<?php
define('KV_ROOMBOSS_BASE', 'https://api.roomboss.com/extws');
define('KV_BOOKING_SYSTEM_BASE', 'https://trip.japanskiexperience.com');
define('KV_ROOMBOSS_USER', 'JSE');
define('KV_ROOMBOSS_PASS', 'B1DcyHegA5TRRHjF');
// define('KV_BS_authToken', '7762|ri1vWuoIOAqqBj0v0omJRbXA3Pmn3mw9hM7VMSAp13f9ca5a');
define('KV_BS_authToken', '7762|ri1vWuoIOAqqBj0v0omJRbXA3Pmn3mw9hM7VMSAp13f9ca5a');

add_action('wp_ajax_niseko_search', 'niseko_search');
add_action('wp_ajax_nopriv_niseko_search', 'niseko_search');

/**
 * Main search dispatcher - routes to booking system or local search
 * Validates input and delegates to appropriate search function
 * 
 * @return void Sends JSON response
 */
function niseko_search() {
    try {
        // ✅ STEP 1: Validate POST data exists
        if (empty($_POST)) {
            return wp_send_json_error([
                'message' => 'No search parameters provided',
                'code' => 'missing_post_data'
            ], 400);
        }

        // ✅ STEP 2: Validate and sanitize date parameters
        $checkin = isset($_POST['checkin']) ? sanitize_text_field($_POST['checkin']) : '';
        $checkout = isset($_POST['checkout']) ? sanitize_text_field($_POST['checkout']) : '';

        $has_dates = !empty($checkin) && !empty($checkout);

        // ✅ STEP 3: Check if hotel/booking system search is requested
        $is_hotel_search = !empty($_POST['hotel_search']);

        // ✅ STEP 4: Route to appropriate search function
        if ($has_dates && $is_hotel_search) {
            // Use Booking System API for hotel search
            hz_search_in_booking_system();
        } else {
            // Fall back to local WordPress search
            niseko_search_local();
        }

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return wp_send_json_error([
            'message' => 'An unexpected error occurred during search',
            'code' => 'unexpected_error',
            'details' => $e->getMessage()
        ], 500);
    }
}

/**
 * Search accommodations using local WordPress database
 * Queries accommodation posts matching user filters and returns paginated results
 * 
 * @return void Sends JSON response with HTML and pagination info
 */
function niseko_search_local()
{
    try {
        // ✅ STEP 1: Validate and build search query arguments
        if (empty($_POST)) {
            return wp_send_json_error([
                'message' => 'No search parameters provided',
                'code' => 'missing_search_params'
            ], 400);
        }

        $args = niseko_build_search_query_args($_POST);
        $all_acc_args = niseko_build_search_query_args($_POST, ['posts_per_page' => -1]);

        if (!is_array($args) || empty($args)) {
            return wp_send_json_error([
                'message' => 'Failed to build search query',
                'code' => 'query_build_failed'
            ], 500);
        }

        // ✅ STEP 2: Execute paginated accommodation query
        $query = new WP_Query($args);

        if (!is_object($query) || !isset($query->posts)) {
            return wp_send_json_error([
                'message' => 'Failed to query accommodations',
                'code' => 'query_execution_failed'
            ], 500);
        }

        // ✅ STEP 3: Build accommodation HTML output
        ob_start();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                get_template_part('partials/accommodation-box');
            }
        } else {
            echo '<p class="no-results">No accommodation found.</p>';
        }

        $html_output = ob_get_clean();
        wp_reset_postdata();

        // ✅ STEP 4: Get all hotel IDs for room count calculation
        $all_acc_query = new WP_Query($all_acc_args);
        $hotel_ids = [];
        $room_count = 0;

        if (!empty($all_acc_query->posts) && is_array($all_acc_query->posts)) {
            foreach ($all_acc_query->posts as $post) {
                if (!is_object($post) || empty($post->ID)) {
                    continue;
                }

                $hotel_id = get_field('acc_hotel_id', $post->ID);
                if (!empty($hotel_id)) {
                    $hotel_ids[] = $hotel_id;
                }
            }
        }

        // ✅ STEP 5: Query related room counts
        if (!empty($hotel_ids)) {
            $room_args = [
                'post_type'      => 'japan_rooms',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [
                    [
                        'key'     => 'room_hotel_id',
                        'value'   => $hotel_ids,
                        'compare' => 'IN',
                    ],
                ],
            ];

            $room_query = new WP_Query($room_args);
            $room_count = isset($room_query->found_posts) ? (int) $room_query->found_posts : 0;
        }

        // ✅ STEP 6: Return paginated results with metadata
        $max_pages = isset($query->max_num_pages) ? $query->max_num_pages : 1;
        $current_page = isset($args['paged']) ? (int) $args['paged'] : 1;

        return wp_send_json_success([
            'html'      => $html_output,
            'count'     => (int) $query->found_posts,
            'room_count' => $room_count,
            'has_more'  => ($current_page < $max_pages),
        ]);

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return wp_send_json_error([
            'message' => 'An unexpected error occurred during search',
            'code' => 'unexpected_error',
            'details' => $e->getMessage()
        ], 500);
    }
}

/**
 * Search availability in Booking System
 * Validates dates, guests, and retrieves available accommodation from booking system
 * 
 * @return void Sends JSON response
 */
function hz_search_in_booking_system() {
    try {
        // ✅ STEP 1: Validate required date parameters
        $checkin_raw = isset($_POST['checkin']) ? sanitize_text_field($_POST['checkin']) : '';
        $checkout_raw = isset($_POST['checkout']) ? sanitize_text_field($_POST['checkout']) : '';

        if (empty($checkin_raw) || empty($checkout_raw)) {
            return wp_send_json_error([
                'message' => 'Check-in and check-out dates are required',
                'code' => 'missing_dates'
            ], 400);
        }

        // ✅ STEP 2: Validate date format (d/m/Y)
        $checkInObj = DateTime::createFromFormat('d/m/Y', $checkin_raw);
        $checkOutObj = DateTime::createFromFormat('d/m/Y', $checkout_raw);

        if (!$checkInObj || !$checkOutObj) {
            return wp_send_json_error([
                'message' => 'Invalid date format. Please use DD/MM/YYYY',
                'code' => 'invalid_date_format'
            ], 400);
        }

        // ✅ STEP 3: Validate date logic (checkout after checkin)
        if ($checkOutObj <= $checkInObj) {
            return wp_send_json_error([
                'message' => 'Check-out date must be after check-in date',
                'code' => 'invalid_date_range'
            ], 400);
        }

        // ✅ STEP 4: Validate guest count
        $guests = !empty($_POST['guests']) ? intval($_POST['guests']) : 1;
        
        // if ($guests < 1 || $guests > 20) {
        //     return wp_send_json_error([
        //         'message' => 'Guest count must be between 1 and 20',
        //         'code' => 'invalid_guest_count'
        //     ], 400);
        // }

        // ✅ STEP 5: Convert date format for API (d/m/Y → d-M-Y)
        $checkIn = hz_convert_date_format($checkin_raw, 'd-M-Y');
        $checkOut = hz_convert_date_format($checkout_raw, 'd-M-Y');

        if (!$checkIn || !$checkOut) {
            return wp_send_json_error([
                'message' => 'Failed to process dates',
                'code' => 'date_conversion_failed'
            ], 500);
        }

        // ✅ STEP 6: Get matching hotel IDs and build booking system arguments
        $localHotelData = hz_get_local_property_ids_and_args($_POST);
        // pre($localHotelData, 1);
        
        if (!is_array($localHotelData)) {
            return wp_send_json_error([
                'message' => 'Failed to retrieve property data',
                'code' => 'property_retrieval_failed'
            ], 500);
        }

        $hotel_ids = $localHotelData['ids'] ?? [];
        $args = $localHotelData['args'] ?? [];
        // pre( $hotel_ids );
        // pre( $args );

        if (empty($hotel_ids)) {
            return wp_send_json_success([
                'html' => '<p>No properties match your search criteria. Please try different filters.</p>',
                'count' => 0,
                'room_count' => 0,
                'has_more' => false,
            ]);
        }
        // cf_log($args, 'acc_args');
        // ✅ STEP 7: Query booking system for availability (with caching)
        $roombossData = kv_roomboss_available_ids_cached($hotel_ids, $args);

        if (is_wp_error($roombossData)) {
            return wp_send_json_error([
                'message' => 'Error retrieving availability: ' . $roombossData->get_error_message(),
                'code' => 'availability_query_failed'
            ], 500);
        }

        if (empty($roombossData)) {
            return wp_send_json_success([
                'html' => '<p>No availability found for the selected dates. Please try different dates.</p>',
                'count' => 0,
                'room_count' => 0,
                'has_more' => false,
            ]);
        }

        // ✅ STEP 8: Render accommodation results
        $availableHotelIds = array_keys($roombossData);
        niseko_search_roomboss_wp($availableHotelIds, $roombossData);

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return wp_send_json_error([
            'message' => 'An unexpected error occurred while searching',
            'code' => 'unexpected_error',
            'details' => $e->getMessage()
        ], 500);
    }
}

function get_room_count_from_roomboss_hotels($hotel_ids)
{
    $rooms_query = new WP_Query([
        'post_type'      => 'japan_rooms',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_query'     => [
            [
                'key'     => 'property_id',
                'value'   => $hotel_ids,
                'compare' => 'IN',
            ],
        ],
    ]);
    return (int)$rooms_query->found_posts ?? 0;;
    // return $rooms_query ?? [];
}

/**
 * Get available hotel IDs with pricing from Booking System (cached)
 * 
 * @param array $hotelIds List of hotel IDs to query
 * @param array $args Search parameters (start_date, end_date, maxPersons, etc.)
 * @return array|WP_Error Array of results or WP_Error on failure
 */
function kv_roomboss_available_ids_cached(
    array $hotelIds,
    array $args
) {
    try {
        // ✅ STEP 1: Validate input parameters
        if (empty($hotelIds) || !is_array($hotelIds)) {
            return [];
        }

        $hotelIds = array_filter($hotelIds); // Remove empty values
        if (empty($hotelIds)) {
            return [];
        }
        // pre($hotelIds, 0);

        // ✅ STEP 2: Validate and extract date parameters
        $checkIn = isset($args['start_date']) ? sanitize_text_field($args['start_date']) : '';
        $checkOut = isset($args['end_date']) ? sanitize_text_field($args['end_date']) : '';
        $guests = !empty($args['maxPersons']) ? intval($args['maxPersons']) : 1;

        if (empty($checkIn) || empty($checkOut)) {
            return new WP_Error(
                'invalid_dates',
                'Start date and end date are required for availability check'
            );
        }

        // ✅ STEP 3: Generate cache key
        $cache_key = 'rb_full_' . md5($checkIn . $checkOut . $guests . implode(',', $hotelIds));
        
        // ✅ STEP 4: Check cache first
        $cached_body = get_transient($cache_key);
        // pre($cached_body, 1);
        if ($cached_body !== false && is_array($cached_body)) {
            return kv_roomboss_parse_availability($cached_body);
        }
        // pre($cached_body, 1);

        // ✅ STEP 5: Fetch from Booking System API
        $url = KV_BOOKING_SYSTEM_BASE . '/api/quotation-filteration';
        $bs_args = kv_booking_system_filter_args(KV_BS_authToken, $args);
        // cf_log( $bs_args, 'acc_bs_args', 'txt', false, true );
        
        if (!$bs_args) {
            return new WP_Error(
                'invalid_request_args',
                'Failed to build booking system request arguments'
            );
        }

        $response = wp_remote_get($url, $bs_args);

        // ✅ STEP 6: Validate API response
        if (is_wp_error($response)) {
            return new WP_Error(
                'api_request_failed',
                'Failed to connect to booking system: ' . $response->get_error_message()
            );
        }

        $http_code = wp_remote_retrieve_response_code($response);
        if ($http_code !== 200) {
            return new WP_Error(
                'api_error',
                'Booking system returned HTTP ' . $http_code
            );
        }

        // ✅ STEP 7: Parse JSON response
        $response_body = wp_remote_retrieve_body($response);
        if (empty($response_body)) {
            return new WP_Error(
                'empty_response',
                'Booking system returned empty response'
            );
        }

        $body = json_decode($response_body, true);
        if (!is_array($body)) {
            return new WP_Error(
                'invalid_json',
                'Booking system returned invalid JSON'
            );
        }

        // ✅ STEP 8: Cache the response
        set_transient($cache_key, $body, 10 * MINUTE_IN_SECONDS);

        // ✅ STEP 9: Parse and return availability data
        return kv_roomboss_parse_availability($body);

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return new WP_Error(
            'unexpected_error',
            'Error retrieving availability: ' . $e->getMessage()
        );
    }
}

/**
 * Parse booking system availability response into standardized format
 * 
 * @param array $body API response body
 * @return array Parsed results with hotel IDs as keys
 */
function kv_roomboss_parse_availability(array $body): array {
    $results = [];

    // Validate properties exist in response
    if (empty($body['properties']) || !is_array($body['properties'])) {
        return [];
    }

    foreach ($body['properties'] as $hotel) {
        // Skip hotels without units
        if (empty($hotel['Units']) || !is_array($hotel['Units'])) {
            continue;
        }

        // Skip hotels without property ID
        if (empty($hotel['PropertyId'])) {
            continue;
        }

        $prices = [];
        $bedrooms = [];
        $room_count = 0;

        // ✅ Iterate through units
        foreach ($hotel['Units'] as $unit) {
            // Validate unit data
            if (empty($unit) || !is_array($unit)) {
                continue;
            }

            // Skip invalid units (Unit count <= 0)
            if (empty($unit['Unit']) || intval($unit['Unit']) <= 0) {
                continue;
            }

            // Validate rooms data
            if (empty($unit['Rooms']) || !is_array($unit['Rooms'])) {
                continue;
            }

            // ✅ Iterate through rooms
            foreach ($unit['Rooms'] as $room) {
                if (empty($room) || !is_array($room)) {
                    continue;
                }

                $room_count++;

                // Collect pricing data
                if (!empty($room['ActualPrice']) && is_numeric($room['ActualPrice'])) {
                    $prices[] = (float) $room['ActualPrice'];
                }

                // Collect bedroom count data
                if (!empty($room['numberBedrooms']) && is_numeric($room['numberBedrooms'])) {
                    $bedrooms[] = (int) $room['numberBedrooms'];
                }
            }
        }

        // Only include hotels with at least one room
        if ($room_count === 0) {
            continue;
        }

        // Build result entry for this hotel
        $results[$hotel['PropertyId']] = [
            'min_price'  => !empty($prices) ? min($prices) : null,
            'bedrooms'   => !empty($bedrooms) ? array_values(array_unique($bedrooms)) : [],
            'room_count' => $room_count,
        ];
    }

    return $results;
}


// function kv_roomboss_available_ids(
//     array $hotelIds,
//     string $checkIn,
//     string $checkOut,
//     int $guests
// ): array {

//     if (empty($hotelIds)) {
//         return [];
//     }

//     $results = [];

//     // RoomBoss limitation → chunk requests
//     $chunks = array_chunk($hotelIds, 50);

//     foreach ($chunks as $chunkIds) {

//         $hotelParams = implode('&', array_map(
//             fn($id) => 'hotelId=' . urlencode($id),
//             $chunkIds
//         ));

//         $url = KV_ROOMBOSS_BASE . '/hotel/v1/listAvailable?'
//             . $hotelParams
//             . "&checkIn={$checkIn}"
//             . "&checkOut={$checkOut}"
//             . "&numberGuests={$guests}"
//             . "&rate=ota";

//         $response = wp_remote_get($url, kv_roomboss_http());

//         if (is_wp_error($response)) {
//             continue;
//         }

//         $body = json_decode(wp_remote_retrieve_body($response), true);

//         if (
//             empty($body['success']) ||
//             empty($body['availableHotels'])
//         ) {
//             continue;
//         }

//         $hotel_ids = wp_list_pluck($body['availableHotels'], 'hotelId');

//         foreach ($body['availableHotels'] as $hotel) {

//             if (empty($hotel['availableRoomTypes'])) {
//                 continue;
//             }


//             // get room count

//             $prices   = [];
//             $bedrooms = [];

//             $room_count = count($hotel['availableRoomTypes']);

//             foreach ($hotel['availableRoomTypes'] as $room) {

//                 // ✅ Basic availability only
//                 if (empty($room['quantityAvailable']) || $room['quantityAvailable'] <= 0) {
//                     continue;
//                 }

//                 // 💰 Collect prices
//                 if (!empty($room['ratePlan']['priceRetail'])) {
//                     $prices[] = (float) $room['ratePlan']['priceRetail'];
//                 }

//                 // 🛏️ Collect bedroom counts
//                 if (!empty($room['numberBedrooms'])) {
//                     $bedrooms[] = (int) $room['numberBedrooms'];
//                 }
//             }

//             if (!$prices && !$bedrooms) {
//                 continue;
//             }

//             $results[$hotel['hotelId']] = [
//                 'min_price' => $prices ? min($prices) : null,
//                 'bedrooms'  => array_values(array_unique($bedrooms)),
//                 'room_count'  => (int)$room_count,
//             ];
//         }
//     }
//     return $results;
// }

/**
 * Build Booking System API request arguments
 * Merges default body with user overrides and creates HTTP headers
 * 
 * @param string $authorization Bearer token for API authentication
 * @param array $overrides Optional request body parameters to override defaults
 * @return array HTTP request arguments (method, headers, body, timeout)
 */
function kv_booking_system_filter_args( string $authorization, array $overrides = []): array {
    try {
        // ✅ STEP 1: Validate authorization token
        $authorization = trim($authorization);
        if (empty($authorization)) {
            return [];
        }

        // ✅ STEP 2: Build default request body
        $body = [
            "accommodationName" => "",
            "minRange" => null,
            "maxRange" => null,
            "resortId" => 1,
            "locationCode" => "",
            "boardBasisId" => "",
            "start_date" => "02-Apr-2026",
            "end_date" => "08-Apr-2026",
            "duration" => 6,
            "units" => 1,
            "channel" => true,
            "bedBank" => true,
            "testMode" => false,
            "propertType" => [
                "apartment" => false,
                "chalet" => false,
                "hotel" => false
            ],
            "maxPersons" => 1,
            "totalAdults" => 1,
            "totalChildren" => 0,
            "totalInfants" => 0,
            "offset" => 0,
            "limit" => 50,
            "adults" => [1],
            "children" => [0],
            "infants" => [0],
            "propertyIds" => []
        ];

        // ✅ STEP 3: Merge overrides safely (only process if overrides is array)
        if (!empty($overrides) && is_array($overrides)) {
            $body = array_replace_recursive($body, $overrides);
        }

        // ✅ STEP 4: Build HTTP headers with authorization
        $headers = [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $authorization,
        ];

        // ✅ STEP 5: Return complete request arguments
        return [
            'method'      => 'POST',
            'headers'     => $headers,
            'body'        => wp_json_encode($body),
            'timeout'     => 30,
            'data_format' => 'body',
        ];

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        error_log('Error building booking system filter args: ' . $e->getMessage());
        return [];
    }
}

/**
 * Calculate number of days between two dates
 * 
 * @param string $start_date Start date in 'd-M-Y' format (e.g., '02-Apr-2026')
 * @param string $end_date End date in 'd-M-Y' format (e.g., '08-Apr-2026')
 * @return int|false Number of days as integer, or false on error
 */
function get_duration_from_date( $start_date, $end_date ) {
    try {
        // ✅ STEP 1: Validate parameters are not empty
        if (empty($start_date) || empty($end_date)) {
            return false;
        }

        // ✅ STEP 2: Sanitize input dates
        $start_date = trim((string) $start_date);
        $end_date = trim((string) $end_date);

        if (empty($start_date) || empty($end_date)) {
            return false;
        }

        // ✅ STEP 3: Parse dates with error handling
        $date1 = DateTime::createFromFormat('d-M-Y', $start_date);
        $date2 = DateTime::createFromFormat('d-M-Y', $end_date);

        if (!$date1 || !$date2) {
            return false;
        }

        // ✅ STEP 4: Calculate and return duration
        $duration = $date1->diff($date2);
        return (int) $duration->days;

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        error_log('Error calculating date duration: ' . $e->getMessage());
        return false;
    }
}

/**
 * Convert date from d/m/Y format to specified output format
 * Input format: d/m/Y (e.g., '10/04/2026' = April 10, 2026)
 * Output formats: 'd-M-Y' (02-Apr-2026), 'Y-m-d', etc.
 * 
 * @param string $date Input date in d/m/Y format
 * @param string $format Output format string for DateTime
 * @return string|false Formatted date string, or false on error
 */
function hz_convert_date_format( string $date, string $format ) {
    try {
        // ✅ STEP 1: Validate input parameters
        $date = trim($date);
        $format = trim($format);

        if (empty($date) || empty($format)) {
            return false;
        }

        // ✅ STEP 2: Parse date with input format d/m/Y
        $dateObject = DateTime::createFromFormat('d/m/Y', $date);

        if (!$dateObject) {
            return false;
        }

        // ✅ STEP 3: Format and return result
        return $dateObject->format($format);

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        error_log('Error converting date format: ' . $e->getMessage());
        return false;
    }
}

/**
 * Get local property IDs and build booking system API arguments
 * Queries WordPress database for accommodation matching filters and constructs API request body
 * 
 * @param array $input Search input containing filters (checkin, checkout, resort, prices, etc.)
 * @return array Array with 'ids' => property IDs array and 'args' => booking system request body
 */
function hz_get_local_property_ids_and_args(array $input): array {
    $empty_result = ['ids' => [], 'args' => []];
    try {
        // ✅ STEP 1: Validate input and query local properties
        if (empty($input) || !is_array($input)) {
            return $empty_result;
        }

        $args = niseko_build_search_query_args($input, [
            'fields'         => 'ids',
            'posts_per_page' => -1,
        ]);

        if (!is_array($args) || empty($args)) {
            return $empty_result;
        }

        $query = new WP_Query($args);

        if (empty($query->posts) || !is_array($query->posts)) {
            return $empty_result;
        }

        $booking_sys_args = [];

        // ✅ STEP 2: Process date parameters
        if (isset($input['checkin'], $input['checkout'])) {
            $checkin_raw = sanitize_text_field($input['checkin']);
            $checkout_raw = sanitize_text_field($input['checkout']);

            if (!empty($checkin_raw) && !empty($checkout_raw)) {
                // Convert dates d/m/Y → d-M-Y format for API
                $checkin = hz_convert_date_format($checkin_raw, 'd-M-Y');
                $checkout = hz_convert_date_format($checkout_raw, 'd-M-Y');

                if ($checkin && $checkout) {
                    $duration = get_duration_from_date($checkin, $checkout);

                    if ($duration !== false && $duration > 0) {
                        $booking_sys_args['start_date'] = $checkin;
                        $booking_sys_args['end_date'] = $checkout;
                        $booking_sys_args['duration'] = (int) $duration;
                    }
                }
            }
        }

        // ✅ STEP 3: Process resort parameter
        if (!empty($input['resort'])) {
            $taxonomy_name = sanitize_text_field($input['resort']);
            $term = get_term_by('slug', $taxonomy_name, 'accommodation-cat');

            if ($term && !is_wp_error($term)) {
                $term_id = intval($term->term_id);
                $resortId = get_field('bs_resort_id', 'term_' . $term_id);

                if (!empty($resortId)) {
                    $booking_sys_args['resortId'] = intval($resortId);
                }
            }
        }

        // ✅ STEP 4: Process price parameters
        if (isset($input['price_min'], $input['price_max'])) {
            $minRange = sanitize_text_field($input['price_min']);
            $maxRange = sanitize_text_field($input['price_max']);

            if (!empty($minRange) && !empty($maxRange)) {
                $booking_sys_args['minRange'] = (float) $minRange;
                $booking_sys_args['maxRange'] = (float) $maxRange;
            }
        }

        // ✅ STEP 5: Process accommodation type parameters
        if (!empty($input['accommodation_type']) && is_array($input['accommodation_type'])) {
            $acc_types = array_map('strtolower', $input['accommodation_type']);
            $acc_types = array_map('sanitize_text_field', $acc_types);

            $booking_sys_args['propertType']['apartment'] = in_array('apartments', $acc_types, true);
            $booking_sys_args['propertType']['chalet'] = in_array('chalet', $acc_types, true);
            $booking_sys_args['propertType']['hotel'] = in_array('hotel rooms', $acc_types, true);
        }

        // ✅ STEP 6: Process booking channel parameter
        if (!empty($input['booking'])) {
            $booking_sys_args['channel'] = true;
            $booking_sys_args['bedBank'] = false;
        }

        // ✅ STEP 7: Process areas/location parameter
        if (!empty($input['areas[]'])) {
            $areas = sanitize_text_field($input['areas[]']);
            if (!empty($areas)) {
                $booking_sys_args['locationCode'] = $areas;
            }
        }

        // ✅ STEP 8: Extract property IDs from query results
        $ids = array_values(
            array_unique(
                array_filter(
                    array_map(
                        function($post_id) {
                            if (!is_numeric($post_id)) {
                                return null;
                            }
                            $property_id = get_field('property_id', (int) $post_id);
                            return !empty($property_id) ? $property_id : null;
                        },
                        $query->posts
                    )
                )
            )
        );

        // ✅ STEP 9: Return property IDs and booking system arguments
        return [
            'ids' => $ids,
            'args' => $booking_sys_args,
        ];

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        error_log('Error building property IDs and booking args: ' . $e->getMessage());
        return $empty_result;
    }
}

/**
 * Retrieve rooms for a hotel property with optional room type filtering
 * 
 * @param mixed $hotel_id Property ID to query rooms for
 * @param array $allowedRoomTypeIds Optional array of room type IDs to filter by
 * @return array Array containing 'rooms' (array of posts) and 'bedroom_types' (unique bedroom counts)
 */
function get_hotel_rooms($hotel_id, array $allowedRoomTypeIds = [])
{
    try {
        // ✅ STEP 1: Validate and sanitize hotel_id parameter
        if (empty($hotel_id)) {
            return [
                'rooms' => [],
                'bedroom_types' => [],
            ];
        }

        // Type-cast hotel_id appropriately
        $hotel_id = is_numeric($hotel_id) ? (int) $hotel_id : sanitize_text_field($hotel_id);

        if (empty($hotel_id)) {
            return [
                'rooms' => [],
                'bedroom_types' => [],
            ];
        }

        // ✅ STEP 2: Build base meta query
        $meta_query = [
            'relation' => 'AND',
            [
                'key'     => 'property_id',
                'value'   => $hotel_id,
                'compare' => '=',
            ],
        ];

        // ✅ STEP 3: Add optional room type filter
        if (!empty($allowedRoomTypeIds) && is_array($allowedRoomTypeIds)) {
            // Sanitize and filter room type IDs
            $allowedRoomTypeIds = array_filter(array_map('absint', $allowedRoomTypeIds));

            if (!empty($allowedRoomTypeIds)) {
                $meta_query[] = [
                    'key'     => 'actual_room_id',
                    'value'   => $allowedRoomTypeIds,
                    'compare' => 'IN',
                ];
            }
        }

        // ✅ STEP 4: Query for rooms
        $args = [
            'post_type'      => 'japan_rooms',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_query'     => $meta_query,
        ];

        $rooms = get_posts($args);

        // Validate query result
        if (!is_array($rooms)) {
            $rooms = [];
        }

        // ✅ STEP 5: Collect distinct bedroom types from results
        $bedroom_types = [];

        foreach ($rooms as $room) {
            // Validate room object structure
            if (!is_object($room) || empty($room->ID)) {
                continue;
            }

            $bedrooms = get_field('room_bedroom', $room->ID);

            // Validate and type-cast bedroom count
            if (!empty($bedrooms)) {
                $bedrooms = (int) $bedrooms;

                if ($bedrooms > 0 && !in_array($bedrooms, $bedroom_types, true)) {
                    $bedroom_types[] = $bedrooms;
                }
            }
        }

        // ✅ STEP 6: Sort bedroom types for consistent output
        sort($bedroom_types);

        // ✅ STEP 7: Return results
        return [
            'rooms'         => $rooms,
            'bedroom_types' => $bedroom_types,
        ];

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        error_log('Error in get_hotel_rooms: ' . $e->getMessage());

        return [
            'rooms' => [],
            'bedroom_types' => [],
        ];
    }
}

function niseko_build_search_query_args(array $input, array $overrides = []): array
{

    $paged    = isset($input['page']) ? max(1, (int) $input['page']) : 1;
    $per_page = 6;

    $meta_query = [ /*'relation' => 'AND'*/ ];
    $tax_query  = [];

    /* =========================
     * TAXONOMY
     * ========================= */
    if (!empty($input['category_id']) || !empty($input['category_slug']) || !empty($input['resort'])) {
        $tax_query = [
            'relation' => 'OR',
        ];

        if (!empty($input['category_id'])) {
            $tax_query[] = [
                'taxonomy'         => 'accommodation-cat',
                'field'            => 'term_id',
                'terms'            => [(int) $input['category_id']],
                'include_children' => true,
            ];
        }

        if (!empty($input['category_slug'])) {
            $tax_query[] = [
                'taxonomy' => 'accommodation-cat',
                'field'    => 'slug',
                'terms'    => sanitize_text_field($input['category_slug']),
            ];
        }

        /* =========================
         * RESORT (OPTIONAL)
         * ========================= */

        if (!empty($input['resort'])) {
            $tax_query[] = [
                'taxonomy' => 'accommodation-cat',
                'field'    => 'slug',
                'terms'    => sanitize_text_field($input['resort']),
            ];
            cf_log($tax_query, 'resort');
        }
    }

    /* =========================
     * BEDROOMS
     * ========================= */
    if (!empty($input['bedrooms']) && is_array($input['bedrooms'])) {
        $bedroom_sub = ['relation' => 'OR'];
        foreach ($input['bedrooms'] as $bedroom) {
            $bedroom_sub[] = [
                'key'     => 'bedroom_number',
                'value'   => '"' . sanitize_text_field($bedroom) . '"',
                'compare' => 'LIKE',
            ];
        }
        $meta_query[] = $bedroom_sub;
    }

    /* =========================
     * PRICE
     * ========================= */
    if (
        isset($input['price_min'], $input['price_max']) &&
        $input['price_min'] !== '' &&
        $input['price_max'] !== ''
    ) {
        $meta_query[] = [
            'key'     => 'min_room_price',
            'value'   => [
                (int) $input['price_min'],
                (int) $input['price_max'],
            ],
            'type'    => 'NUMERIC',
            'compare' => 'BETWEEN',
        ];
    }

    /* =========================
     * AREA
     * ========================= */
    if (!empty($input['areas']) && is_array($input['areas'])) {
        $area_sub = ['relation' => 'OR'];
        foreach ($input['areas'] as $area) {
            $area_sub[] = [
                'key'     => 'area',
                'value'   => '"' . sanitize_text_field($area) . '"',
                'compare' => 'LIKE',
            ];
        }
        $meta_query[] = $area_sub;
    }

    /* =========================
     * TYPE
     * ========================= */
    if (!empty($input['accommodation_type']) && is_array($input['accommodation_type'])) {
        $type_sub = ['relation' => 'OR'];
        foreach ($input['accommodation_type'] as $type) {
            $type_sub[] = [
                'key'     => 'type',
                'value'   => '"' . sanitize_text_field($type) . '"',
                'compare' => 'LIKE',
            ];
        }
        $meta_query[] = $type_sub;
    }

    /* =========================
     * ski in ski out
     * ========================= */
    if (!empty($input['ski_in_out'])) {
        $ski_in_out = ['relation' => 'AND'];
        $ski_in_out[] = [
            'key'     => 'area',
            'value'   => '"' . $input['ski_in_out'] . '"',
            'compare' => 'LIKE',
        ];
        $meta_query[] = $ski_in_out;
    }

    /* =========================
     * onsen
     * ========================= */
    if (!empty($input['onsen'])) {
        $onsen = ['relation' => 'AND'];
        $onsen[] = [
            'key'     => 'type',
            'value'   => '"' . $input['onsen'] . '"',
            'compare' => 'LIKE',
        ];
        $meta_query[] = $onsen;
    }


    /* =========================
     * discount
     * ========================= */
    if (!empty($input['discount'])) {
        $discount = ['relation' => 'AND'];
        $discount[] = [
            'key'     => 'is_discount',
            'value'   => '1',
            'compare' => '=',
        ];
        $meta_query[] = $discount;
    }

    if (!empty($input['booking'])) {
        $booking = ['relation' => 'AND'];
        $booking[] = [
            'key'     => 'is_roomboss',
            'value'   => '1',
            'compare' => '=',
        ];

        $booking[] = [
            'key'     => 'acc_hotel_id',
            'compare' => 'EXISTS',
        ];
        $meta_query[] = $booking;
    }

    /* =========================
     * SORTING
     * ========================= */
    
    $orderby  = 'meta_value_num';
    $order    = 'ASC';
    $meta_key = 'post_order';

    if (!empty($input['sort'])) {
        switch ($input['sort']) {
            case 'price_asc':
                $meta_key = 'min_room_price';
                $order    = 'ASC';
                break;
            case 'price_desc':
                $meta_key = 'min_room_price';
                $order    = 'DESC';
                break;
            case 'title_asc':
                $orderby  = 'title';
                $order    = 'ASC';
                $meta_key = '';
                break;
            case 'title_desc':
                $orderby  = 'title';
                $order    = 'DESC';
                $meta_key = '';
                break;
            case 'date_desc':
                $orderby  = 'date';
                $order    = 'DESC';
                $meta_key = '';
                break;
        }
    }

    $args = [
        'post_type'      => 'accommodation',
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $paged,
        'meta_query'     => $meta_query,
        'orderby'        => $orderby,
        'order'          => $order,
    ];

    if (!empty($input['search_acc'])) {
        $args['title'] = $input['search_acc'];
    }

    if (!empty($meta_key)) {
        $args['meta_key'] = $meta_key;
    }    

    if ($tax_query) {
        $args['tax_query'] = $tax_query;
    }

    // 🔁 Allow overrides (fields, posts_per_page, etc.)
    return array_replace_recursive($args, $overrides);
}


function niseko_search_roomboss_wp(array $availableHotelIds, array $roombossData = [])
{

    $room_count = get_room_count_from_roomboss_hotels($availableHotelIds);
    if (empty($availableHotelIds)) {
        wp_send_json_success([
            'html'     => '<p>No accommodation available.</p>',
            'count'    => 0,
            'has_more' => false,
        ]);
    }

    $args = niseko_build_search_query_args($_POST, [
        'meta_query' => [
            'relation' => 'AND',
            [
                'key'           => 'property_id',
                'value'         => $availableHotelIds,
                'room_count'    => $room_count,
                'compare'       => 'IN',
            ],
        ],
    ]);

    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            $property_id = get_field('property_id', get_the_ID());

            $GLOBALS['kv_roomboss_current'] = $roombossData[$property_id] ?? null;

            // get_template_part('partials/accommodation-box', null, ['bed_bank' => false, 'room_boss' => true]);

            unset($GLOBALS['kv_roomboss_current']);
        }
    } else {
        echo '<p>No accommodation available.</p>';
    }

    wp_reset_postdata();

    wp_send_json_success([
        'html'     => ob_get_clean(),
        'count'    => (int) $query->found_posts,
        'room_count'    => $room_count,
        'has_more' => ($args['paged'] < $query->max_num_pages),
    ]);
}

function get_post_id_by_property_id( $property_id ){
    $query = new WP_Query([
        'post_type'      => 'accommodation',
        'posts_per_page' => 1,
        'meta_query'     => [
            [
                'key'     => 'property_id',
                'value'   => $property_id,
                'compare' => '=',
            ],
        ],
    ]);

    if ( $query->have_posts() ) {
        return $query->posts[0]->ID;
    }

    return null;
}

function get_resort_id_by_property_id( $property_id ){

    $post_id = get_post_id_by_property_id( $property_id );

    if ( ! $post_id ) {
        return null;
    }

    $terms = get_the_terms( $post_id, 'accommodation-cat' );

    if ( is_wp_error( $terms ) || empty( $terms ) ) {
        return null;
    }

    foreach ( $terms as $term ) {
        $resort_id = get_field( 'bs_resort_id', 'term_' . $term->term_id );
        if ( $resort_id ) {
            return $resort_id;
        }
    }

    return null;
}

function get_available_bedrooms( $rooms ){
    $available_bedroom_types = [];
    if (!empty($rooms)) {
    
        foreach ($rooms as $room) {
            if (!empty($room['numberBedrooms'])) {
                $available_bedroom_types[] = (int) $room['numberBedrooms'];
            }
        }

        $available_bedroom_types = array_values( array_unique($available_bedroom_types) );
        sort($available_bedroom_types);
    }

    return $available_bedroom_types;
}

// Register the AJAX action
add_action('wp_ajax_niseko_search_roomboss_single', 'niseko_search_roomboss_single');
add_action('wp_ajax_nopriv_niseko_search_roomboss_single', 'niseko_search_roomboss_single');

// Handle the "Check Rates" for a single hotel room search
function niseko_search_roomboss_single()
{
    // Ensure required fields are passed
    if (empty($_POST['checkin']) || empty($_POST['checkout']) || empty($_POST['property_id'])) {
        wp_send_json_error(['message' => 'Missing required parameters']);
    }

    $checkin = sanitize_text_field($_POST['checkin']);
    $checkout = sanitize_text_field($_POST['checkout']);
    $property_id = sanitize_text_field($_POST['property_id']);

    // Get room data for the single hotel
    $roomData = kv_bs_available_room_data($property_id, $checkin, $checkout, 1);
    if (empty($roomData)) {
        wp_send_json_success([
            'html' => '<p>No rooms available for the selected dates. Choose new dates or request a quote to find availability.</p>',
            'count' => 0,
            'has_more' => false,
        ]);
    }


    $is_rb = $roomData['is_roomboss'];
    ob_start();
    if (!empty($roomData)) :
        foreach ($roomData as $room) :
            if( !is_array( $room ) ) continue;
            get_template_part('partials/room-box-bs', null, ['room' => $room, 'rb' => $is_rb, 'property_id' => $property_id]);
        endforeach;
    else :
        echo '<p>No rooms available for the selected dates. Choose new dates or request a quote to find availability.</p>';
    endif;

    $html = ob_get_clean();
    $available_bedroom_types = get_available_bedrooms( $roomData );

    wp_send_json_success([
        'html' => $html,
        'available_bedroom_types' => $available_bedroom_types, // Return available bedroom types for filter
        'count' => count(array_filter(array_keys($roomData), 'is_int')), /*retuen number of rooms*/
        'has_more' => false, // Or add pagination logic if necessary
    ]);
}

function kv_bs_available_room_data(
    int $propertyId,
    string $checkIn,
    string $checkOut,
    int $guests
    ): array {

    // Hotel ID is required
    if (empty($propertyId)) {
        return [];
    }

    $checkIn = hz_convert_date_format( $checkIn, 'd-M-Y' );
    $checkOut = hz_convert_date_format( $checkOut, 'd-M-Y' );

    // Extract room details for the single hotel
    $hotel = kv_roomboss_get_availability(
                $propertyId,
                $checkIn,
                $checkOut,
                $guests
            );
    if( !empty( $hotel ) ){

        $units = $hotel[0]['Units'][0] ?? [];
        $rooms = $units['Rooms'];
        $is_rb = !empty( $hotel['PropertyRoomBossHotelId'] ) ? 1 : 0;
        $rooms['is_roomboss'] = $is_rb;
        // Return structured data for rooms
        return $rooms;
    }
    else{
        return [];
    }
}

add_action('wp_ajax_niseko_load_room_details', 'niseko_load_room_details');
add_action('wp_ajax_nopriv_niseko_load_room_details', 'niseko_load_room_details');

function niseko_load_room_details()
{
    $room_id = intval($_POST['room_id'] ?? 0);
    $hotel_id = $_POST['hotel_id'] ?? 0;

    if (!$room_id) {
        wp_send_json_error();
    }

    ob_start();
    get_template_part('partials/room-details-modal', null, ['room_id' => $room_id, 'hotel_id' => $hotel_id]); // NEW template
    wp_reset_postdata();

    wp_send_json_success([
        'html' => ob_get_clean()
    ]);
}


add_action('wp_ajax_load_roomboss_booking', 'kv_ajax_load_roomboss_booking');
add_action('wp_ajax_nopriv_load_roomboss_booking', 'kv_ajax_load_roomboss_booking');

/**
 * Load available rooms for booking with guest details and date range
 * 
 * @return void Sends JSON response with room availability
 */
function kv_ajax_load_roomboss_booking()
{
    try {
        // ✅ STEP 1: Validate and sanitize date inputs
        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';

        if (empty($start_date) || empty($end_date)) {
            return wp_send_json_error([
                'message' => 'Check-in and check-out dates are required',
                'code' => 'missing_dates'
            ], 400);
        }

        // ✅ STEP 2: Validate date format (d/m/Y)
        $checkInObj = DateTime::createFromFormat('d/m/Y', $start_date);
        $checkOutObj = DateTime::createFromFormat('d/m/Y', $end_date);

        if (!$checkInObj || !$checkOutObj) {
            return wp_send_json_error([
                'message' => 'Invalid date format. Please use DD/MM/YYYY',
                'code' => 'invalid_date_format'
            ], 400);
        }

        // ✅ STEP 3: Validate date range (checkout after checkin)
        if ($checkOutObj <= $checkInObj) {
            return wp_send_json_error([
                'message' => 'Check-out date must be after check-in date',
                'code' => 'invalid_date_range'
            ], 400);
        }

        // ✅ STEP 4: Validate and calculate guest count
        $adults = !empty($_POST['adults']) ? intval($_POST['adults']) : 0;
        $children = !empty($_POST['children']) ? intval($_POST['children']) : 0;
        $infants = !empty($_POST['infants']) ? intval($_POST['infants']) : 0;

        $guests = $adults + $children + $infants;

        // if ($guests < 1 || $guests > 20) {
        //     return wp_send_json_error([
        //         'message' => 'Total guests must be between 1 and 20',
        //         'code' => 'invalid_guest_count'
        //     ], 400);
        // }

        // ✅ STEP 5: Validate property ID
        $property_id = !empty($_POST['property_id']) ? intval($_POST['property_id']) : 0;

        if ($property_id < 1) {
            return wp_send_json_error([
                'message' => 'Valid property ID is required',
                'code' => 'invalid_property_id'
            ], 400);
        }

        // ✅ STEP 6: Convert date format for API (d/m/Y → d-M-Y)
        $checkIn = $checkInObj->format('d-M-Y');
        $checkOut = $checkOutObj->format('d-M-Y');

        if (!$checkIn || !$checkOut) {
            return wp_send_json_error([
                'message' => 'Failed to process dates',
                'code' => 'date_conversion_failed'
            ], 500);
        }

        // ✅ STEP 7: Build cache key and check transient
        $cache_key = "availability_{$property_id}_{$checkIn}_{$checkOut}";
        $availability = get_transient($cache_key);

        // ✅ STEP 8: Fetch from API if not cached
        if (true) {
        // if ($availability === false) {
            $availability = kv_roomboss_get_availability(
                (string) $property_id,
                $checkIn,
                $checkOut,
                $guests
            );

            // Handle API errors
            if (is_wp_error($availability)) {
                return wp_send_json_error([
                    'message' => 'Error retrieving availability: ' . $availability->get_error_message(),
                    'code' => $availability->get_error_code()
                ], 500);
            }

            // Cache the result for 10 minutes
            if (!empty($availability)) {
                set_transient($cache_key, $availability, 10 * MINUTE_IN_SECONDS);
            }
        }

        // ✅ STEP 9: Validate availability response
        if (empty($availability) || !is_array($availability)) {
            return wp_send_json_success([
                'html' => '<p>No rooms available for the selected dates. Please try different dates.</p>',
                'available_bedroom_types' => [],
            ]);
        }

        // ✅ STEP 10: Validate room data structure
        if (empty($availability[0]['Units'][0]['Rooms'])) {
            return wp_send_json_success([
                'html' => '<p>No rooms available for the selected dates. Please try different dates.</p>',
                'available_bedroom_types' => [],
            ]);
        }
        // pre($availability);

        $bs_rooms = $availability[0]['Units'][0]['Rooms'];

        // ✅ STEP 11: Prepare room data
        $grouped_rooms = kv_bs_group_rooms($bs_rooms);
        $available_bedroom_types = get_available_bedrooms($bs_rooms);
        $rate_plans = kv_roomboss_get_rate_plans($grouped_rooms);
        $room_descriptions = kv_roomboss_get_room_descriptions($grouped_rooms);

        // ✅ STEP 12: Render template
        ob_start();
        get_template_part(
            'partials/room-booking-data',
            null,
            [
                'grouped_rooms' => $grouped_rooms,
                'property_id' => $property_id,
                'rate_plans' => $rate_plans,
                'room_descriptions' => $room_descriptions,
                'dates' => [
                    'check_in' => $start_date,
                    'check_out' => $end_date,
                    'guests' => $guests,
                ],
            ]
        );
        $html = ob_get_clean();

        if (empty($html)) {
            return wp_send_json_error([
                'message' => 'Failed to render rooms template',
                'code' => 'template_render_failed'
            ], 500);
        }

        // ✅ STEP 13: Return success response
        return wp_send_json_success([
            'html' => $html,
            'available_bedroom_types' => $available_bedroom_types,
            'room_count' => count($grouped_rooms),
        ]);

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return wp_send_json_error([
            'message' => 'An unexpected error occurred while loading rooms',
            'code' => 'unexpected_error',
            'details' => $e->getMessage()
        ], 500);
    }
}

function kv_roomboss_get_rate_plans($rooms): array
{

    $plans = [];
    foreach ($rooms ?? [] as $p) {
        if( $p['ratePlanId'] != null ){

            $plans[$p['ratePlanId']] = [
                'name'        => $p['ratePlanName'] ?? '',
                'description' => $p['descriptions'] ?? '',
                'long_desc'   => $p['ratePlanLongDescription'] ?? '',
            ];
        }
    }

    return $plans;
}

function kv_roomboss_get_room_descriptions(array $rooms): array
{
    $desc = [];
    foreach ($rooms as $room) {
        if( !empty($room['RoomId']) ){
            
            $room_id = $room['RoomId'];
            if (!empty($room['RoomDescription'])) {
                $desc[$room_id] = $room['RoomDescription'];
            }
        }
    }
    return $desc;
}

function kv_bs_group_rooms(array $availableRooms): array
{
    $grouped = [];

    foreach ($availableRooms as $r) {

        $roomTypeId = (int) $r['RoomId'];

        $key = $r['RoomName'];

        if (!isset($grouped[$key])) {
            $grouped[$key] = $r;
            $grouped[$key]['ratePlans'] = [];
        }

        if( !empty( $r['ratePlan'] ) ){
            $grouped[$key]['ratePlans'][] = $r['ratePlan'];
        }
    }

    return $grouped;
}

/**
 * Get room availability from Booking System API
 * 
 * @param string $propertyId Property ID to query
 * @param string $checkIn Check-in date (format: d-M-Y)
 * @param string $checkOut Check-out date (format: d-M-Y)
 * @param int $guests Number of guests
 * @return array|WP_Error Array of properties or WP_Error on failure
 */
function kv_roomboss_get_availability(
    string $propertyId,
    string $checkIn,
    string $checkOut,
    int $guests
) {

    try {
        // ✅ STEP 1: Validate input parameters
        if (empty($propertyId)) {
            return new WP_Error(
                'invalid_property_id',
                'Property ID is required'
            );
        }

        if (empty($checkIn) || empty($checkOut)) {
            return new WP_Error(
                'invalid_dates',
                'Check-in and check-out dates are required'
            );
        }

        // if ($guests < 1 || $guests > 20) {
        //     return new WP_Error(
        //         'invalid_guest_count',
        //         'Guest count must be between 1 and 20'
        //     );
        // }

        // ✅ STEP 2: Get property details
        $resort_id = get_resort_id_by_property_id($propertyId);

        if (empty($resort_id)) {
            return new WP_Error(
                'resort_not_found',
                'Resort ID not found for property: ' . $propertyId
            );
        }

        // ✅ STEP 3: Calculate duration
        $duration = get_duration_from_date($checkIn, $checkOut);

        if ($duration < 1) {
            return new WP_Error(
                'invalid_date_range',
                'Stay duration must be at least 1 day'
            );
        }

        // ✅ STEP 4: Build booking system API arguments
        $args = [
            'start_date' => $checkIn,
            'resortId' => intval($resort_id),
            'end_date' => $checkOut,
            'channel' => true,
            'bedBank' => true,
            'duration' => $duration,
            'maxPersons' => $guests,
            'propertyIds' => [intval($propertyId)],
            'adults' => [$guests],
        ];

        // ✅ STEP 5: Build API request
        $url = KV_BOOKING_SYSTEM_BASE . '/api/quotation-filteration';
        $bs_args = kv_booking_system_filter_args(KV_BS_authToken, $args);

        if (!$bs_args) {
            return new WP_Error(
                'invalid_request_args',
                'Failed to build booking system request arguments'
            );
        }

        // ✅ STEP 6: Make API request
        $response = wp_remote_get($url, $bs_args);

        if (is_wp_error($response)) {
            return new WP_Error(
                'api_request_failed',
                'Failed to connect to booking system: ' . $response->get_error_message()
            );
        }

        // ✅ STEP 7: Validate HTTP response code
        $http_code = wp_remote_retrieve_response_code($response);

        if ($http_code !== 200) {
            return new WP_Error(
                'api_error',
                'Booking system returned HTTP ' . $http_code
            );
        }

        // ✅ STEP 8: Parse response body
        $response_body = wp_remote_retrieve_body($response);

        if (empty($response_body)) {
            return new WP_Error(
                'empty_response',
                'Booking system returned empty response'
            );
        }

        $body = json_decode($response_body, true);
        // pre($body);

        if (!is_array($body)) {
            return new WP_Error(
                'invalid_json',
                'Booking system returned invalid JSON'
            );
        }

        // ✅ STEP 9: Validate and extract properties
        if (empty($body['properties']) || !is_array($body['properties'])) {
            return [];
        }

        // ✅ STEP 10: Return properties array
        return $body['properties'];

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return new WP_Error(
            'unexpected_error',
            'Error retrieving availability: ' . $e->getMessage()
        );
    }
}

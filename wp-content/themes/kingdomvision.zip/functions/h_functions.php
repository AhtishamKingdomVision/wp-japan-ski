<?php
function hz_js_to_enque()
{

    wp_register_style('jquery-ui', '//code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css', false, '1.11.3');

    // slick-carousel
    wp_register_style('slick-carousel', '//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css', false);
    wp_enqueue_style('slick-carousel');
    wp_register_script('slick-carousel', '//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), true);
    wp_enqueue_script('slick-carousel');

    // ion.rangeSlider
    wp_register_style('ion-rangeSlider-styles', get_template_directory_uri() . '/ion.rangeSlider-master/css/ion.rangeSlider.css?v=' . filemtime(get_template_directory() . '/ion.rangeSlider-master/css/ion.rangeSlider.css'), false);
    wp_enqueue_style('ion-rangeSlider-styles');
    wp_register_script('ion-rangeSlider-scripts', get_template_directory_uri() . '/ion.rangeSlider-master/js/ion.rangeSlider.js?v=' . filemtime(get_template_directory() . '/ion.rangeSlider-master/js/ion.rangeSlider.js'),  array('jquery'), false);
    wp_enqueue_script('ion-rangeSlider-scripts');

    // Date Dropper
    wp_register_script('datedropper_en', get_template_directory_uri() . '/js/datedropper.min.js', array('jquery', 'kv-script'), '1.0', true);

    wp_enqueue_script('datedropper_en');
    wp_enqueue_style('air_datepicker', '//cdn.jsdelivr.net/npm/air-datepicker@3.3.5/air-datepicker.min.css', false, '3.3.5');
    wp_enqueue_script('air_datepicker', '//cdn.jsdelivr.net/npm/air-datepicker@3.3.5/air-datepicker.min.js', array('jquery', 'kv-script', 'wp-util'), '3.3.5', true);

    if ( is_page( 'confirm-booking' ) ) {
        /*flywire*/
        wp_register_script('flywire', 'https://checkout.flywire.com/flywire-payment.js', array(), null, true);
        wp_enqueue_script('flywire');

        /*flywire SDK*/
        wp_register_script('flywire-sandbox', 'https://artifacts.flywire.com/sdk/js/v0/sandbox.main.js', array(), null, true);
        wp_enqueue_script('flywire-sandbox');
    }

    // isotope
    wp_enqueue_script('isotope', 'https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js', array('jquery'), '3.3.5', true);

    // essentials used in kv-script are here
    wp_register_script('hz-essentials', 'https://cdn.jsdelivr.net/gh/HumzaKV/hz_essentials@main/essentials.js', [], false, false);
    wp_enqueue_script('hz-essentials');

    wp_register_script('js-cookies', 'https://cdn.jsdelivr.net/npm/js-cookie@3.0.5/dist/js.cookie.min.js', array(), false, true);
    wp_enqueue_script('js-cookies');

    if (
        wp_script_is('kv-script', 'registered') ||
        wp_script_is('kv-script', 'enqueued')
    ) {
        // die( 'script found' );
        $weekStartDate = get_field('check_start_date', 'option');
        $weekEndDate = get_field('check_end_date', 'option');
        $minDaysOption = get_field('check_min_days_option', 'option');
        $dateDropperContent = get_field('date_dropper_content', 'option');
        $minDays = get_field('check_min_days', 'option');

        $weekStartDate_in_time = strtotime($weekStartDate);
        $weekEndDate_in_time = strtotime($weekEndDate);
        $current_date_in_time = strtotime(date("F j, Y"));

        if ($current_date_in_time > $weekStartDate_in_time) {
            $weekStartDate = date("F j, Y");
        }

        if ($current_date_in_time > $weekEndDate_in_time) {
            $weekEndDate = date('F j, Y"', strtotime('+6 months')); /*6 month ahead of current date*/
        }
        $max_price = get_acc_price('max');
        $min_price = get_acc_price('min');
        wp_localize_script(
            'kv-script',
            'kv_object',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'check_start_date' => $weekStartDate,
                'current_date_in_time' => $current_date_in_time,
                'weekStartDate_in_time' => $weekStartDate_in_time,
                'check_end_date' => $weekEndDate,
                'check_min_days_option' => $minDaysOption,
                'check_min_days' => $minDays,
                'range_values' => ['min_price' => $min_price, 'max_price' => $max_price],
                'date_dropper_content' => !empty($dateDropperContent) ? $dateDropperContent : false,
            )
        );
    }
    // else{
    //     die ( 'script not found' );
    // }

}

function get_acc_price($key = 'max', $term_slug = '')
{
    global $wpdb;
    $prefix = $wpdb->prefix;

    // Sanitize the aggregation type (only allow min or max)
    $key = strtolower($key) === 'min' ? 'MIN' : 'MAX';

    // Base SQL with taxonomy join
    $query = "
    SELECT {$key}(CAST(pm.meta_value AS DECIMAL(10,2))) 
    FROM {$prefix}postmeta pm
    INNER JOIN {$prefix}posts p ON pm.post_id = p.ID
    INNER JOIN {$prefix}term_relationships tr ON p.ID = tr.object_id
    INNER JOIN {$prefix}term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
    INNER JOIN {$prefix}terms t ON tt.term_id = t.term_id
    WHERE pm.meta_key = 'min_room_price'
    AND pm.meta_value > 0
    AND p.post_type = 'accommodation'
    AND p.post_status = 'publish'
    AND tt.taxonomy = 'accommodation-cat'
    ";

    // Add term slug condition if provided
    $params = [];
    if (! empty($term_slug)) {
        $query .= " AND t.slug = %s";
        $params[] = $term_slug;
    }

    // Prepare query if term is provided
    if (! empty($params)) {
        $prepared_query = $wpdb->prepare($query, ...$params);
    } else {
        $prepared_query = $query;
    }

    // Execute and return float value
    return (float) $wpdb->get_var($prepared_query);
}

add_action('wp_enqueue_scripts', 'hz_js_to_enque');

function sync_custom_functions_file()
{
    $file_url = 'https://raw.githubusercontent.com/HumzaKV/hz_essentials/main/essentials.php';
    $theme_dir = get_stylesheet_directory();
    $target_file = $theme_dir . '/functions/essentials.php';
    if (!file_exists($target_file)) {
        file_put_contents($target_file, '<?php // Version:0.0.0');
    }

    $remote_response = wp_remote_get($file_url);
    if (is_wp_error($remote_response)) return;
    $remote_code = wp_remote_retrieve_body($remote_response);
    if (empty($remote_code)) return;
    // Get remote version
    preg_match('/Version:\s*([\d.]+)/i', $remote_code, $remote_matches);
    $remote_version = $remote_matches[1] ?? null;
    // cf_log( 'remote_version', 'version_log' );
    // cf_log( $remote_version, 'version_log' );
    // Get local version (if exists)
    $local_version = null;
    if (file_exists($target_file)) {
        $local_code = file_get_contents($target_file);
        preg_match('/Version:\s*([\d.]+)/i', $local_code, $local_matches);
        $local_version = $local_matches[1] ?? null;
    }
    // cf_log( 'local_version', 'version_log' );
    // cf_log( $local_version, 'version_log' );
    // Update only if remote version is newer
    if ($remote_version && $remote_version !== $local_version) {
        // file_put_contents( $target_file, $remote_code );
        $myfile = file_put_contents($target_file, (string) $remote_code . PHP_EOL);
    }
    if (file_exists($target_file)) {
        require_once $target_file;
    }
}
add_action('init', 'sync_custom_functions_file');

function booking_sys_api_args()
{

    $args = array(
        'method'      => 'POST',
        'timeout'     => 120, // Default is often 5, 45 is safer for external APIs
        'redirection' => 5,
        'httpversion' => '1.1',
        'headers'     => array(
            'Authorization' => 'Bearer '.KV_BS_authToken,
        ),
        'body'        => array(), // Add any POST fields here if needed
        'cookies'     => array(),
    );
    return $args;
}

add_action('init', 'kv_accommodation');
function kv_accommodation()
{
    $labels = array(
        'name' => _x('Accommodation', 'post type general name', 'kv_theme'),
        'singular_name' => _x('Accommodation', 'post type singular name', 'kv_theme'),
        'menu_name' => _x('Accommodation', 'admin menu', 'kv_theme'),
        'name_admin_bar' => _x('Accommodation', 'add new on admin bar', 'kv_theme'),
        'add_new' => _x('Add Accommodation', 'event', 'kv_theme'),
        'add_new_item' => __('Add Accommodation', 'kv_theme'),
        'new_item' => __('New Accommodation', 'kv_theme'),
        'edit_item' => __('Edit Accommodation', 'kv_theme'),
        'view_item' => __('View Accommodation', 'kv_theme'),
        'all_items' => __('All Accommodation', 'kv_theme'),
        'search_items' => __('Search Accommodation', 'kv_theme'),
        'parent_item_colon' => __('Parent Accommodation:', 'kv_theme'),
        'not_found' => __('No Accommodations found.', 'kv_theme'),
        'not_found_in_trash' => __('No Accommodations found in Trash.', 'kv_theme'),
    );

    $args = array(
        'labels' => $labels,
        'description' => __('Description.', 'kv_theme'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        //        'rewrite' => array('slug' => 'accommodation'),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'show_admin_column' => true,
        'menu_position' => null,
        'menu_icon' => 'dashicons-tickets-alt',
        'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'page-attributes'),
        'rewrite' => false,
        // 'rewrite' => array(
        //     'slug'       => 'accommodation',
        //     'with_front' => false,
        // ),
    );

    register_post_type('accommodation', $args);

    register_taxonomy(
        'accommodation-cat',
        'accommodation',
        array(
            'label' => __('Accommodation Categories'),
            'show_admin_column' => true,
            'rewrite' => array(
                'slug'       => 'accommodation-cat',
                'with_front' => false,
            ),
            'hierarchical' => true,
        )
    );
}

add_action('init', 'jp_room_post_type');

add_filter('post_type_link', 'hz_update_acc_link', 10, 2);

// function hz_update_acc_link ($permalink, $post) {

//     if ($post->post_type !== 'accommodation') {
//         return $permalink;
//     }

//     $terms = wp_get_post_terms($post->ID, 'accommodation-cat');

//     if (!empty($terms) && !is_wp_error($terms)) {
//         return home_url(
//             trailingslashit($terms[0]->slug) . 'accommodation/' . $post->post_name
//         );
//     }

//     return $permalink;

// }

function hz_update_acc_link($permalink, $post)
{

    if ($post->post_type !== 'accommodation') {
        return $permalink;
    }

    $terms = wp_get_post_terms($post->ID, 'accommodation-cat');

    if (empty($terms) || is_wp_error($terms)) {
        return $permalink;
    }

    // Take first term (or apply your own priority logic)
    $term_slug = $terms[0]->slug;

    // Remove "-accommodation"
    $location = str_replace('-accommodation', '', $term_slug);

    return home_url("/{$location}/accommodation/{$post->post_name}/");
}

// add_action('init', 'hz_accommodation_rewrite_rules');

function hz_accommodation_rewrite_rules()
{

    // add_rewrite_rule(
    //     '^([^/]+)/accommodation/([^/]+)/?$',
    //     'index.php?post_type=accommodation&name=$matches[2]&accommodation-cat=$matches[1]',
    //     'bottom'
    // );

    add_rewrite_rule(
        '^([^/]+)/accommodation/([^/]+)/?$',
        'index.php?post_type=accommodation&name=$matches[2]',
        'top'
    );
}

add_action('parse_request', 'parse_req_func');

function parse_req_func($wp)
{

    if (empty($wp->request)) {
        return;
    }

    $parts = explode('/', trim($wp->request, '/'));

    // Expect: {location}/accommodation/{slug}
    if (count($parts) !== 3) {
        return;
    }

    if ($parts[1] !== 'accommodation') {
        return;
    }

    // If a PAGE exists, let WP handle it
    $page = get_page_by_path($wp->request);
    if ($page) {
        return;
    }

    // Otherwise treat as accommodation CPT
    $wp->query_vars = [
        'post_type' => 'accommodation',
        'name'      => $parts[2],
    ];
}

add_filter('get_canonical_url', 'acc_canonical_url', 10, 2);

function acc_canonical_url($canonical, $post)
{

    if ($post && $post->post_type === 'accommodation') {
        return get_permalink($post);
    }

    return $canonical;
}

function jp_room_post_type()
{
    register_post_type('japan_rooms', array(
        'labels' => array(
            'name' => __('Japan Rooms'),
            'singular_name' => __('Japan Room'),
        ),
        'supports' => array(
            'title',
            'editor',
            'author',
            'thumbnail',
            'revisions',
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-admin-home',
        'taxonomies' => array('categories'),
    ));
}

function get_rooms_custom_field_values($rooms, $meta_key)
{

    $results = [];
    foreach ($rooms as $key => $room) {
        $room_id = $room->ID;
        $results[] = get_post_meta($room_id, $meta_key, true);
    }

    return $results; // array of values
}

add_filter('manage_japan_rooms_posts_columns', 'manage_japan_rooms_columns');

function manage_japan_rooms_columns($columns) {

    $columns['roomboss'] = 'RoomBoss';

    return $columns;
}

add_action('manage_japan_rooms_posts_custom_column', 'manage_japan_rooms_columns_values', 10, 2);

function manage_japan_rooms_columns_values($column, $post_id) {

    if ($column === 'roomboss') {
        echo get_post_meta($post_id, 'is_roomboss', true) ? 'true': 'false';
    }

}

function _currency_format_new($value, $symbol = false, $decimals = 0)
{
    $numbers = (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT);
    $str_chr = preg_replace('/[^a-zA-Z-_\.+*#]/', '', $value);

    $stnr = '';
    $nfr = number_format_i18n($numbers, $decimals);
    if (!empty($str_chr))
        $stnr =  $nfr . $str_chr;
    else
        $stnr = $nfr;
    return ($symbol) ? '¥' . $stnr : $stnr;
}

function get_post_by_title($title, $post_type = 'post')
{
    $args = array(
        // 's'                 => $title,
        'post_type'         => $post_type,
        'title'             => $title,
        'post_status'       => 'any',
        'numberposts'       => -1,
    );
    $posts = get_posts($args);
    if ($posts) {
        return $posts[0] ?? [];
    } else {
        return null;
    }
}

function get_rooms_by_property_id($property_id)
{
    $args = array(
        'post_type' => 'japan_rooms',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            'relation' => 'AND',
            array(
                'key' => 'property_id',
                'value' => $property_id,
            ),
        ),
    );
    $room = get_posts($args);

    return $room ? $room : [];
}

function get_hotels_by_hotel_id($hotel_id)
{
    $args = array(
        'post_type' => 'accommodation',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            'relation' => 'AND',
            array(
                'key' => 'acc_hotel_id',
                'value' => $hotel_id,
            ),
        ),
    );
    $hotel = get_posts($args);

    return $hotel ? $hotel[0] : [];
}

/**
 * Get post ID by type ID (property_id or room_id)
 * 
 * @param string|int $typeID The property_id or room_id to search for
 * @param string $type Type of post to search ('accommodation' or 'room')
 * @return int Post ID if found, 0 if not found
 */
function get_post_id_by_typeId($typeID, $type = '')
{
    try {
        // ✅ STEP 1: Validate input parameters
        if (empty($typeID)) {
            return 0;
        }

        // Sanitize and validate typeID
        $typeID = is_numeric($typeID) ? intval($typeID) : sanitize_text_field($typeID);
        
        if (empty($typeID)) {
            return 0;
        }

        // ✅ STEP 2: Validate and map post type
        $type = sanitize_text_field($type);
        // pre('typeID: ' . $typeID);
        // pre('type: ' . $type);

        if ($type === 'accommodation') {
            $meta_key = " pm.meta_key = 'property_id' ";
            $post_type = 'accommodation';
        } elseif ($type === 'room') {
            $meta_key = " pm.meta_key IN ('room_type_id', 'room_id') "; // room_type_id, room_id
            $post_type = 'japan_rooms';
        } else {
            return 0; // Invalid type
        }

        // ✅ STEP 3: Query database for post
        global $wpdb;

        $query = $wpdb->prepare(
            "SELECT pm.post_id
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_value = %s
               AND $meta_key
               AND p.post_status = 'publish'
               AND p.post_type = %s
             LIMIT 1",
            $typeID,
            $post_type
        );
        // pre('query: ' . $query);

        $post_id = $wpdb->get_var($query);
        // pre('post_id: ' . $post_id);

        // ✅ STEP 4: Return post ID or 0
        return $post_id ? intval($post_id) : 0;

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return 0;
    }
}


add_action("wp_ajax_roomboss_search", "hz_get_roomboss_data");
add_action("wp_ajax_nopriv_roomboss_search", "hz_get_roomboss_data");

function hz_get_roomboss_data()
{

    parse_str($_POST['data'], $formData);
    // Example: access submitted values
    $hotelId = '';
    $total_pages = 0;
    $type_acc = isset($formData['type_acc']) ? sanitize_text_field($formData['type_acc']) : '';
    $type_val = isset($formData['type_val']) ? sanitize_text_field($formData['type_val']) : '';
    $offset    = sanitize_text_field($formData['offset']);
    $limit     = sanitize_text_field($formData['limit']);
    $start_date = !empty($formData['checkIn']) ? sanitize_text_field($formData['checkIn']) : date('d-M-Y', strtotime('1 March'));
    $end_date  = !empty($formData['checkOut']) ? sanitize_text_field($formData['checkOut']) : date('d-M-Y', strtotime('5 March'));
    // $start_date = new DateTime('20-Mar-2026');
    // $end_date = new DateTime('26-Mar-2026');

    // Calculate the difference between the two dates
    // $duration = $start_date->diff($end_date);
    $checkIn = date('Ymd', strtotime($start_date));
    $checkOut = date('Ymd', strtotime($end_date));
    $ski = isset($formData['ski']) ? sanitize_text_field($formData['ski']) : '';

    if (isset($formData['selcted_room'])) {
        $selcted_room = $formData['selcted_room'];
    }

    $price_range = $formData['price_range_value'];
    $prices = explode('-', $price_range);
    $guests = (int)sanitize_text_field($formData['guests']);

    $get_all = sanitize_text_field($formData['get_all']);

    $get_acc = [];

    if (!empty($start_date) && !empty($end_date)) {

        if ($get_all == 'no') {

            if ($type_acc == 'hotel') {
                $hotelId = 'hotelId=' . $type_val;
                $total_pages = 1;
            } else if ($type_acc == 'destination') {
                $category = strtolower(str_replace(' ', '-', $type_val));
                $destination = strtoupper(str_replace(' Accommodation', '', $type_val));
                $args = [
                    'post_type'      => 'accommodation',
                    'post_status'    => 'publish',
                    'fields'         => 'ids',              // return only post IDs
                    'paged'          => $offset,            // page_number
                    'orderby'        => 'title',            // Sort by price first, then title
                    'order'          => 'ASC',
                    'posts_per_page' => 9,
                ];

                if (!empty($selcted_room)) {

                    $bedrooms = array_filter(array_map('intval', explode(',', $selcted_room)));

                    if (!empty($bedrooms)) {

                        // Create the OR relation for multiple bedroom numbers
                        $bedroom_meta = ['relation' => 'OR'];

                        foreach ($bedrooms as $num) {
                            $bedroom_meta[] = [
                                'key'     => 'bedroom_number',
                                'value'   => 'i:' . $num . ';',
                                'compare' => 'LIKE',
                            ];
                        }

                        // Merge with price query (AND relation)
                        $args['meta_query'] = [
                            'relation' => 'AND',
                            [
                                'key'     => 'min_room_price',
                                'value'   => [intval($prices[0]), intval($prices[1])],
                                'compare' => 'BETWEEN',
                                'type'    => 'NUMERIC',
                            ],
                            $bedroom_meta,
                        ];
                    }
                } else {
                    // No bedrooms selected — use only price filter
                    $args['meta_query'] = [
                        'relation' => 'AND',
                        [
                            'key'     => 'min_room_price',
                            'value'   => [intval($prices[0]), intval($prices[1])],
                            'compare' => 'BETWEEN',
                            'type'    => 'NUMERIC',
                        ],
                    ];
                }

                if (! empty($ski) && $ski === 'yes') {
                    $args['meta_query'][] = [
                        // [
                        'key'     => 'area',
                        'value'   => 's:14:"Ski In Ski Out"',
                        'compare' => 'LIKE',
                        // ]
                    ];
                }

                if (!empty($category)) {
                    $args['tax_query'] = [
                        [
                            'taxonomy' => 'accommodation-cat',
                            'field'    => 'slug',   // you can also use 'term_id'
                            'terms'    => $category,
                        ],
                    ];
                }

                $get_acc = new WP_Query($args);
                $total_pages = $get_acc->max_num_pages;
                $des_ids = $get_acc->get_posts();

                $format_ids = array_map(function ($post_id) {
                    return 'hotelId=' . get_field('acc_hotel_id', $post_id);
                }, $des_ids);

                $hotelId = implode('&', $format_ids);
            }
        }

        if (empty($hotelId)) {
            return wp_send_json_error(['data' => 'No records were found for the cuurent criteria. Change the criteria and try again', 'total' => $total_pages, 'images' => []]);
        }

        $response = hz_get_limited_available_hotels($hotelId, $checkIn, $checkOut, $guests);

        $status = $response['status'];

        if ($status == 'success') {
            $hotels = $response['response'];
            $hotel_tids = '';
            $hotel_tids_str = '';

            $acc_html = '';

            if (!empty($hotels)) {

                foreach ($hotels as $key => $hotel) {
                    $hotel_title = $hotel['hotelName'];
                    $hotel_tid = $hotel['hotelId'];
                    $hotel_desc = $hotel['PropertyDescription'] ?? '';
                    $cleaned_desc = strip_tags($hotel_desc, '<p>');
                    $trim_cleaned_desc = wp_trim_words($hotel_desc, 11);


                    $accomodation = get_hotels_by_hotel_id($hotel_tid);
                    $acc_id = $accomodation->ID;
                    $acc_url = get_the_permalink($acc_id);
                    $img_url = has_post_thumbnail($acc_id) ? get_the_post_thumbnail_url($acc_id) : get_attachment_link(43404);

                    $hotel_tids .= 'hotelId=' . $hotel_tid . '&';

                    $roomTypes = $hotel['availableRoomTypes'];
                    $get_min_room_price = get_hotel_min_room_price($roomTypes);

                    $resort = '';
                    $terms = get_the_terms($acc_id, 'accommodation-cat');
                    $term_name = $terms[0]->name;
                    $resort = explode(' ', $term_name)[0];

                    $acc_html .= '<div class="listing_box" data-hotel-id="' . esc_attr($hotel_tid) . '" data-acc-id="' . esc_attr($acc_id) . '">';
                    // $acc_html .= '<a href="'.$acc_url.'?start_date='.$start_date.'&end_date='.$end_date.'&guests='.$guests.'&resortId='.$resortId.'">';
                    $acc_html .= '<div class="listing_box_img">';
                    $acc_html .= '<img class="acc_img" src="' . $img_url . '" alt="hero01"/>';
                    $acc_html .= '</div>'; // .listing_box_img

                    // if( is_int( $get_min_room_price ) ){

                    //     update_post_meta( $acc_id, 'min_room_price', $get_min_room_price );
                    // }

                    $acc_html .= '<div class="listing_cont">';
                    $acc_html .= '<div class="acc_title"> <h3>' . $hotel_title . '</h3> </div>';
                    $acc_html .= '<div class="acc_min_price"><p>From: ' . _currency_format_new($get_min_room_price, true) . '</p> /night</div>';
                    $acc_html .= '<div class="acc_short_esc">';
                    $acc_html .= '<p class="short_desc_text">';
                    $content = get_the_content($acc_id);
                    if (! empty($content)) {

                        $acc_html .= esc_html(wp_trim_words(wp_strip_all_tags($content), 20, '...'));
                    }
                    $acc_html .= '</p>';
                    $acc_html .= '</div>';
                    $acc_html .= '<div class="acc_buttons" data-post_id="' . $acc_id . '" data-redirect="' . $acc_url . '" data-params="start_date=' . $start_date . '&end_date=' . $end_date . '&guests=' . $guests . '&resort=' . $resort . '&check_rates=yes">
                    <div class="view_book">
                    <button class="view_book_btn">View and Book</button>
                    </div>
                    </div>';
                    $acc_html .= '</div>'; // .listing_cont

                    // $acc_html .= '<span>View More</span>';
                    $acc_html .= '</div>'; // .listing_box

                } /*end foreach*/

                $img_args = booking_sys_api_args();

                $imgapiUrl = 'https://api.roomboss.com/extws/hotel/v1/listImage?' . $hotel_tids;
                $img_res = wp_remote_get($imgapiUrl, $img_args);

                $img_arr = [];

                if (is_array($img_res) && ! is_wp_error($img_res)) {

                    $img_resBody = wp_remote_retrieve_body($img_res);
                    $img_result = json_decode($img_resBody, true);
                    // cf_log( $img_result, 'img_result_res' );
                    $img_hotels = $img_result['hotels'];

                    foreach ($img_hotels as $key => $img_hotel) {
                        $hotelId = $img_hotel['hotelId'];
                        $hotelImages = $img_hotel['hotelImages'];
                        $img_arr[$hotelId] = $hotelImages[array_key_first($hotelImages)];
                    }/*end foreach img_hotels*/

                    if (!empty($img_resBody['failureMessage'])) return $img_resBody['failureMessage'];

                    if (empty($img_hotels)) return 'No hotels were found for the provided hotel ID';
                }/*end is_array( $img_res )*/ else if (is_wp_error($img_res)) {
                    cf_log($img_res->get_error_message(), 'img_api_err');
                }/*end is_wp_error( $img_res )*/
                return wp_send_json_success(['data' => $acc_html, 'total' => $total_pages, 'images' => $img_arr]);
            } elseif (empty($hotels)) {
                return wp_send_json_success(['data' => '', 'total' => $total_pages, 'images' => []]);
            }
        }
    } else if (empty($start_date) || empty($end_date)) {

        $args = [
            'post_type'      => 'accommodation',
            'post_status'    => 'publish',
            'posts_per_page' => 9,
            'paged'          => $offset,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'meta_query'     => [],
        ];

        if (!empty($formData['price_range_value'])) {

            $price_range =
                [
                    'key'     => 'min_room_price',
                    'value'   => [intval($prices[0]), intval($prices[1])],
                    'compare' => 'BETWEEN',
                    'type'    => 'NUMERIC',
                ];

            $args['meta_query'][] = $price_range;
        }

        // 🛏️ Add bedroom filter if user selected rooms
        if (!empty($formData['selcted_room'])) {
            $bedrooms = array_filter(array_map('intval', explode(',', $formData['selcted_room'])));
            if (!empty($bedrooms)) {
                $bedroom_meta = ['relation' => 'OR'];
                foreach ($bedrooms as $num) {
                    $bedroom_meta[] = [
                        'key'     => 'bedroom_number',
                        'value'   => 'i:' . $num . ';',
                        'compare' => 'LIKE',
                    ];
                }
                $args['meta_query'][] = $bedroom_meta;
            }
        }

        // 🎿 Add Ski In Ski Out filter (checkbox)
        if (!empty($ski) && $ski === 'yes') {
            $args['meta_query'][] = [
                'key'     => 'area',
                'value'   => 's:14:"Ski In Ski Out"',
                'compare' => 'LIKE',
            ];
        }

        // 🏨 1️⃣ Type = hotel
        if ($type_acc === 'hotel' && !empty($type_val)) {
            $args['meta_query'][] = [
                'key'     => 'acc_hotel_id',
                'value'   => $type_val,
                'compare' => '=',
            ];
        }

        // 🌍 2️⃣ Type = destination (taxonomy)
        elseif ($type_acc === 'destination' && !empty($type_val)) {
            $category = strtolower(str_replace(' ', '-', $type_val));
            $args['tax_query'] = [
                [
                    'taxonomy' => 'accommodation-cat',
                    'field'    => 'slug',
                    'terms'    => $category,
                ],
            ];
        }

        $query = new WP_Query($args);

        if (!$query->have_posts()) {
            return wp_send_json_error([
                'data'   => 'No accommodations found for current criteria.',
                'total'  => 0,
                'images' => [],
            ]);
        }

        // 🧱 Build HTML
        $html = '';
        while ($query->have_posts()) {
            $query->the_post();
            $acc_id = get_the_ID();
            $hotel_tid = get_field('acc_hotel_id', $acc_id);
            $acc_url = get_permalink();
            $title = get_the_title();
            $desc = wp_trim_words(strip_tags(get_the_content()), 20);
            $get_min_room_price = get_field('min_room_price', $acc_id);
            $img_url = has_post_thumbnail() ? get_the_post_thumbnail_url($acc_id, 'medium') : get_attachment_link(43404);

            $html .= '<div class="listing_box" data-hotel-id="' . esc_attr($hotel_tid) . '" data-acc-id="' . esc_attr($acc_id) . '">';
            $html .= '<div class="listing_box_img"><img class="acc_img" src="' . $img_url . '" alt="hero01"/></div>';
            $html .= '<div class="listing_cont">';
            $html .= '<div class="acc_title"> <h3>' . $title . '</h3> </div>';
            $html .= '<div class="acc_min_price"><p>From: ' . _currency_format_new($get_min_room_price, true) . '</p> /night</div>';
            $html .= '<div class="short_esc">';
            $html .= '<p class="short_desc_text">';
            $content = get_the_content(get_the_ID());
            if (! empty($content)) {

                $html .= esc_html(wp_trim_words(wp_strip_all_tags($content), 20, '...'));
            }
            $html .= '</p>';
            $html .= '</div>';
            $html .= '<div class="acc_buttons" data-post_id="' . $acc_id . '" data-redirect="' . $acc_url . '" data-params="start_date=' . $start_date . '&end_date=' . $end_date . '&guests=' . $guests . '&resort=' . $resort . '">
            <div class="view_book">
            <button class="view_book_btn">View and Book</button>
            </div>
            </div>';

            $html .= '</div>'; /*listing_cont*/
            $html .= '</div>'; // .listing_box
        }
        wp_reset_postdata();

        return wp_send_json_success([
            'data'   => $html,
            'total'  => $query->max_num_pages,
            'images' => [],
        ]);
    }
}

function get_hotel_min_room_price($rooms, $key = 'min')
{

    if (empty($rooms)) return;

    if (is_array($rooms) && !empty($rooms)) {
        // $room_prices = wp_list_pluck( $rooms, 'ratePlan' );
        $room_prices = [];


        foreach ($rooms as $room_key => $room) {
            $room_prices[] = $room['ratePlan']['priceRetail'] ?? 0;
        }
        asort($room_prices, SORT_NUMERIC);
        $min_val_key = array_key_first($room_prices);
        $max_val_key = array_key_last($room_prices);

        $val_key = $key == 'min' ? $min_val_key : $max_val_key;
        $room_price = $room_prices[$val_key] ?? 0;
        return $room_price;
    }
}

function get_hotel_num_bedrooms($rooms)
{
    if (empty($rooms)) return;
    if (is_array($rooms) && !empty($rooms)) {
        $bedrooms = wp_list_pluck($rooms, 'no_of_bedrooms');
        asort($bedrooms, SORT_NUMERIC);
        return $bedrooms;
    }
}

function hz_get_term_id_by_resort_id($resort_id) {

    $terms = get_terms([
        'taxonomy'   => 'accommodation-cat',
        'hide_empty' => false,
        'meta_query' => [
            [
                'key'     => 'bs_resort_id',
                'value'   => $resort_id,
                'compare' => '='
            ]
        ]
    ]);

    return (!is_wp_error($terms) && !empty($terms)) ? $terms[0]->term_id : null;
}

// add images from room boss api
function hz_add_img_from_booking_sys($images, $post_id, $type){

    if( @$_GET['test'] == 'yes' ){
        if( empty($images) || !is_array($images) ) pre( 'no images' );
    }

    if( empty($images) || !is_array($images) ) return;

    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    if( $type == 'accommodation' ){

        $old_thumbnail_deleted = false;
        /* --- Add new images --- */
        $gallery_ids = [];

        foreach ($images as $index => $image) {

            /* --- Remove existing featured image --- */
            $old_thumb_id = get_post_thumbnail_id($post_id);
            if( @$_GET['test'] == 'yes' ){
                pre( 'Old thumbnail ID: ' . $old_thumb_id );
            }
            if ($old_thumb_id && ! $old_thumbnail_deleted === false) {

                wp_delete_attachment($old_thumb_id, true);
                delete_post_thumbnail($post_id);
                if( @$_GET['test'] == 'yes' ){

                    pre( 'Old thumbnail deleted with ID: ' . $old_thumb_id );
                }
                $old_thumbnail_deleted = true;
            }

            /* --- Remove existing gallery images --- */
            $old_gallery = get_field('acco_image_gallery', $post_id);

            if (!empty($old_gallery)) {
                foreach ($old_gallery as $att_id) {
                    wp_delete_attachment($att_id, true);

                    if( @$_GET['test'] == 'yes' ){
                        pre( 'Old gallery image deleted with ID: ' . $att_id );
                    }
                }
            }

            // Clear gallery field
            update_field('acco_image_gallery', [], $post_id);

            $image_url   = $image['url'];
            if( @$_GET['test'] == 'yes' ){
                pre( 'img_url' );
                pre( $image_url );
            }

            $attachment_id = media_sideload_image(
                $image_url,
                $post_id,
                null,
                'id'
            );

            if( @$_GET['test'] == 'yes' ){
                pre( 'attachment_id' );
                pre( $attachment_id );
            }

            if (is_wp_error($attachment_id)) {
                continue;
            }

            // First image → Featured
            if ($index === array_key_first($images)) {

                set_post_thumbnail($post_id, $attachment_id);
                update_post_meta($post_id, 'accommodation_list_image', $attachment_id);

                if( @$_GET['test'] == 'yes' ){
                   pre( 'Featured image set with ID: ' . $attachment_id );
                }

            } else {
                $gallery_ids[] = $attachment_id;
                
                if( @$_GET['test'] == 'yes' ){
                    pre( 'Gallery image added with ID: ' . $attachment_id );
                }

            }
        }

        if (! empty($gallery_ids)) {
            if( @$_GET['test'] == 'yes' ){
                pre( 'Updating accommodation gallery with IDs: ' . implode(', ', $gallery_ids) );
            }
            update_field('acco_image_gallery', $gallery_ids, $post_id);
        }
    }

    /*for room*/

    if( $type == 'room' ){

        $old_thumbnail_deleted = false;
        
        /* --- Add new room images --- */
        $room_gallery_ids   = [];

        foreach ($images as $index => $image) {

            /* --- Remove existing featured image --- */
            $old_room_thumb = get_post_thumbnail_id($post_id);
            if ( $old_room_thumb && !$old_thumbnail_deleted === false ) {
                
                if( @$_GET['test'] == 'yes' ){
                    pre( 'Old room thumbnail ID: ' . $old_room_thumb );
                }
                wp_delete_attachment($old_room_thumb, true);
                delete_post_thumbnail($post_id);
            
            }

            /* --- Remove existing gallery --- */
            $old_room_gallery = get_field('room_images', $post_id);

            if( !empty( $old_room_gallery ) ){

                if( @$_GET['test'] == 'yes' ){
                    pre( 'Old room gallery IDs: ' . implode(', ', $old_room_gallery) );
                }
                if (! empty($old_room_gallery)) {
                    foreach ($old_room_gallery as $att_id) {
                        if( @$_GET['test'] == 'yes' ){
                            pre( 'Deleting old room gallery image with ID: ' . $att_id );
                        }
                        wp_delete_attachment($att_id, true);
                    }
                }
            }

            update_field('room_images', [], $post_id);

            $image_url          = '';
            if (filter_var($image['url'], FILTER_VALIDATE_URL)) {
                $image_url      = $image['url'];
            }

            $attachment_id      = media_sideload_image(
                $image_url,
                $post_id,
                null,
                'id'
            );

            if (is_wp_error($attachment_id)) {
                continue;
            }

            if ($index === array_key_first($images)) {
                if( @$_GET['test'] == 'yes' ){
                    pre( 'Setting first image as room featured image with ID: ' . $attachment_id );
                }
                set_post_thumbnail($post_id, $attachment_id);
            
            } else {
                $room_gallery_ids[] = $attachment_id;
                if( @$_GET['test'] == 'yes' ){
                    pre( 'Adding image to room gallery with ID: ' . $attachment_id );
                }
            }
        }

        if (! empty($room_gallery_ids)) {
            update_field('room_images', $room_gallery_ids, $post_id);
            if( @$_GET['test'] == 'yes' ){
                pre( 'Room gallery field updated with new images' );
            }    
        }
    }

    return 'Images successfully refreshed for accommodations and rooms';
}

function hz_get_limited_properties($page = 1, $perPage = 1)
{

    $apiUrl = "https://trip.japanskiexperience.com/api/get-all-properties?page=$page&per_page=$perPage";

    $args = booking_sys_api_args(); // keep existing auth logic

    $response = wp_remote_post($apiUrl, $args);
    if (is_wp_error($response)) {
        cf_log($response->get_error_message(), 'err_api', 'txt', false, true);
        return false;
    }

    $result = json_decode( wp_remote_retrieve_body( $response ) , true );

    if (empty($result['properties'])) {
        return [
            'properties' => [],
            'total_pages' => 0,
            'pagination'  => []
        ];
    }

    return [
        'properties' => $result['properties'],
        'total_pages' => $result['pagination']['last_page'] ?? 1,
        'pagination'  => $result['pagination'] ?? []
    ];
}


function hz_get_limited_available_hotels($hotelId, $checkIn, $checkOut, $guests, $offset = 0, $limit = 5)
{

    $apiUrl = "https://api.roomboss.com/extws/hotel/v1/listAvailable?$hotelId&checkIn=$checkIn&checkOut=$checkOut&numberGuests=$guests&excludeConditionsNotMet=true&rate=ota";
    $args = booking_sys_api_args();
    // $apiUrl = 'https://api.roomboss.com/extws/hotel/v1/list?countryCode=jp&locationCode=HAKUBA';

    $response = wp_remote_get($apiUrl, $args);
    // cf_log( $response, 'res' );
    // cf_log( $response, 'chk_res', 'txt', true, true );
    if (is_array($response) && ! is_wp_error($response)) {
        $responseBody = wp_remote_retrieve_body($response);
        $result = json_decode($responseBody, true);
        $number_posts = $result['availableHotels'] ? count($result['availableHotels']) : 0;
        $hotels = array_slice($result['availableHotels'], $offset, $limit);

        return ['status' => 'success', 'response' => $hotels, 'number_posts' => $number_posts];
    } else if (is_wp_error($response)) {
        cf_log($response->get_error_message(), 'err_api', 'txt', false, true);
        return ['status' => 'fail', 'response' => $response->get_error_message(), 'number_posts' => $number_posts];
    }
}

@$_GET['test'] == 'yes' ? add_action('wp_head', 'testing') : '';
@$_GET['del_reviews'] == 'yes' ? add_action('wp_head', 'del_reviews') : '';
@$_GET['create_reviews'] == 'yes' ? add_action('wp_head', 'review_creation_func') : '';
@$_GET['chk_dup_reviews'] == 'yes' ? add_action('wp_head', 'chk_dup_reviews') : '';

function del_reviews(){
    $allposts = get_posts( array('post_type' => 'reviews', 'numberposts' => -1) );
    foreach ( $allposts as $eachpost ) {
        pre( 'deleting review '. $eachpost->ID );
        wp_delete_post( $eachpost->ID, true ); // Set to 'true' to bypass trash
        pre( 'deleted review '. $eachpost->ID );
    }
}

function chk_dup_reviews() {
    $allposts = get_posts(array('post_type' => 'reviews', 'numberposts' => -1));
    $store_ids = [];

    // Collect all store_review_id values with their post IDs
    foreach ($allposts as $eachpost) {
        pre( 'post id' );
        pre( $eachpost->ID );
        
        $store_id = get_field('store_review_id', $eachpost->ID);
        pre( 'store_review_id' );
        pre( $store_id );
    }
}

function testing(){
    // kv_cron_fetch_reviews_fn();
    hz_get_data_from_booking_sys_func();
}

/*to check if cron was causing issue*/
function review_creation_func(){
    global $wpdb;
    $store_id = 'japanskiexperience-com1';
    $api_key  = 'ae0427dc29a62e2320110a6c157bc45b';
    // $page     = get_option('reviews_page', 1 );
    $page     = 1;
    $per_page = 100;
    while ( true ) {
        $url = add_query_arg([
            'store'    => $store_id,
            'per_page' => $per_page,
            'page'     => $page,
        ], 'https://api.reviews.io/merchant/reviews');

        $response = wp_remote_get( $url, [
            'headers' => [
                'Content-Type' => 'application/json',
                'store'        => $store_id,
                'apikey'       => $api_key,
            ],
            'timeout' => 20,
        ]);

        if ( is_wp_error( $response ) ) {
            break;
        }
        pre( 'fetching page ' . $page );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body['reviews'] ) ) {
            $upd_page = $body['total_pages'] ?? 1;
            
            $prv_page = intval( $upd_page ) - 1;
            update_option( 'reviews_page', $prv_page, false ); // reset for next full sync
            
            pre( 'curr page' );
            pre( $body[ 'page' ] );

            pre( 'going to prev' );
            pre( $prv_page );

            break;
        }

        $upd_page = $body['total_pages'];
        update_option( 'reviews_page', $upd_page, false );

        pre( 'curr page' );
        pre( $body[ 'page' ] );

        pre( 'going to next' );
        pre( $upd_page );

        /*
         * Process reviews
         */
        foreach ( $body['reviews'] as $review ) {

            if ( empty( $review['store_review_id'] ) ) {
                continue;
            }
            pre( 'review' );
            pre( $review );
            // Prevent duplicates
            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = %s AND meta_value = %s LIMIT 1",
                    'store_review_id',
                    $review['store_review_id']
                )
            );

            pre( 'store_id' );
            pre( $review['store_review_id'] );

            pre( 'chk_duplicates' );
            pre( var_dump( $exists ) );
            if ( $exists ) {
                pre( 'post-id' );
                pre( $exists );
                continue;
            }


            pre( 'after exists check' );
            $author = trim(
                html_entity_decode(
                    ( $review['reviewer']['first_name'] ?? '' ) . ' ' .
                    ( $review['reviewer']['last_name'] ?? '' )
                )
            );

            $post_id = wp_insert_post([
                'post_title'   => sanitize_text_field( $author ?: 'Anonymous Review' ),
                'post_type'    => 'reviews',
                'post_status'  => 'publish',
                'post_content' => $review['comments'] ?? '',
            ]);

            pre( 'before validation' );
            pre( $post_id ); 

            if ( ! $post_id || is_wp_error( $post_id ) ) {
                continue;
            }
            pre( 'post created' );
            pre( $post_id );
            /*
             * Save meta
             */
            update_post_meta( $post_id, 'review_rating', (int) $review['rating'] );
            update_post_meta( $post_id, 'review_date', $review['date_created'] );
            update_post_meta( $post_id, 'store_review_id', $review['store_review_id'] );

            $posted_date = 'Posted ' . date( 'F Y', strtotime( $review['date_created'] ) );

            if ( function_exists( 'update_field' ) ) {
                update_field( 'posted_date', $posted_date, $post_id );
            } else {
                update_post_meta( $post_id, 'posted_date', $posted_date );
            }
            /*
             * Assign review tags → CPT taxonomy (slug: review_tags)
             */
            if ( ! empty( $review['tags'] ) && is_array( $review['tags'] ) ) {

                $tag_slugs = [];

                foreach ( $review['tags'] as $tag ) {
                    if ( ! empty( $tag['tag'] ) ) {
                        $tag_slugs[] = sanitize_title( $tag['tag'] );
                    }
                }

                pre( 'tags' );
                pre( $tag_slugs );
                
                pre( 'tags added' );

                if ( ! empty( $tag_slugs ) ) {
                    wp_set_object_terms(
                        $post_id,
                        $tag_slugs,
                        'review_tags',
                        false
                    );
                }
            }
        }

        $page++;
    }
}

// Cron Scheduling
function hz_cron_schedule($schedules)
{
    $schedules['every_two_mins'] = array(
        'interval' => (60 * 2), // Every 2 mins
        'display'  => 'Every 2 Mins',
    );
    $schedules['every_three_mins'] = array(
        'interval' => (60 * 3), // Every 3 mins
        'display'  => 'Every 3 Mins',
    );
    $schedules['every_five_mins'] = array(
        'interval' => (60 * 5), // Every 5 mins
        'display'  => 'Every 5 Mins',
    );
    return $schedules;
}

add_filter('cron_schedules', 'hz_cron_schedule');

// cronjob every 15 minutes

add_action('init', 'hooks_for_roomboss_cron');

function hooks_for_roomboss_cron()
{
    if (! wp_next_scheduled('hz_get_data_from_booking_sys')) {
        // wp_schedule_event( time(), 'fifteen_minutes', 'hz_get_data_from_booking_sys' );
        wp_schedule_event(time(), 'every_five_mins', 'hz_get_data_from_booking_sys');
    }
}

add_action('hz_get_data_from_booking_sys', 'hz_get_data_from_booking_sys_func');

function hz_get_data_from_booking_sys_func()
{
    $accommodation_cat = get_terms([
        'taxonomy'   => 'accommodation-cat',
        'hide_empty' => false,
        'exclude'    => [61],
    ]);
    if (empty($accommodation_cat) || is_wp_error($accommodation_cat)) {
        cf_log('No accommodation categories found', 'err_key', 'txt', false, true);
        return;
    }

    $hotel_ids    = [];

    $page_num     = get_option('hz_page', 1);
    $total_pages  = get_option('hz_total_pages', 5);
    $per_page = 3;
    if( @$_GET['test'] == 'yes' ){
        $per_page = 1;
    }

    if ($page_num <= $total_pages) {
        if( @$_GET['test'] == 'yes' ){

            pre( 'page_num' );
            pre( $page_num );
        }

        $limited_hotels = hz_get_limited_properties($page_num, $per_page );

        $properties = $limited_hotels['properties'] ?? [];

        if (empty($properties)) {
            cf_log(
                'no hotels found at offset: ' . $page_num . ' total pages are: ' . $total_pages,
                'empty_hotels',
                'txt',
                true,
                true
            );

            // reset for new category
            update_option('hz_page', 1, false);
            update_option('hz_post_order', 1, false);
            update_option('hz_total_pages', 5, false); // reset to default unless API updates it
            return;
        }

        $hz_total_pages = $limited_hotels['total_pages'];
        if ($hz_total_pages > 0) {
            update_option('hz_total_pages', $hz_total_pages, false);
            $total_pages = $hz_total_pages;
        }

        foreach ($properties as $property_key => $property) {

            $is_roomboss = isset($property['is_bed_bank']) && $property['is_bed_bank'] == 'false' ? true : false;
            $meta_input = [];

            $is_enabled = (bool)$property['is_enabled'];

            $hotel_name = trim( htmlentities( $property['name'] ) );

            if( @$_GET['test'] == 'yes' ){
                pre( 'hotel_name' );
                pre( $hotel_name );
            }
            if( @$_GET['test'] == 'yes' ){
                pre('is_bed_bank' );
                pre( $property['is_bed_bank'] );
            }
            if( @$_GET['test'] == 'yes' ){
                pre( 'is_roomboss' );
                pre( var_dump( $is_roomboss ) );
            }
            if ( $is_roomboss === true ) {

                $hotel_tid  = trim($property['room_boss_hotel_id']);

                $meta_input = [
                    'acc_hotel_id' => $hotel_tid,
                    'is_roomboss'   => 1,
                ];
            } else { // bedbank

                $meta_input = [
                    'is_roomboss'   => 0,   
                ];
            }

            if ( empty($hotel_name) ) {
                continue;
            }

            $detail         = $property['details'] ?? [];

            $hotel_desc     = trim($detail['long_description'] ?? '');
            $list_desc      = trim( $detail['list_description'] ?? '' );
            $unit_count     = trim( $detail['unit_count'] ?? 0 );

            $rateplans      = $property['ratePlanDescriptions'] ?? [];
            
            $status         = $is_enabled === true ? 'publish' : 'draft';
            $roomTypes      = $property['rooms'] ?? [];
            $property_id    = trim($property['id']);
            $resort_id      = trim($property['resort_id']);
            $post_order     = intval(get_option('hz_post_order', 1));

            $hotel          = get_post_by_title($hotel_name, 'accommodation');

            $hotelid        = !empty($hotel) ? $hotel->ID : 0;
            $isExisting     = !empty($hotel) ? true : false;

            $new_acc_prefix = $hotelid == 0 ? 'new ' : '';

            // $get_min_room_price = get_hotel_min_room_price( $roomTypes );
            $num_bedrooms   = get_hotel_num_bedrooms($roomTypes) ?? [];

            $bedrooms       = array_unique($num_bedrooms);

            $meta_input['bedroom_number']           =  $bedrooms;
            $meta_input['property_id']              =  $property_id;
            $meta_input['post_order']               =  $post_order;

            $meta_input['_header_option']           =  'field_695261be5649d ';
            $meta_input['header_option']            =  'transparent ';

            if( $unit_count > 0 ){
                $meta_input['unit_count']           = $unit_count;
            }

            if( !empty( $list_desc ) ){
                $meta_input['bs_short_description'] = $list_desc;
            }

            $hotel_data = [
                'ID'                                => $hotelid,
                'post_title'                        => $hotel_name,
                'post_content'                      => $hotel_desc,
                'post_type'                         => 'accommodation',
                'post_status'                       => $status,
                'menu_order'                        => $post_order,
            ];

            $msg     = !empty($hotel) ? "Hotel: $hotel_name updated with id: " : "Hotel: $hotel_name created with id: ";
            $err_msg = !empty($hotel) ? "Error updating hotel: " : "Error creating hotel: ";
            // cf_log($hotel_data, 'hotel_data');
            $upd_hotel_id = wp_insert_post($hotel_data);

            /*add images*/

            $PropertyImages = $property['images'] ?? [];
            /*RatePlan*/
            if( !empty( $rateplans ) ){

                $rate_plan_rows = [];
                foreach ($rateplans as $rateplan) {
                    
                    // Define the data for your rows

                    $rate_plan_rows[] =
                        array(
                            'rate_plan_id'                      => $rateplan['rate_plan_id'],
                            
                            'rate_plan_name'                    => !empty( trim( $rateplan['client_rateplan_name'] ) ) ? 
                            trim( htmlentities( $rateplan['client_rateplan_name'] ) ) : 
                            $rateplan['names'],
                            
                            'rate_plan_description'             => !empty( trim( $rateplan['client_description'] ) ) ? 
                            trim( htmlentities( $rateplan['client_description'] ) ) : 
                            $rateplan['descriptions'],

                            'rate_plan_long_descriptions'       => !empty( trim( $rateplan['client_long_description'] ) ) ? 
                            trim( htmlentities( $rateplan['client_long_description'] ) ) : 
                            $rateplan['long_descriptions'],
                        );
                }

                // Update the repeater field
                update_field('rate_plan', $rate_plan_rows, $upd_hotel_id);
            }

            // add images
            hz_add_img_from_booking_sys( $PropertyImages, $upd_hotel_id, 'accommodation' );

            foreach ($meta_input as $meta_key => $meta_value) {
                update_post_meta( $upd_hotel_id, $meta_key, $meta_value );
            }

            $cat_id = hz_get_term_id_by_resort_id( $resort_id );

            if (!is_wp_error($upd_hotel_id)) {
                wp_set_object_terms($upd_hotel_id, (int) $cat_id, 'accommodation-cat');
                cf_log($msg . $upd_hotel_id, 'roomboss_hotels');
                if( @$_GET['test'] == 'yes' ){
                    pre( $msg . $upd_hotel_id );
                }        
            } else {
                cf_log($err_msg . $upd_hotel_id->get_error_message(), 'roomboss_hotels');
                if( @$_GET['test'] == 'yes' ){
                    pre( $err_msg . $upd_hotel_id->get_error_message() );
                }            
            }

            $room_ids = [];
            $room_links = '';

            foreach ($roomTypes as $key => $roomType) {

                $room_name              = !empty( $roomType['name'] ) ? trim( htmlentities( $roomType['name'] ) ) : '';
                if( @$_GET['test'] == 'yes' ){
                    pre( 'room_name' );
                    pre( $room_name );
                }

                $room_id                = !empty( $roomType['id'] ) ? trim( $roomType['id'] ) : 0;

                $maxNumberGuests        = !empty( $roomType['no_of_guest'] ) ? trim($roomType['no_of_guest']) : 0;
                $numberBedrooms         = !empty( $roomType['no_of_bedrooms'] ) ? trim($roomType['no_of_bedrooms']) : 0;
                $numberBathrooms        = !empty( $roomType['no_of_bathrooms'] ) ? trim($roomType['no_of_bathrooms']) : 0;
                $maxNumberAdults        = !empty( $roomType['maximum_adults'] ) ? trim($roomType['maximum_adults']) : 0;
                $maxNumberChildren      = !empty( $roomType['additional_children'] ) ? trim($roomType['additional_children']): 0;
                $maxNumberInfants       = !empty( $roomType['additional_infants'] ) ? trim($roomType['additional_infants']): 0;
                $room_sqm               = !empty( $roomType['square_meters'] ) ? trim( $roomType['square_meters'] ) : 0;

                $rooms                  = get_hotel_rooms( $property_id, [$room_id] );

                if( @$_GET['test'] == 'yes' ){
                    
                    pre( 'rooms' );
                    pre( $rooms );
                }

                $roomid                 = $rooms['rooms'][0]->ID;

                $room_data              = 
                [
                    'ID'                => $roomid,
                    'post_title'        => $room_name,
                    'post_type'         => 'japan_rooms',
                    'post_status'       => $status,
                ];

                $meta_input = [
                    'property_id'       => $property_id,
                    'actual_room_id'    => $room_id,
                    'room_guests'       => $maxNumberGuests,
                    'room_bedroom'      => $numberBedrooms,
                    'room_bathroom'     => $numberBathrooms,
                    'room_adults'       => $maxNumberAdults,
                    'room_children'     => $maxNumberChildren,
                    'room_infants'      => $maxNumberInfants,
                    'room_sqm'          => $room_sqm,
                    'jp_hotel_link'     => [
                        'title'  => $hotel_name,
                        'url'    => get_permalink( $upd_hotel_id ),
                        'target' => '_blank'
                        ],
                    'jp_hotel'        => [$upd_hotel_id],

                ];

                if ( $is_roomboss ) {

                    $room_desc          = isset($roomType['description']) ? trim($roomType['description']) : '';
                    $room_tid           = trim($roomType['room_boss_room_id']);

                    $room_data[ 'post_content' ] = $room_desc;

                    $meta_input['room_hotel_id'] = $hotel_tid;
                    $meta_input['room_type_id'] = $room_tid;
                    $meta_input['is_roomboss'] = intval( !$is_roomboss );

                } else { // bedbank
                    $meta_input[ 'is_roomboss' ] = intval( !$is_roomboss );
                }

                $msg        = !empty($rooms['rooms']) ? "Room: $room_name is updated for hotel: $hotel_name and id: " : "Room: $room_name is created for hotel: $hotel_name and id: ";
                $err_msg    = !empty($room)  ? "Error creating room: " : "Error updating room: ";
                $upd_room_id = wp_insert_post($room_data);

                $room_ids[]  = $upd_room_id;
                $room_links  .= "<a href='https://jsnew.japanskiexperience.com/wp-admin/post.php?post={$upd_room_id}&action=edit'>{$room_name}</a>\n";
                $room_imgs   = $roomType['images'] ?? [];

                if( @$_GET['test'] == 'yes' ){
                    pre( 'upd_room_id' );
                    pre( $upd_room_id );
                }

                // add images
                hz_add_img_from_booking_sys($room_imgs, $upd_room_id, 'room');

                if (!is_wp_error($upd_room_id)) {
                    cf_log($msg . $upd_room_id, 'roomboss_rooms');
                    if( @$_GET['test'] == 'yes' ){
                        pre( $msg . $upd_room_id );
                    }
                    foreach ($meta_input as $meta_key => $meta_value) {
                        update_post_meta( $upd_room_id, $meta_key, $meta_value );
                    }

                } else {
                    cf_log($err_msg . $upd_room_id->get_error_message(), 'roomboss_rooms');
                    if( @$_GET['test'] == 'yes' ){
                        pre( $err_msg . $upd_room_id->get_error_message() );
                    }
                }
            }

            update_field( 'jp_rooms_link', $room_links, $upd_hotel_id);
            update_field( 'jp_rooms', $room_ids, $upd_hotel_id);
            update_option('hz_post_order', $post_order + 1, false);

            update_option('hz_page', intval($page_num) + 1, false);
            cf_log('page updated to: ' . ($page_num + 1) . ' with total pages: ' . $total_pages, 'page_updated', 'txt', true, true);
        }
    }
    else {

        // reset for new category
        update_option('hz_page', 1, false);
        update_option('hz_post_order', 1, false);
        update_option('hz_total_pages', 5, false); // reset to default unless API updates it
    }
}

add_action('wp', 'hz_get_acc_params');

function hz_get_acc_params() {

    $url = explode('?', $_SERVER['REQUEST_URI']);

    // Get just the path part
    $path = parse_url($url[0], PHP_URL_PATH);

    // Break into parts
    $parts = explode('/', trim($path, '/'));

    $resort_slug = '';

    // Get the second-last segment

    foreach ($parts as $key => $part) {

        if (strpos($part, 'accommodation')) {
            $resort = explode('-', $part);
            $resort_slug = $resort[0];
        }
    }

    $_GET['resort'] = ucwords($resort_slug);

    if (isset($_COOKIE['formData'])) {

        $params = $_COOKIE['formData'];
        // pre( $params );
        if (isset($_COOKIE['hz_acc_params_' . get_the_ID()])) {
            // pre( 'hz_acc_params_'.get_the_ID() );
            $params = $_COOKIE['hz_acc_params_' . get_the_ID()];
            // pre( $_COOKIE );
        }

        // pre( $params );
        @$_GET['params'] == 'show' ? pre($params) : '';
        if (!empty($params)) {
            parse_str($params, $formData);
            if (!empty($formData)) {
                foreach ($formData as $key => $value) {
                    $_GET[$key] = $value;

                    if (@$_GET['show_keys'] == 'yes') {

                        pre($key);
                        pre($_GET[$key]);
                    }
                }

                $checkin = $_GET['checkIn'];

                $duration = $_GET['duration'];

                // $_GET['checkout'] = $chk_out;
            }
        }
    }
}

add_shortcode('get_single_page_rooms', 'get_rooms_func');

function get_rooms_func($atts) {

    $atts = shortcode_atts(
        array(
            'property_id' => '',
        ),
        $atts,
        'get_single_page_rooms'
    );

    $property_id = $atts['property_id'];

    $rooms = get_rooms_by_property_id($property_id);

    $msg = '';

    $heading = get_field('room_type_heading', 'option');
    $desc = get_field('room_type_desc', 'option');

    // pre( $rooms, 1 );
    // pre( var_dump( $rooms ), 1 );
    if (!empty($rooms)):
        $num_bedrooms = get_rooms_custom_field_values( $rooms, 'room_bedroom' );

        $unique_bedrooms = array_unique($num_bedrooms);
        $count_bedrooms = count($unique_bedrooms);
        asort($unique_bedrooms, SORT_NUMERIC);

        $num_adults = get_rooms_custom_field_values($rooms, 'room_adults');
        asort($num_adults, SORT_NUMERIC);

        $num_children = get_rooms_custom_field_values($rooms, 'room_children');
        asort($num_children, SORT_NUMERIC);

        $num_infants = get_rooms_custom_field_values($rooms, 'room_infants');
        asort($num_infants, SORT_NUMERIC);

        $display_buttons = $count_bedrooms > 1 ? 'block' : 'none';
?>
        <div class="main_container_1 container">
            <div class="hotel_rooms_1">
                <div class="head">
                    <h1><?php echo $heading ?></h1>
                    <p><?php echo $desc ?></p>
                    <div class="room-buttons buttons-container">
                        <div class="buttons">
                            <button data-value="*" class="bedroom-btn">
                                All Bedrooms
                            </button>
                            <?php foreach ($unique_bedrooms as $key => $bedroom): ?>
                                <?php if (!empty($bedroom)): ?>
                                    <button data-value="<?php echo $bedroom; ?>" class="bedroom-btn">
                                        <?php echo $bedroom ?> Bedroom
                                    </button>
                                <?php endif ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="room-container room-slider">
                    <?php
                    foreach ($rooms as $key => $room) {
                        // pre( $room );
                        $pid = $room->ID;
                        $tid = get_field('room_hotel_id', $pid);
                        $name = get_the_title($pid);

                        $bedroom = get_field('room_bedroom', $pid);

                        $img_src = '';
                        if (has_post_thumbnail($pid)) {
                            $img_src = get_the_post_thumbnail_url($pid);

                            if (empty($img_src)) {
                                $img_src = get_attachment_link(43404);
                            }
                        } else {
                            $img_src = get_attachment_link(43404);
                        }
                        $options = ['fa-user' => 'room_guests', 'fa-person' => 'room_adults', 'fa-child' => 'room_children', 'fa-baby-carriage' => 'room_infants', 'fa-bed' => 'room_bedroom', 'fa-bath' => 'room_bathroom'];
                        $display = $bedroom > 1 ? 'none' : 'block';
                    ?>
                        <div class="room" data-id="<?php echo $pid ?>" data-tid="<?php echo $tid ?>" data-bedroom="<?php echo $bedroom; ?>">
                            <div class="room_image">
                                <img src="<?php echo $img_src; ?>" data-id="<?php echo $pid ?>">
                            </div>
                            <div class="room-main">
                                <div class="err_msg container">
                                    <p class="msg"></p>
                                </div>
                                <div class="room_title">
                                    <p><?php echo $name; ?></p>
                                </div>
                                <div class="room_price">
                                    <p><?php //echo $price; 
                                        ?></p>
                                </div>
                                <div class="err_msg" style="display:none;">
                                    <p>This room is not available check other rooms.</p>
                                </div>
                                <div class="room_options">
                                    <ul>
                                        <?php
                                        foreach ($options as $key => $option):

                                            $opt_value = get_field($option, $pid);

                                            if ($opt_value && $opt_value > 0):
                                                $option_label = str_replace('room_', '', $option);
                                        ?>
                                                <li>
                                                    <div class="icon">
                                                        <i class="fa-solid <?php echo $key ?>"></i>
                                                    </div>
                                                    <div class="label">
                                                        <p><?php echo $option_label; ?>:</p>
                                                    </div>
                                                    <div class="value">
                                                        <?php echo $opt_value; ?>
                                                    </div>
                                                </li>
                                        <?php endif;
                                        endforeach; ?>
                                    </ul>
                                </div>
                                <div class="room_bottom">
                                    <div class="detail_buttons">
                                        <button class="instant_quote">Book Now</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    else:
        echo $msg;

    endif;
}

add_shortcode('room_check_rates', 'get_rooms_rates_func');

function get_rooms_rates_func()
{

    $atts = shortcode_atts(
        array(
            'property_id' => get_field( 'property_id', get_the_ID() ),
        ),
        $atts,
        'room_check_rates'
    );

    $hotel_id = $atts['hotel_id'];

    if (!empty(@$_GET['start_date']) && !empty(@$_GET['end_date']) && !empty(@$_GET['guests'])) {

        $hotel_tid = get_field('acc_hotel_id', $hotel_id);
        $start_date = @$_GET['start_date'];
        $converted_start_date = date("Ymd", strtotime($start_date));
        $end_date = @$_GET['end_date'];
        $converted_end_date = date("Ymd", strtotime($end_date));

        $chk_in_date = new DateTime($start_date);
        $chk_out_date = new DateTime($end_date);
        $interval = $chk_in_date->diff($chk_out_date);
        $duration = $interval->d;

        $guests = $_GET['adults'] ? intval($_GET['adults']) + intval($_GET['children']) + intval($_GET['infants']) : $_GET['guests'];

        $args = booking_sys_api_args();
        $get_room_apiUrl = 'https://api.roomboss.com/extws/hotel/v1/listRatePlanDescription?hotelId=' . $hotel_tid;
        $get_rateplan_res = wp_remote_get($get_room_apiUrl, $args);

        $rateplan_resBody = wp_remote_retrieve_body($get_rateplan_res);
        $rateplan_result = json_decode($rateplan_resBody, true);

        $rate_plan_en = [];
        foreach ($rateplan_result[0]['ratePlanDescriptionList'] as $plan) {
            $rate_plan_en[$plan['ratePlanId']] = [
                'name'            => $plan['names']['en'] ?? '',
                'description'     => $plan['descriptions']['en'] ?? '',
                'longDescription' => $plan['longDescriptions']['en'] ?? '',
            ];
        }

        $room_desc_apiUrl = 'https://api.roomboss.com/extws/hotel/v1/listDescription?hotelId=' . $hotel_tid . '&locale=en';
        $desc_res = wp_remote_get($room_desc_apiUrl, $args);

        $room_desc_resBody = wp_remote_retrieve_body($desc_res);
        $room_desc_result = json_decode($room_desc_resBody, true);

        $room_desc_hotel = $room_desc_result['hotels'];

        $room_desc = [];

        foreach ($room_desc_hotel[0]['roomTypes'] as $desc) {
            $room_desc[$desc['roomTypeId']] = $desc['roomTypeDescription'];
        }


        $rooms = [];
        $msg = '';

        $heading = get_field('room_type_heading', 'option');
        $desc = get_field('room_type_desc', 'option');

        /*roomboss api*/

        // $apiUrl = 'https://api.roomboss.com/extws/hotel/v1/listDescription?'.$hotel_tid.'&locale=en';
        $get_room_apiUrl = 'https://api.roomboss.com/extws/hotel/v1/listAvailable?hotelId=' . $hotel_tid . '&checkIn=' . $converted_start_date . '&checkOut=' . $converted_end_date . '&numberGuests=' . $guests . '&rate=ota';

        $get_room_res = wp_remote_get($get_room_apiUrl, $args);
        // pre( $get_room_res );

        if (is_array($get_room_res) && ! is_wp_error($get_room_res)) {
            $get_room_resBody = wp_remote_retrieve_body($get_room_res);
            $get_room_result = json_decode($get_room_resBody, true);

            // pre( $get_room_result );

            $hotels = $get_room_result['availableHotels'];
            $hotels = $hotels[0];
            $rooms = $hotels['roomTypes'];
            $available_rooms = $hotels['availableRoomTypes'];

            $img_rooms = [];
            if (!empty($rooms)) {
                $imgapiUrl = 'https://api.roomboss.com/extws/hotel/v1/listImage?hotelId=' . $hotel_tid;
                $img_res = wp_remote_get($imgapiUrl, $args);

                if (is_array($img_res) && ! is_wp_error($img_res)) {

                    $img_resBody = wp_remote_retrieve_body($img_res);
                    $img_result = json_decode($img_resBody, true);
                    // cf_log( $img_result, 'img_result_res' );
                    $img_hotels = $img_result['hotels'];
                    $img_hotels = $img_hotels[0];

                    $img_rooms = $img_hotels['roomTypes'];

                    if (!empty($img_resBody['failureMessage'])) return $img_resBody['failureMessage'];

                    if (empty($img_hotels)) return 'No hotels were found for the provided hotel ID';
                }/*end is_array( $img_res )*/ else if (is_wp_error($img_res)) {
                    cf_log($img_res->get_error_message(), 'img_api_err');
                }/*end is_wp_error( $img_res )*/
            } else {
                echo '<div class="err_msg">No rooms available for the selected dates.</div>';
            }

            $hotel_name = $hotels['hotelName'];
        } else if (is_wp_error($get_room_res)) {
            cf_log($get_room_res->get_error_message(), 'err_api_get_rooms', 'txt', false, true);
            $msg = '<p class="api_error">Error occured. Contact support.</p>';
        }

        if (!empty($rooms)):

            $num_bedrooms = wp_list_pluck($rooms, 'numberBedrooms');
            $num_bedrooms = array_unique($num_bedrooms);
            asort($num_bedrooms, SORT_NUMERIC);

            $num_bathrooms = wp_list_pluck($rooms, 'numberBathrooms');
            asort($num_bathrooms, SORT_NUMERIC);

            $num_adults = wp_list_pluck($rooms, 'maxNumberAdults');
            asort($num_adults, SORT_NUMERIC);

            $num_children = wp_list_pluck($rooms, 'maxNumberChildren');
            asort($num_children, SORT_NUMERIC);

            $num_infants = wp_list_pluck($rooms, 'maxNumberInfants');
            asort($num_infants, SORT_NUMERIC);

        ?>
            <div class="main_container container">
                <div class="hotel_rooms" data-post_id="<?php echo $hotel_id ?>">
                    <div class="head">
                        <h1><?php echo $heading ?></h1>
                        <p><?php echo $desc ?></p>
                        <div class="room-buttons buttons-container">
                            <div class="buttons">
                                <button data-value="*" class="bedroom-btn">
                                    All Bedrooms
                                </button>
                                <?php foreach ($num_bedrooms as $key => $bedroom): ?>
                                    <button data-value="<?php echo $bedroom; ?>" class="bedroom-btn">
                                        <?php echo $bedroom ?> Bedroom
                                    </button>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </div>
                    <div class="room-container">
                        <?php
                        foreach ($rooms as $key => $room) {
                            $grouped = [];
                            if (!empty($available_rooms)) {
                                foreach ($available_rooms as $av_room_key => $available_room):

                                    $name = $available_room['roomTypeName'];
                                    if (isset($grouped[$name])) {

                                        if ($grouped[$name]['ratePlans'])

                                            $grouped[$name]['ratePlans'][] = $available_room['ratePlan'];
                                    } else {
                                        $grouped[$name] = [
                                            'roomTypeId' => $available_room['roomTypeId'],
                                            'roomTypeName' => $name,
                                            'maxNumberGuests' => $available_room['maxNumberGuests'],
                                            'numberBedrooms' => $available_room['numberBedrooms'],
                                            'numberBathrooms' => $available_room['numberBathrooms'],
                                            'maxNumberAdults' => $available_room['maxNumberAdults'],
                                            'maxNumberChildren' => $available_room['maxNumberChildren'],
                                            'maxNumberInfants' => $available_room['maxNumberInfants'],
                                            'quantityAvailable' => $available_room['quantityAvailable'],
                                            'priceNumberGuests' => $available_room['priceNumberGuests'],
                                            'minNights' => $available_room['minNights'],
                                            'ratePlans' => [$available_room['ratePlan']]
                                        ];
                                    }
                        ?>

                                <?php
                                endforeach;
                            } else {
                                echo '<div class="err_msg">This room is not available in the selected dates.</div>';
                            }
                            $available_room = $grouped[$room['roomTypeName']];
                            // pre( $available_room );

                            $ratePlans = $available_room['ratePlans'];

                            $prices = wp_list_pluck($ratePlans, 'priceRetail');

                            if ($ratePlans && !empty($ratePlans)) :
                                // pre( $room );
                                $tid = $room['roomTypeId'];

                                $name = $room['roomTypeName'];
                                $room_imgs_arr = $img_rooms[$key];
                                $img_src = '';
                                if ($room_imgs_arr['roomTypeId'] == $tid) {
                                    $room_imgs = $room_imgs_arr['roomTypeImages'] ?? [];

                                    if (!empty($room_imgs)) {
                                        $img_key = array_key_first($room_imgs);

                                        $img_src = $room_imgs[$img_key] ?? get_attachment_link(43404);

                                        // $img_src = get_attachment_link( 43404 );
                                    } else {
                                        $img_src = get_attachment_link(43404);
                                    }
                                } else {
                                    $img_src = get_attachment_link(43404);
                                }

                                $adults = $_GET['adults'] ?? 0;
                                $children = @$_GET['children'];
                                $infants = @$_GET['infants'];

                                $options = ['fa-user' => 'maxNumberGuests', 'fa-bed' => 'numberBedrooms', 'fa-bath' => 'numberBathrooms'];

                                $display = $room['numberBedrooms'] > 1 ? 'none' : 'block';
                                $max_guests = $room['maxNumberGuests'];
                                $max_adults = $room['maxNumberAdults'];
                                $max_children = $room['maxNumberChildren'];
                                $max_infants = $room['maxNumberInfants'];

                                $total_children = $max_guests - 1;
                                $net_guests = intval($max_guests) + intval($max_infants);

                                // if( $max_adults > 0 ){
                                //     $options['fa-person'] = 'maxNumberAdults';
                                // }

                                // if( $max_children > 0 ){
                                //     $options['fa-child'] = 'maxNumberChildren';
                                // }

                                if ($max_infants > 0) {
                                    $options['fa-baby-carriage'] = 'maxNumberInfants';
                                }
                                ?>
                                <div class="room" data-tid="<?php echo $tid ?>" data-bedroom="<?php echo $room['numberBedrooms']; ?>">
                                    <div class="room_container_2">
                                        <div class="room_image-1">
                                            <img src="<?php echo $img_src; ?>">
                                        </div>
                                        <div class="room-main-1">
                                            <div class="room_header">
                                                <div class="room_title">
                                                    <p><?php echo $name; ?></p>
                                                </div>
                                                <div class="selected_dates">
                                                    <div class="start-date"><?php echo date('d-M-Y', strtotime(@$_GET['start_date'])); ?></div>
                                                    -
                                                    <div class="end-date"><?php echo date('d-M-Y', strtotime($_GET['end_date'])); ?></div>
                                                </div>

                                            </div>
                                            <div class="room_options">
                                                <ul>
                                                    <?php foreach ($options as $opt_key => $option):

                                                        if ($room[$option] && $room[$option] > 0):
                                                            $option_label = str_replace(['number', 'maxNumber'], '', $option)
                                                    ?>
                                                            <li data-option="<?php echo strtolower($option_label) ?>">
                                                                <div class="icon">
                                                                    <i class="fa-solid <?php echo trim($opt_key) ?>"></i>
                                                                </div>
                                                                <div class="value">
                                                                    <?php echo intval($room[$option]); ?>
                                                                </div>
                                                            </li>

                                                    <?php endif;
                                                    endforeach; ?>
                                                </ul>
                                            </div>
                                            <div class="guests_filter">
                                                <form id="guets_form" class="guets_form" method="POST" data-nights="<?php echo $duration ?>">
                                                    <div class="num_adults guest_search">
                                                        <label>Adults </label>

                                                        <select class="num_adults guest_fields guests_form_select" data-total="<?php echo $max_guests; ?>" name="num_adults" id="num_adults" data-placeholder="adults">
                                                            <option>Adults</option>
                                                            <?php
                                                            for ($i = 1; $i <= $max_guests; $i++) { ?>
                                                                <option class="adult_option" <?php echo $i == $adults ? 'selected' : '' ?> value="<?php echo $i ?>"><?php echo $i ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>

                                                    <div class="num_children guest_search">
                                                        <label>Children </label>
                                                        <select class="num_children guest_fields guests_form_select" data-total="<?php echo $max_guests; ?>" name="num_children" id="num_children" data-placeholder="children">
                                                            <option>Children</option>
                                                            <?php

                                                            for ($i = 0; $i <= $total_children; $i++) { ?>
                                                                <option class="children_option" <?php echo $i == $children ? 'selected' : '' ?> value="<?php echo $i ?>"><?php echo $i ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>

                                                    <div class="num_infants guest_search">
                                                        <label>Infants </label>
                                                        <select class="num_infants guest_fields<?php echo $max_infants == 0 ? ' guests_form_select' : ' net_total_guests' ?>" data-total="<?php echo $max_infants == 0 ? $max_guests : $net_guests; ?>" name="num_infants" id="num_infants" data-placeholder="infants">
                                                            <option>Infants</option>
                                                            <?php

                                                            // $total_infants = $max_infants;
                                                            // if( $max_infants < 1 ){
                                                            $total_infants = intval($max_guests) - 1;
                                                            // }

                                                            for ($i = 0; $i <= $total_infants; $i++) { ?>
                                                                <option class="infant_option" <?php echo $i == $infants ? 'selected' : '' ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </form>
                                            </div>

                                            <div class="error-wrap">
                                                <p class="err_guests" style="display:none;color:red;margin:5px 0;"></p>
                                                <p class="err_infants" style="display:none;color:red;margin:5px 0;"></p>
                                            </div>
                                            <div class="desc">
                                                <p><?php echo $room_desc[$tid]; ?></p>
                                            </div>
                                        </div><!-- room main -->
                                    </div>
                                    <div class="bottom-container">
                                        <div class="rate_plan container">
                                            <?php

                                            foreach (array_reverse($ratePlans) as $rp_key => $ratePlan):

                                                $ratePlanId = $ratePlan['ratePlanId'];
                                                $priceRetail = $ratePlan['priceRetail'];
                                                $ratePlan_info = $rate_plan_en[$ratePlanId] ?? [];

                                            ?>
                                                <div class="rate_plan_box" data-tid="<?php echo $ratePlanId ?>">
                                                    <div class="rate_plan_title">
                                                        <p><?php echo $ratePlan_info['name'] ?? ''; ?></p>
                                                        <i class="toggle_long_desc fa-solid fa-circle-info"></i>
                                                    </div>
                                                    <div class="rate_plan_desc">
                                                        <p><?php echo $ratePlan_info['description'] ?? ''; ?></p>
                                                        <?php
                                                        $desc = $ratePlan_info['description'];

                                                        $old_price = 0;
                                                        if (count($prices) > 1) {
                                                            $old_price = max($prices);
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="long_desc" style="display:none;">
                                                        <?php
                                                        $long_desc = $ratePlan_info['longDescription'] ?? '';

                                                        $long_desc = preg_replace(
                                                            '/<p>\s*<strong><em>\[?[^\]]*Booking Policy[^\]]*\]?<\/em><\/strong><\/p>[\s\S]*?(?=<p>\s*<strong><em>\[|$)/i',
                                                            '',
                                                            $long_desc
                                                        );
                                                        ?>
                                                        <?php echo $long_desc ?? ''; ?>
                                                    </div>
                                                    <div class="price_container">
                                                        <div class="room_prices">
                                                            <?php
                                                            $per_person_price = ceil(intval($priceRetail) / intval($max_guests));
                                                            ?>
                                                            <div class="per_person"><?php echo _currency_format_new($per_person_price, true) ?>
                                                                <label class="label">per stay</label>
                                                            </div>
                                                            <?php
                                                            ?>
                                                            <div class="room-price">
                                                                <?php if ($old_price > 0 && $old_price > $priceRetail) { ?>
                                                                    <!-- <div class="discount_label">Was</div> -->
                                                                    <div class="discount_price" data-price="<?php echo ceil($old_price) ?>"><?php echo _currency_format_new(ceil($old_price), true) ?></div>
                                                                <?php } ?>
                                                                <div class="final_price" data-price="<?php echo $priceRetail; ?>"><?php echo _currency_format_new($priceRetail, true); ?></div>
                                                            </div>
                                                        </div>
                                                        <div class="select-room">
                                                            <button class="room_select">Select</button>
                                                        </div>

                                                    </div>
                                                </div>
                                            <?php endforeach;
                                            ?>
                                        </div>
                                    </div>
                                </div>
                        <?php
                            endif;
                        }
                        ?>
                    </div>
                </div>
                <div class="cart">
                    <div class="cart_conatiner">
                        <div class="cart_head">
                            <div class="cart_heading">
                                <h1>Booking Summary</h1>
                            </div>
                        </div>
                        <div class="cart_body">
                            <?php if ($_COOKIE['cart_data']):
                                $cartData = json_decode(stripslashes($_COOKIE['cart_data']), true);
                                // pre( $cartData);
                                if ($cartData['post_id'] && !empty($cartData['post_id']) && $cartData['post_id'] == get_the_ID()):
                                    $display = 'none';
                                    $cart_rooms = $cartData['rooms'];

                                    $display = !empty($cart_rooms) ? 'block' : 'none';

                                    $total_price = $cartData['total_price'];
                                    foreach ($cart_rooms as $cr_key => $cart_room): ?>

                                        <div class="selected_room">
                                            <div class="close">
                                                <button><i class="fa-solid fa-trash"></i></button>
                                            </div>
                                            <div class="details" data-tid="<?php echo $cart_room['tid'] ?>">
                                                <div class="room_name"><?php echo $cart_room['room_name'] ?></div>
                                                <div class="room_desc"><?php echo $cart_room['rate_plan_title'] ?></div>
                                                <div class="guests_staying"><?php echo $cart_room['guests_staying'] ?></div>
                                                <div class="selected_dates">
                                                    <div class="start_date_container">
                                                        <b>Start Date:</b>
                                                        <div class="start_date"><?php echo $cartData['start_date'] ?></div>
                                                    </div>
                                                    <div class="end_date_container">
                                                        <b>End Date</b>
                                                        <div class="end_date"><?php echo $cartData['end_date'] ?></div>
                                                    </div>
                                                </div>
                                                <?php if ($cart_room['discount_price'] > 0): ?>
                                                    <div class="discount_price" data-price="<?php echo $cart_room['discount_price'] ?>" data-tid="<?php echo $cart_room['tid'] ?>"><?php echo _currency_format_new($cart_room['discount_price'], true) ?></div>
                                                <?php
                                                // $total_price = intval( $total_price ) + intval( $cart_room['price'] );
                                                endif ?>
                                                <div class="price" data-price="<?php echo $cart_room['price'] ?>"><?php echo _currency_format_new($cart_room['price'], true); ?></div>
                                            </div>
                                        </div>
                            <?php endforeach;
                                endif;
                            endif; ?>
                        </div>
                        <div class="cart_footer" style="display:<?php echo $display ?>">
                            <div class="total">
                                <input type="text" readonly data-price="<?php echo $total_price ?>" name="total_price" class="total_price" readonly value="<?php echo _currency_format_new($total_price); ?>">
                            </div>
                            <!-- <a class="proceed-btn btn" href="<?php //echo home_url( '/confirm_booking/' ); 
                                                                    ?>">Proceed</a> -->
                            <a class="proceed-btn btn" href="javascript:void(0)">Proceed</a>
                        </div>
                    </div>
                </div>
            </div>
<?php
        else:

            echo $msg;

        endif;
    } else {
        echo '<div class="err_msg">Please select check-in, check-out dates and number of guests in the previous step.</div>';
    }
}

add_shortcode('get_room_data', 'get_room_data_func');

function get_room_data_func()
{

    $atts = shortcode_atts(
        array(
            'post_id' => get_the_ID(),
        ),
        $atts,
        'get_room_data'
    );

    $post_id = $atts['post_id'];

    /*Rom types*/
    $property_id = get_field('property_id', $post_id);
    if ((@$_GET['check_rates'] && !empty($_GET['check_rates'])) && !empty(@$_GET['start_date']) && !empty(@$_GET['end_date']) && !empty(@$_GET['guests'])) {
        echo do_shortcode('[room_check_rates property_id=' . $property_id . ']');
    } else {
        echo do_shortcode('[get_single_page_rooms property_id=' . $property_id . ']');
    }
}

//hz_get_results_by_name
add_action("wp_ajax_hz_get_results_by_name", "hz_get_results_by_name_func");
add_action("wp_ajax_nopriv_hz_get_results_by_name", "hz_get_results_by_name_func");

function hz_get_results_by_name_func()
{
    $properties = '';
    $destinations = '';
    if (!empty(@$_POST['name'])) {

        $search_term = sanitize_text_field($_POST['name']);
        $cat_slug = sanitize_text_field($_POST['cat_slug']);

        $args = [
            'post_type'          => 'accommodation',
            'post_status'        => 'publish',
            'title_starts_with'  => $search_term,
            'posts_per_page'     => 9,
            'orderby'            => 'title', // Sort by post title
            'order'              => 'ASC',
            'fields'             => 'ids', // only return IDs
        ];

        if (!empty($cat_slug)) {
            $args['tax_query'] = 
            [
                [
                    'taxonomy' => 'accommodation-cat',
                    'field'    => 'slug',   // you can also use 'term_id'
                    'terms'    => $cat_slug,
                ],
            ];
        }

        $get_acc = new WP_Query($args);
        $acc_html = '';

        if ($get_acc->have_posts()) {

            while ($get_acc->have_posts()) {
                $get_acc->the_post();
                $acc_id = get_the_ID();
                $acc_title = get_the_title();
                $hotel_id = get_field('acc_hotel_id');
                $area = get_field('area');

                $properties .= '<li data-value="' . $acc_title . '" data-hotel-id="' . $hotel_id . '" class="property">' . $acc_title . '</li>';
                wp_reset_postdata();
            }
        }

        $terms = get_terms([
            'taxonomy'   => 'accommodation-cat',
            'hide_empty' => false,
            'search'     => $search_term, // partial match
        ]);

        if (empty($terms) || is_wp_error($terms)) {
            return wp_send_json_success(['data' => ['properties' => $properties, 'destinations' => $destinations]]);
        }

        return wp_send_json_success(['data' => ['properties' => $properties, 'destinations' => $destinations]]);
    } else {
        return wp_send_json_success(['data' => ['properties' => $properties, 'destinations' => $destinations]]);
    }
}

add_filter( 'posts_where', 'wpse_title_starts_with_where', 10, 2 );

function wpse_title_starts_with_where( $where, $query ) {
    global $wpdb;

    // Retrieve our custom argument
    $starts_with = $query->get( 'title_starts_with' );

    if ( $starts_with ) {
        // Use LIKE with the wildcard at the end for "starts with" logic
        $where .= $wpdb->prepare( 
            " AND {$wpdb->posts}.post_title LIKE %s", 
            $wpdb->esc_like( $starts_with ) . '%' 
        );
    }

    return $where;
}

/**
 * Generate dynamic checkboxes for ACF 'bedroom_number' field based on existing post meta values.
 *
 * @param string $post_type The post type to filter meta values from.
 * @param array $selected Optional array of selected bedroom numbers.
 */
function kv_dynamic_bedroom_checkboxes($post_type = 'accommodation', $selected = array())
{
    global $wpdb;

    // Fetch distinct serialized meta values for the given post type
    $results = $wpdb->get_col($wpdb->prepare("
        SELECT DISTINCT pm.meta_value
        FROM $wpdb->postmeta AS pm
        INNER JOIN $wpdb->posts AS p ON p.ID = pm.post_id
        WHERE pm.meta_key = %s
        AND p.post_type = %s
        AND p.post_status = 'publish'
        AND pm.meta_value != ''
        ", 'bedroom_number', $post_type));

    $bedroom_values = array();

    // Unserialize each meta value and collect numbers
    foreach ($results as $meta_value) {
        $unserialized = maybe_unserialize($meta_value);
        if (is_array($unserialized)) {
            foreach ($unserialized as $unserial_key => $val) {

                if (intval($val) > 0)
                    $bedroom_values[] = intval($val);
            }
        } elseif (!empty($unserialized) && $unserialized > 0) {
            $bedroom_values[] = intval($unserialized);
        }
    }

    // Get unique and sorted values
    $bedroom_values = array_unique($bedroom_values);
    sort($bedroom_values, SORT_NUMERIC);

    // Handle selected values (GET or passed array)
    if (empty($selected) && isset($_GET['bedrooms'])) {
        $selected = array_map('intval', (array) $_GET['bedrooms']);
    }

    // Output HTML checkboxes
    if (!empty($bedroom_values)) {
        echo '<div class="bedroom_search accomodation_search">';
        echo '<label><strong>Number of Bedrooms:</strong></label>';
        echo '<div class="bedroom_chkbox">';
        foreach ($bedroom_values as $val) {
            $checked = in_array($val, $selected) ? 'checked' : '';
            echo sprintf(
                '<label style="margin-right:10px;">
                <input type="checkbox" name="bedrooms[]" value="%d" %s> %d
                </label>',
                $val,
                $checked,
                $val
            );
        }
        echo '</div>';

        echo '</div>';
    } else {
        echo '<p>No bedroom data found for this post type.</p>';
    }
}

add_filter('acf/load_field', 'hz_make_acf_readonly_fields');

function hz_make_acf_readonly_fields( $field ) {
    $readonly_fields = array('acc_hotel_id', 'room_hotel_id', 'room_type_id', '_payment_id', '_external_reference', '_amount', '_expires_at', '_booking_reference', 'jp_rooms', 'jp_rooms_link', 'property_id', 'is_roomboss', 'rate_plan_id', 'rate_plan_name', 'rate_plan_description', 'rate_plan_long_descriptions');

    if ( in_array($field['name'], $readonly_fields) ) {
        $field['readonly'] = 1;
    }

    return $field;
}

isset($_GET['reset_permalink']) && intval($_GET['reset_permalink']) ? add_action('wp_head', 'hz_reset_perma_link') : '';

function hz_reset_perma_link()
{

    $post_id = $_GET['reset_permalink'];
    $permalink_array = get_option('permalink-manager-uris');

    if ($permalink_array[$post_id]) {
        unset($permalink_array[$post_id]);
    }
    update_option('permalink-manager-uris', $permalink_array);
}

add_action("wp_ajax_fetch_room_details", "hz_get_room_data");
add_action("wp_ajax_nopriv_fetch_room_details", "hz_get_room_data");

/**
 * Fetch detailed room information via AJAX
 * 
 * @return void Sends JSON response with room data
 */
function hz_get_room_data()
{
    try {
        // ✅ STEP 1: Validate and sanitize input
        $room_tid = isset($_POST['room_tid']) ? sanitize_text_field($_POST['room_tid']) : '';

        if (empty($room_tid)) {
            return wp_send_json_error([
                'message' => 'Room ID is required',
                'code' => 'missing_room_id'
            ], 400);
        }

        // ✅ STEP 2: Get room post ID
        $room_id = get_post_id_by_typeId($room_tid, 'room');

        if (empty($room_id) || $room_id <= 0) {
            return wp_send_json_error([
                'message' => 'Room not found',
                'code' => 'room_not_found'
            ], 404);
        }

        // ✅ STEP 3: Verify room post exists
        $room_post = get_post($room_id);

        if (!$room_post || $room_post->post_status !== 'publish') {
            return wp_send_json_error([
                'message' => 'Room is not accessible',
                'code' => 'room_not_accessible'
            ], 403);
        }

        // ✅ STEP 4: Get room image
        $room_img = get_the_post_thumbnail_url($room_id, 'medium');

        if (!$room_img) {
            $room_img = get_stylesheet_directory_uri() . '/images/placeholder-listing.jpg'; // Fallback to empty string
        }

        // ✅ STEP 5: Get room description
        $room_desc = get_the_content(null, false, $room_id);

        if (!$room_desc) {
            $room_desc = $room_post->post_excerpt ?? ''; // Fallback to excerpt
        }

        // ✅ STEP 6: Build room fields array
        $field_options = [
            'guest' => 'room_guests',
            'bed' => 'room_bedroom',
            'bath' => 'room_bathroom',
            'infant' => 'room_infants',
        ];

        $room_fields = '';

        foreach ($field_options as $icon_class => $field_name) {
            $field_value = get_field($field_name, $room_id);

            if (!empty($field_value)) {
                $field_value = intval($field_value); // Type-cast to integer
                $room_fields .= '<span class="rb-icon ' . esc_attr($icon_class) . '">' 
                    . esc_html($field_value) 
                    . '</span>';
            }
        }

        // ✅ STEP 7: Return success response
        return wp_send_json_success([
            'room_id' => $room_id,
            'room_img' => esc_url($room_img),
            'room_fields' => $room_fields,
            'room_desc' => wp_kses_post($room_desc),
        ]);

    } catch (Exception $e) {
        // ❌ Catch unexpected errors
        return wp_send_json_error([
            'message' => 'An unexpected error occurred',
            'code' => 'unexpected_error',
            'details' => $e->getMessage()
        ], 500);
    }
}

add_filter('wpseo_breadcrumb_links', 'hz_accommodation_breadcrumbs_from_url');
function hz_accommodation_breadcrumbs_from_url($links)
{

    if (!is_singular('accommodation')) {
        return $links;
    }

    $path = trim(
        wp_make_link_relative(get_permalink()),
        '/'
    );

    $parts = array_values(array_filter(explode('/', $path)));

    // Expecting: [resort, accommodation, slug]
    if (count($parts) < 3) {
        return $links;
    }

    [$resort, $accommodation] = $parts;

    $new = [];

    $new[] = [
        'url'  => home_url('/'),
        'text' => 'Home',
    ];

    $new[] = [
        'url'  => home_url("/{$resort}/"),
        'text' => ucwords(str_replace('-', ' ', $resort)),
    ];

    $new[] = [
        'url'  => home_url("/{$resort}/{$accommodation}/"),
        'text' => ucwords(str_replace('-', ' ', $accommodation)),
    ];

    $new[] = [
        'text' => get_the_title(),
    ];

    return $new;
}

add_shortcode('show_tagged_reviews', 'codex_tagged_reviews');
function codex_tagged_reviews( $atts)
{

    $atts = shortcode_atts( [
        'tags' => 'accommodation-best',
        'required' => 5,
    ], $atts, 'show_tagged_reviews' );

    ob_start();
    $average = get_option('kv_company_average_rating', '4.8'); 
    $total = get_option('kv_company_total_reviews', '632');
    $count = $average . ' Average ' . $total . ' Reviews';
    $paged = isset($_POST['ajaxpage']) ? $_POST['ajaxpage'] : 1;

    $schemaReviews = [];
    
    $tags = [ trim( $atts['tags'] ) ];
    if( strpos( $atts['tags'] , ',' ) ){
        $tags = explode(',', $atts['tags'] );
    }

    $args = [
        'post_type'      => 'reviews',
        'post_status'    => 'publish',
        'paged' => $paged,
        // 'orderby' => 'publish_date',
        'meta_key' => 'review_date',
        'orderby' => 'meta_value_num',
        'order' => 'DESC',
        'tax_query'      => [
            [
                'taxonomy' => 'review_tags',
                'field'    => 'slug',
                'terms'    => $tags,
            ],
        ],
    ];
    $loop = new WP_Query($args);
    ?>
    <div class="cs_reviews">
        <div class="cs__inn">
            <div class="cs_total">
                <a href="https://www.reviews.io/company-reviews/store/japanskiexperience-com1" target="_blank">
                    <span class="total_count"><?= $average; ?></span>
                    <span class="fa star-<?= round($average); ?>"></span>
                    <span class="total_reviews"><?= $count; ?></span>
                    <img src="https://s3-us-west-1.amazonaws.com/reviews-us-assets/assets/widget-assets/logos/logo-reviewsio--black--md.png"
                         width="105" height="15" alt="">
                </a>
            </div> <!-- cs_total -->
            <div class="cs_blank">&nbsp;</div> <!-- cs_blank -->
        </div> <!-- cs__inn -->
        <div class="reviews-ajax">
            <?php
            while ($loop->have_posts()) : $loop->the_post();
                $date = get_field('review_date', get_the_ID());
                $rating = get_post_meta(get_the_ID(), 'review_rating', 1) ?: '5';
                $reviewDate = date("d/m/Y", strtotime($date));
                ?>
                <div class="review_users">
                    <div class="user_name_rv">
                        
                        <h3><?php echo str_replace('&quot;', '' , html_entity_decode( get_the_title() ) ) ; ?></h3>
                        <span class="date"><?= $reviewDate; ?></span>
                        <div class="rv_image">
                            <a href="https://www.reviews.io/company-reviews/store/japanskiexperience-com1"
                               target="_blank">
                                <img src="https://s3-us-west-1.amazonaws.com/reviews-us-assets/assets/widget-assets/logos/favicon-reviewsio--black--sm.png"
                                     width="25" height="25">
                                <span>- Review.io</span>
                            </a>
                        </div> <!-- rv_image -->
                    </div> <!-- user_name_rv -->
                    <div class="user_comment">
                        <span class="fa star-<?= $rating; ?>"></span>
                        <p class="review-more"><?php echo get_the_content(); ?></p>
                        <!-- Ali bhai is par show hide wala kam karna hai -->
                    </div> <!-- user_comment -->
                </div> <!-- review_users -->
            <?php
            endwhile;
            ?>
        </div>
        <?php
        wp_reset_postdata();
        if ($loop->max_num_pages > 1)
            echo '<div class="_loadmore btn">Load More</div>';
        ?>
    </div> <!-- cs_reviews -->
    <script>
        jQuery(function ($) { // use jQuery code inside this to avoid "$ is not defined" error
            let page = 2;
            let max = <?= $loop->max_num_pages; ?>;
            $('._loadmore').click(function () {
                let button = $(this);
                $.ajax({ // you can also use $.post here
                    url: window.location.href, // AJAX handler
                    data: {ajaxpage: page},
                    type: 'POST',
                    beforeSend: function (xhr) {
                        button.text('Loading...'); // change the button text, you can also add a preloader image
                    },
                    success: function (data) {
                        if (data) {
                            let html = $('.reviews-ajax', data).html();
                            $('.reviews-ajax').append(html);
                            button.text('Load More'); // insert new posts
                            page++;
                            if (page == max)
                                button.remove(); // if last page, remove the button
                        } else {
                            button.remove(); // if no data, remove the button as well
                        }
                    }
                });
            });
        });
    </script>
    <?php
    return '' . ob_get_clean();
}

add_shortcode('company_rating', 'kv_company_rating_shortcode');
function kv_company_rating_shortcode()
{
    // Fetch stored options
    $review_data = get_review_data();
    $rating        = $review_data['average']; //kv_company_average_rating
    $total_reviews = $review_data['total']; //'kv_company_total_reviews'
    // Safety fallback
    if (!$rating || !$total_reviews) {
        return '';
    }
    ob_start();
    ?>
    <div class="ratingarea">
        <div class="rate_star top_style">
            <img src="<?php echo home_url() ?>/wp-content/themes/kingdomvision/images/rating-star.svg"
                 class="attachment-full size-full"
                 alt="Rating stars"
                 decoding="async">
        </div>

        <span class="top_style">
            <?php echo esc_html($rating); ?> | <?php echo esc_html(number_format($total_reviews)); ?> Reviews
        </span>

        <div class="brand top_style">
            <img src="https://jsnew.japanskiexperience.com/wp-content/uploads/2025/12/Brand.svg"
                 class="attachment-full size-full"
                 alt="Brand"
                 decoding="async">
        </div>

    </div>
    <?php

    return ob_get_clean();
}

function get_review_data (){
    // $average = get_field('kv_company_average_rating', 'option') ?: '4.8';
    $average = get_field('average_reviews', 'option') ?: '4.8';
    // $total   = get_field('kv_company_total_reviews', 'option') ?: '632';
    $total   = get_field('total_reviews', 'option') ?: '632';

    $count   = round($average, 1) . ' Average ' . $total . ' Reviews';
    // $title   = get_field('kv_company_review_title', 'option') ?: 'Rated excellent by 900+ customers';
    $title   = get_field('review_title', 'option') ?: 'Rated excellent by 900+ customers';

    return [ 'average' => $average, 'total' => $total, 'count' => $count, 'title' => $title ];
}

add_filter( 'gform_validation_3', 'inject_flywire_trigger_as_error' );

function inject_flywire_trigger_as_error( $validation_result ) {
    $form = $validation_result['form'];

        // do NOT inject the Flywire trigger. Let the user fix those first.
    if ( !$validation_result['is_valid'] ) {
        return $validation_result;
    }
    
    // Check our 'lock' field (e.g., ID 100). If empty, we fail validation.
    $lock_field_id = 17; 
    $payment_token = rgpost( "input_{$lock_field_id}" );

    if ( empty( $payment_token ) ) {
        $validation_result['is_valid'] = false;

        foreach ( $form['fields'] as &$field ) {
            if ( $field->id == $lock_field_id ) {
                $field->failed_validation = true;
                // INJECT TRIGGER HERE:
                $field->validation_message .= "<div id='flywire-trigger' style='display:none;'></div>";
            }
        }
    }

    $validation_result['form'] = $form;
    return $validation_result;
}

add_filter( 'gform_confirmation_anchor_3', '__return_false' );

add_action('wp_ajax_create_flywire_session', 'create_flywire_session');
add_action('wp_ajax_nopriv_create_flywire_session', 'create_flywire_session');

function create_flywire_session() {

    $payload = $_POST['payload'];

    $url = 'https://api-platform-sandbox.flywire.com/payments/v1/checkout/sessions';

    $body = [
        'type'               => 'one_off',
        'schema'             => 'cards',
        'charge_intent' => [
            'mode'          => 'one_off',     // keeps it a single payment
            'capture'       => 'manual',      // tells Flywire to authorize but not capture
            'authorization' => 'preauth',     // allows later capture & amount adjustment
        ],
        'payor'          => [
            'first_name' => sanitize_text_field($payload['firstName']),
            'last_name'  => sanitize_text_field($payload['lastName']),
            'email'      => sanitize_email($payload['email']),
            'phone'      => sanitize_text_field($payload['phone']),
            'address'    => sanitize_text_field($payload['address']),
            'city'       => sanitize_text_field($payload['city']),
            'country'    => sanitize_text_field($payload['country']),
            'zip'        => sanitize_text_field($payload['postcode']),
        ],
        'options'                    => [
            'form' => [
                'action_button'     => 'save',
                'locale'            => sanitize_text_field($payload['lang']),
                
                'show_flywire_logo' => true,
            ],
        ],
        'recipient'                  => [
            'fields' => [
                [
                    'id'    => 'booking_reference',
                    'value' => 'GF-' . time(),
                ],
            ],
        ],
        'items'                      => [
            [
                'id'     => 'default',
                'amount' => intval( $payload['amount'] ),
            ],
        ],
        'notifications_url'          => home_url('/wp-json/flywire/v1/webhook'),
        'return_url'                 => home_url('/flywire-return/'),
        'external_reference'         =>'Booking-' . date( 'Y-M-d h:i:s A' ),
        'recipient_id'               => 'JSE',
        'payor_id'                   => 'JSE_'.time(),
        'enable_email_notifications' => true,
    ];

    $args = [
        'method'  => 'POST',
        'timeout' => 45,
        'headers' => [
            'Content-Type'         => 'application/json',
            'X-Authentication-Key' => 'Y05SSzQ5TXQwakFSaVk3TG9jNk9KZz09',
        ],
        'body'    => json_encode($body),
    ];
    // wp_send_json_success([$args]);
    $response = wp_remote_post($url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    wp_send_json_success(
        $data ?? null
    );
}

add_action('rest_api_init', function () {
    register_rest_route('kv/v1', '/accommodation/sync', [
        'methods'  => 'POST',
        'callback' => 'kv_sync_accommodation',
        'permission_callback' => '__return_true',
    ]);
});

function kv_sync_accommodation(WP_REST_Request $request) {
    // pre( $request );
    $cat_array = [0 => 'furano-accommodation',1 => 'hakuba-accommodation',2 => 'niseko-accommodation',3 => 'rusutsu-accommodation',];
    $property_data = $request->get_json_params();

    if (empty($property_data)) {
        return new WP_Error('invalid_payload', 'property_data is required', ['status' => 400]);
    }

    $is_bedbank    = empty( $property_data['property_location']['room_boss_hotel_id'] ) ? true: false;

    /**
     * Resolve canonical hotel_id
     * ──────────────────────────
     * Bedbank   → provided directly
     * RoomBoss  → room_boss_hotel_id
     */
    if ($is_bedbank) {
        $hotel_id = sanitize_text_field($request->get_param('property_id'));
    } else {
        $hotel_id = $property_data['property_location']['room_boss_hotel_id'] ?? null;
    }

    // if (!$hotel_id) {
    //     return new WP_Error('missing_hotel_id', 'Unable to resolve hotel_id', ['status' => 400]);
    // }

    //$property_id = 0; /*not available in payload*/
    $is_enabled = (bool)$property_data['property_location']['is_enabled'];
    $status = $is_enabled ? 'publish' : 'draft';
    /**
     * Locate existing accommodation
     */

    // return new WP_REST_Response([
    //     'hotel_id'    => $hotel_id,
    // ], 200);
    $existing = get_post_id_by_typeId( $hotel_id, 'accommodation' );

    // return new WP_REST_Response([
    //     'existing'    => $existing,
    // ], 200);

    $post_id = $existing ? $existing : 0;
    $upd_post_id = 0;

    $resort_id = $property_data['property_location']['resort_id'] ?? 0;
    //$cat_slug = $cat_array[$resort_id]; /*not provided in payload*/

    /**
     * Prepare core post fields
     */
    $title = $property_data['property_location']['name'] ?? 'Accommodation';

    $content =
        $property_data['property_details']['client_long_description']
        ?? $property_data['property_details']['long_description']
        ?? '';

    $post_args = [
        'ID'           => $post_id,
        'post_type'    => 'accommodation',
        'post_content' => $content,
        'post_title'   => wp_strip_all_tags($title),
        'post_status'  => $status,
    ];

    /**
     * Create or update post
     */
    $upd_post_id = wp_insert_post($post_args, true);
    $action = $post_id > 0 ? 'updated' : 'created';

    if (is_wp_error($upd_post_id)) {
        return new WP_Error('post_error', $post_id->get_error_message(), ['status' => 500]);
    }


    // wp_set_object_terms($upd_post_id, $cat_slug, 'accommodation-cat');

    // $bedrooms = (array)$property_data['property_details']['no_of_bedrooms'];
    // $area = (array)$property_data['property_details']['no_of_bedrooms'];
    // $type = (array)$property_data['property_details']['no_of_bedrooms'];

    /**
     * Canonical meta
     */

    if( $is_bedbank ){
        update_post_meta($upd_post_id, 'property_id', $hotel_id );
    }
    elseif( !$is_bedbank ){
        update_post_meta($upd_post_id, 'acc_hotel_id', $hotel_id );
    }
    
    // update_post_meta($upd_post_id, 'property_id', $property_id ? 1 : 0);
    update_post_meta($upd_post_id, 'is_roomboss', $is_bedbank ? 0 : 1);
    update_post_meta($upd_post_id, 'bedroom_number', $bedrooms );
    // update_post_meta($upd_post_id, 'area', $area );
    // update_post_meta($upd_post_id, 'type', $type );

    // update_post_meta($post_id, 'data_source', $is_bedbank ? 'bedbank' : 'roomboss');

    /**
     * Full supplier payload (future-proof)
     */
    // update_post_meta($post_id, 'property_location', $property_data['property_location'] ?? []);
    // update_post_meta($post_id, 'property_details', $property_data['property_details'] ?? []);
    // update_post_meta($post_id, 'important_info', $property_data['important_info'] ?? []);
    // update_post_meta($post_id, 'extra_properties', $property_data['extra_properties'] ?? []);
    // update_post_meta($post_id, 'property_gallery', $property_data['property_gallery'] ?? []);

    return [
        'success'  => true,
        'action'   => $action,
        'post_id'  => $upd_post_id,
        'hotel_id' => $hotel_id,
        'source'   => $is_bedbank ? 'bedbank' : 'roomboss',
    ];
}

add_action('rest_api_init', function () {
    register_rest_route('kv/v1', '/rooms/sync', [
        'methods'  => 'POST',
        'callback' => 'kv_sync_japan_rooms',
        'permission_callback' => '__return_true',
    ]);
});

function kv_sync_japan_rooms( WP_REST_Request $request ) {

    $payload = $request->get_json_params();

    if ( empty($payload['property_id']) || empty($payload['rooms']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'property_id and rooms are required'
        ], 400);
    }

    $property_id = intval($payload['property_id']);

    $results = [];

    foreach ( $payload['rooms'] as $room ) {

        $is_roomboss  = empty($room['room_boss_room_id']) ? false : true;
        if ( empty($room['room_boss_room_id']) && empty($room['id']) ) {
            continue;
        }

        $external_id = $is_roomboss ? sanitize_text_field($room['room_boss_room_id']) : sanitize_text_field($room['id']);

        // ---- Find existing room ----
        $existing = get_post_id_by_typeId($external_id, 'room');

        $post_id = $existing ? $existing : 0;
        $room_args = [
            'ID'           => $post_id,
            'post_type'    => 'japan_rooms',
            'post_title'   => sanitize_text_field($room['name']),
            'post_content' => wp_kses_post($room['description'] ?? ''),
            'post_status'  => 'publish',
        ];

        $updated_post_id = wp_insert_post($room_args, true);
        $action  = $existing ? 'updated' : 'created';

        if ( is_wp_error($updated_post_id) ) {
            $room_type = $is_roomboss == true ? 'RoomBoss' : 'Bedbank';
            cf_log( 'Error '.$action.' '.$room_type.' room with id: '.$external_id, 'err_room_log', 'txt', false );
        }

        update_post_meta($updated_post_id, 'property_id', $property_id);
        update_post_meta($updated_post_id, 'is_roomboss', (int)$is_roomboss);

        // ---- Core meta (same for both cases) ----
        if( !$is_roomboss ){
            update_post_meta($updated_post_id, 'bb_room_id', $external_id);
        }
        elseif( $is_roomboss ){
            update_post_meta($updated_post_id, 'room_type_id', sanitize_text_field($room['room_boss_room_id']) );
        }

        $meta_map = [
            'standard_adults'     => intval($room['standard_adults'] ?? 0),
            'room_per_unit'       => sanitize_text_field($room['room_per_unit'] ?? ''),
            'no_of_units'         => intval($room['no_of_units'] ?? 0),
            'room_guests'         => intval($room['no_of_guest'] ?? 0),
            'room_bedroom'      => intval($room['no_of_bedrooms'] ?? 0),
            'room_bathroom'     => intval($room['no_of_bathrooms'] ?? 0),
            'room_sqm'       => intval($room['square_meters'] ?? 0),
            'room_adults'      => intval($room['maximum_adults'] ?? 0),
            'additional_children' => intval($room['additional_children'] ?? 0),
            'room_infants'  => intval($room['additional_infants'] ?? 0),
        ];

        foreach ( $meta_map as $key => $value ) {
            update_post_meta($updated_post_id, $key, $value);
        }

        $results[] = [
            'post_id' => $updated_post_id,
            'action'  => $action,
        ];
    }

    return new WP_REST_Response([
        'success'  => true,
        'synced'   => count($results),
        'rooms'    => $results,
    ], 200);
}

add_action('rest_api_init', function () {
    register_rest_route('flywire/v1', '/webhook', [
        'methods' => 'POST',
        'callback' => 'handle_flywire_webhook',
        'permission_callback' => '__return_true', // webhooks are public, secure via secret later if needed
    ]);
});

function handle_flywire_webhook($request) {

    $body = json_decode($request->get_body(), true);
    cf_log( $body, 'flywire_webhook_log', 'txt', false, true );
    
    $event_type = $body['event_type'] ?? '';

    $event_resource = $body['event_resource'] ?? '';
    $data = $body['data'] ?? [];

    $payment_id = $data['payment_id'] ?? null;

    $fields = $data['fields'] ?? [];
    $booking_reference = $fields['booking_reference'] ?? '';

    $external_reference = $data['external_reference'] ?? '';
    $amount = $data['amount_to'] ?? 0;
    $currency = $data['currency_to'] ?? '';
    $status = $data['status'] ?? '';

    if (!$payment_id) {
        return;
    }

    if( $event_type !== 'initiated'){

        $payment_post = get_flywire_payment_by_payment_id($payment_id);

        if (!$payment_post) {
            return;
        }

        $post_id = $payment_post->ID;

        /* FAILED */
        if ($event_resource === 'charges' && $event_type === 'failed') {

            $reason = $data['reason'];
            update_post_meta($post_id, '_status', $status);
            update_post_meta($post_id, '_reason', $reason);

        }

        if ($event_resource === 'payments' && $event_type === 'cancelled') {

            $reason = $data['cancellation_reason'];
            update_post_meta($post_id, '_status', $status);
            update_post_meta($post_id, '_reason', $reason);

        }

        /* AUTHORIZED */
        if ($event_resource === 'charges' && $event_type === 'authorized') {

            update_post_meta($post_id, '_status', $status);
            update_post_meta($post_id, '_authorized_at', current_time('mysql'));
            update_post_meta($post_id, '_authorized_at', current_time('mysql'));

        }

        /* CAPTURED */
        if ($event_resource === 'charges' && $event_type === 'captured') {

            update_post_meta($post_id, '_status', $status);
            update_post_meta($post_id, '_captured_at', current_time('mysql'));

        }

    }

    else if( $event_type == 'initiated'){
        // Create a new payment record for this session

        create_flywire_payment_record([
            'payment_id' => $payment_id,
            'external_reference' => $external_reference,
            'amount' => $amount,
            'currency' => $currency,
            'expires_at' => isset($data['expiration_date']) ? date('Y-m-d H:i:s', strtotime($data['expiration_date'])) : '',
            'booking_reference' => $booking_reference,
            'status' => $status,
        ]);

    }

    // Check status and session ID
    if (
        isset($data['status']) &&
        $data['status'] === 'authorized'
    )
    {

        $form_id = 3;
        $last_entry_id = get_last_gravity_form_entry_id( $form_id );

        if ( $last_entry_id ) {

            $upd_payment_id = GFAPI::update_entry_field( $last_entry_id, 17, $payment_id );
        }
    }

    return wp_send_json_error(['message' => 'Invalid webhook payload']);
}

/**
 * Capture funds for a pre-authorized Flywire session.
 *
 * @param string $session_id The Flywire session ID.
 * @param int $amount Amount to capture (in the smallest currency unit, e.g., cents).
 * @return array Success status and response data or error.
 */
function capture_flywire_payment($payment_id, $amount) {

    $capture_url = "https://api-platform-sandbox.flywire.com/payments/v1/payments/{$payment_id}/captures";

    $body = [
        'amount' => intval($amount),
    ];

    $args = [
        'method'  => 'POST',
        'timeout' => 45,
        'headers' => [
            'Content-Type'         => 'application/json',
            'X-Authentication-Key' => 'Y05SSzQ5TXQwakFSaVk3TG9jNk9KZz09', // your backend key
        ],
        'body'    => json_encode($body),
    ];

    $response = wp_remote_post($capture_url, $args);

    if (is_wp_error($response)) {
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    cf_log( $data, 'flywire_capture_response_log', 'txt', false, true );
    
    if( $data['status'] == 200 ){

        return ['success' => true, 'data' => $data];
    }
    else{
        return ['success' => false, 'data' => $data];
    }

}

/*Fly wire bokings*/
add_action('init', function () {

    register_post_type('flywire_payment', [
        'label' => 'Flywire Payments',
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-money-alt',
        'supports' => ['title'],
        'capability_type' => 'post',
        'map_meta_cap' => true,
    ]);

});

function create_flywire_payment_record($args) {

    $post_id = wp_insert_post([
        'post_type'   => 'flywire_payment',
        'post_title'  => 'FW Payment - ' . $args['external_reference'],
        'post_status' => 'publish',
    ]);

    update_post_meta($post_id, '_payment_id', $args['payment_id'] ?? '');
    update_post_meta($post_id, '_session_id', $args['session_id'] ?? '');
    update_post_meta($post_id, '_external_reference', $args['external_reference']);
    update_post_meta($post_id, '_amount', $args['amount']);
    update_post_meta($post_id, '_currency', $args['currency']);
    update_post_meta($post_id, '_status', $args['status'] ?? 'initiated');
    update_post_meta($post_id, '_reason', '');
    update_post_meta($post_id, '_booking_reference', $args['booking_reference'] ?? '');
    update_post_meta($post_id, '_expires_at', $args['expires_at'] ?? '');

    return $post_id;
}

function get_flywire_payment_by_payment_id($payment_id) {

    $query = new WP_Query([
        'post_type'  => 'flywire_payment',
        'meta_query' => [
            [
                'key'   => '_payment_id',
                'value' => $payment_id
            ]
        ],
        'posts_per_page' => 1
    ]);

    return $query->have_posts() ? $query->posts[0] : null;
}

add_filter('manage_flywire_payment_posts_columns', 'manage_flywire_columns');

function manage_flywire_columns($columns) {

    $columns['payment_id'] = 'Payment ID';
    $columns['amount'] = 'Amount';
    $columns['status'] = 'Status';
    $columns['expires_at'] = 'Expires At';

    return $columns;
}

add_action('manage_flywire_payment_posts_custom_column', 'manage_flywire_columns_values', 10, 2);

function manage_flywire_columns_values($column, $post_id) {

    if ($column === 'payment_id') {
        echo esc_html(get_post_meta($post_id, '_payment_id', true));
    }

    if ($column === 'amount') {
        echo esc_html(get_post_meta($post_id, '_amount', true)) . ' ' .
             esc_html(get_post_meta($post_id, '_currency', true));
    }

    if ($column === 'status') {
        echo esc_html(get_post_meta($post_id, '_status', true));
    }

    if ($column === 'expires_at') {
        echo esc_html(get_post_meta($post_id, '_expires_at', true));
    }

}

function disable_wp_emojicons() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_filter( 'tiny_mce_plugins', 'wpemoji' );
    add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', 'disable_wp_emojicons' );

add_action('save_post_flywire_payment', 'kv_capture_on_status_update', 20, 3);

function kv_capture_on_status_update($post_id, $post, $update)
{
    // Prevent autosave / revision issues
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (wp_is_post_revision($post_id)) {
        return;
    }

    // Only run when updating existing post
    if (!$update) {
        return;
    }

    $status = get_post_meta($post_id, '_status', true);
    $captured = get_post_meta($post_id, '_capture_triggered', true);

    // Trigger capture only when status becomes capture_requested
    if ( $status === 'captured' && !$captured) {

        $payment_id = get_post_meta($post_id, '_payment_id', true);
        $amount = get_post_meta($post_id, '_amount', true);

        $result = capture_flywire_payment($payment_id, $amount);

        $charge_result = $result['charge_result'];
        $status = $charge_result['status'] ?? '';

        cf_log( $result, 'flywire_capture_log', 'txt', false, true );
        if ( $charge_result === 'received' ) {
            cf_log( 'Captured payment for session: '.$payment_id.' amount: '.$amount, 'flywire_success_log', 'txt', false, true );

            return wp_send_json_success(['message' => 'Captured successfully']);
        } else {
            cf_log( 'Failed to capture payment for session: '.$payment_id.' error: '.$data['detail'], 'flywire_capture_log', 'txt', false, true );
            return wp_send_json_error(['message' => $data['detail']]);
        }

    }
}

add_action('wp_ajax_add_other_data_in_fw', 'add_other_data_in_fw');
add_action('wp_ajax_nopriv_add_other_data_in_fw', 'add_other_data_in_fw');

function add_other_data_in_fw() {

    $payment_id = '';

    $form_id = 3;
    $last_entry_id = get_last_gravity_form_entry_id( $form_id );
    if ( $last_entry_id ) {

        // Retrieve the full entry object using the Gravity Forms API
        $entry = GFAPI::get_entry( $last_entry_id );

        // Get the value of a single-input field (e.g., a Single Line Text field with ID 1)
        $payment_id = rgar( $entry, '17' );

    }

    if( !empty( $payment_id ) ){
        /*
        * Add hotel datails in FW  
        */
        $payload = $_POST['payload'];
        $hotel_data = json_decode(stripslashes($payload['hotel_data']), true);
        $payment_post = get_flywire_payment_by_payment_id($payment_id);

        $post_id = $payment_post->ID;
        $room_rows = [];
        $items = $hotel_data['items'];

        update_field('fw_first_name' , rgar( $entry, '11' ), $post_id );
        update_field('fw_last_name' , rgar( $entry, '12' ), $post_id );
        update_field('fw_email' , rgar( $entry, '3' ), $post_id );
        update_field('fw_phone' , rgar( $entry, '13' ), $post_id );
        update_field('fw_user_country' , rgar( $entry, '5' ), $post_id );
        update_field('fw_city' , rgar( $entry, '8' ), $post_id );
        update_field('fw_postcode' , rgar( $entry, '9' ), $post_id );
        update_field('fw_language' , rgar( $entry, '6' ), $post_id );
        update_field('fw_user_address' , rgar( $entry, '10' ), $post_id );
        update_field('fw_amount' , rgar( $entry, '7' ), $post_id );

        foreach ($items as $item_key => $item) {

            update_field('fw_rb_hotel_id', $item['hotel_type_id'], $post_id);
            update_field('fw_hotel_name', $item['hotel_type_id'], $post_id);
            
            // Define the data for your rows

                $room_rows[] = 
                    array(
                        'fw_room_name'          => $item['room_name'],
                        'fw_rb_room_id'         => $item['room_type_id'],
                        'fw_rateplan_id'        => $item['rateplan_id'],
                        'fw_rateplan_name'      => $item['rateplan_name'],
                        'fw_room_price'         => $item['price'],
                        'fw_discount_price'     => $item['discount_price'] ?? 0,
                    );

        }
    }
    // Update the repeater field
    update_field('fw_room_data', $room_rows, $post_id);

    return wp_send_json_success( ['message' => 'Hotel data updated', 'post_id' => $post_id ] );
    // pre( $hotel_data );

}

function get_last_gravity_form_entry_id( $form_id ) {
    // Define search criteria, sorting, and paging
    $search_criteria = array();
    $sorting = array(
        'key'      => 'date_created', // Sort by the date the entry was created
        'direction' => 'DESC'          // Sort in descending order (newest first)
    );
    $paging = array(
        'offset'    => 0,            // Start from the first result
        'page_size' => 1             // Only retrieve one entry
    );

    // Retrieve entries using the Gravity Forms API
    $entries = GFAPI::get_entries( $form_id, $search_criteria, $sorting, $paging );

    // Check if any entries were found
    if ( ! empty( $entries ) ) {
        // The first element in the array is the latest entry
        $last_entry = $entries[0];
        return $last_entry['id']; // Return the entry ID
    } else {
        return null; // No entries found
    }
}

/* add hook to sort accomdations in asc order alphbetically then add menu_order in desc order when accomdation is saved */
/*modify this function to wp_head i will execute it manually as executing once will update all accomdations*/
@$_GET['update_acc'] == 'yes' ? add_action('wp_head', 'sort_accommodations', 20, 3) : '';
function sort_accommodations(){

    // only get accommodations which have menu order 0
    $args = [
        'post_type'      => 'accommodation',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'menu_order'     => 0, // Targets the native post field directly
    ];

    $accommodations = get_posts($args);

    // Update menu_order based on alphabetical order
    foreach ($accommodations as $index => $accommodation) {
        /*only update if menu_order is 0*/
        if( $accommodation->menu_order == 0 || empty( $accommodation->menu_order ) ){
            wp_update_post([
                'ID' => $accommodation->ID,
                'menu_order' => count( $accommodations ) - $index, // Start menu_order from 1
            ]);
        }
    }
}
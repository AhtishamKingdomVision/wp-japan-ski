<?php

add_shortcode('newResortFilters' , 'newResortFiltersCode');
function newResortFiltersCode(){
	ob_start();

	echo '<div class="search-card" id="search-card">';
        echo '<div class="search-row">';

          echo '<div class="sb-field" style="flex:1.3;">';
            echo '<select class="sb-select" id="sb-resort" aria-label="Select resort">';
              echo '<option value="" disabled selected>Resort*</option>';
              echo '<option value="niseko">Niseko</option>';
              echo '<option value="hakuba">Hakuba</option>';
              echo '<option value="rusutsu">Rusutsu</option>';
              echo '<option value="furano">Furano</option>';
            echo '</select>';
          echo '</div>';

          echo '<div class="date-pair">';
            echo '<div class="sb-field" onclick="document.getElementById("sb-checkin").showPicker&&document.getElementById("sb-checkin").showPicker()">';
              echo '<span class="sb-date-display" id="sb-checkin-display">Check In</span>';
              echo '<input class="sb-input" type="date" id="sb-checkin" aria-label="Check-in date" onchange="syncDates("checkin")" />';
            echo '</div>';
            echo '<div class="sb-field" onclick="document.getElementById("sb-checkout").showPicker&&document.getElementById("sb-checkout").showPicker()">';
              echo '<span class="sb-date-display" id="sb-checkout-display">Check Out</span>';
              echo '<input class="sb-input" type="date" id="sb-checkout" aria-label="Check-out date" onchange="syncDates("checkout")" />';
            echo '</div>';
          echo '</div>';

          # Guests field with popover 
          echo '<div class="sb-field sb-guests-desktop" id="sb-guests-field" onclick="toggleGuests(event)">';
            echo '<span class="sb-guests-display empty" id="sb-guests-display">Guests</span>';
          echo '</div>';

          # Mobile: inline guests
          echo '<div class="guests-mobile-row" id="guests-mobile-row">';
            echo '<div class="sb-field">';
              echo '<span class="sb-label">Adults <span class="age-hint">16+</span></span>';
              echo '<input type="number" class="sb-input" id="m-adults" min="1" max="20" value="2" onchange="onMobileGuestChange()" />';
            echo '</div>';
            echo '<div class="sb-field">';
              echo '<span class="sb-label">Children <span class="age-hint">0–15</span></span>';
              echo '<input type="number" class="sb-input" id="m-children" min="0" max="15" value="0" onchange="onMobileGuestChange()" />';
            echo '</div>';
          echo '</div>';

          echo '<button class="sb-submit" id="sb-submit" onclick="doSearch()">';
            echo '<svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            Browse Accommodation';
          echo '</button>';

        echo '</div>'; # search-row

        echo '<div class="guests-popover" id="guests-popover" role="dialog" onclick="event.stopPropagation()">';
          echo '<div class="g-row">';
            echo '<div><span class="g-label">Adults</span><span class="g-sub">Age 16+</span></div>';
            echo '<div class="g-counter">';
              echo '<button class="g-btn" onclick="adj("adults", -1)" id="btn-adults-minus" disabled>−</button>';
              echo '<span class="g-val" id="v-adults">2</span>';
              echo '<button class="g-btn" onclick="adj("adults", 1)">+</button>';
            echo '</div>';
          echo '</div>';
          echo '<div class="g-row">';
            echo '<div><span class="g-label">Children</span><span class="g-sub">Ages 0–15</span></div>';
            echo '<div class="g-counter">';
              echo '<button class="g-btn" onclick="adj("children",-1)" id="btn-children-minus" disabled>−</button>';
              echo '<span class="g-val" id="v-children">0</span>';
              echo '<button class="g-btn" onclick="adj("children",1)">+</button>';
            echo '</div>';
          echo '</div>';
        echo '</div>';

      echo '</div>'; # /search-card

	return''.ob_get_clean();

	?>

	<script>
	  /* ── Scroll: trigger when hero search card scrolls out of view ── */
	  // var heroCard = null;
	  // window.addEventListener('scroll', function() {
	  //   if (!heroCard) heroCard = document.getElementById('search-card');
	  //   var threshold = heroCard ? (heroCard.getBoundingClientRect().bottom + window.scrollY - 80) : 300;
	  //   document.getElementById('main-header').classList.toggle('stickyHeader', window.scrollY > threshold);
	  // });

	  // /* ── Burger / drawer ── */
	  // document.getElementById('hdr-burger').addEventListener('click', function() {
	  //   document.getElementById('nav-drawer').classList.toggle('open');
	  //   document.getElementById('drawer-bg').classList.toggle('open');
	  // });
	  // function closeDrawer() {
	  //   document.getElementById('nav-drawer').classList.remove('open');
	  //   document.getElementById('drawer-bg').classList.remove('open');
	  // }

	  /* ── Date helpers ── */
	  function toDateStr(d) {
	    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
	  }
	  function getDefaultCheckin() {
	    var today = new Date(), m = today.getMonth() + 1, day = today.getDate();
	    if (m >= 3 && !(m === 12 && day >= 1) && m < 12) return new Date(today.getFullYear(), 11, 1);
	    var ci = new Date(today); ci.setDate(ci.getDate() + 5); return ci;
	  }
	  function fmtDate(str) {
	    if (!str) return null;
	    return new Date(str + 'T00:00:00').toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' });
	  }
	  function setDisplayDate(inputId, displayId, fallback) {
	    var val = document.getElementById(inputId).value;
	    var el = document.getElementById(displayId);
	    var fmt = fmtDate(val);
	    el.textContent = fmt || fallback;
	    if (fmt) el.classList.add('has-value'); else el.classList.remove('has-value');
	  }
	  function setDateDefaults() {
	    var ci = getDefaultCheckin();
	    var co = new Date(ci); co.setDate(co.getDate() + 4);
	    /* Hero widget — no pre-filled display, just set min */
	    document.getElementById('sb-checkin').defaultValue  = toDateStr(ci);
	    document.getElementById('sb-checkout').defaultValue = toDateStr(co);
	    document.getElementById('sb-checkout').min          = toDateStr(co);
	    document.getElementById('sb-checkin-display').textContent  = 'Check In';
	    document.getElementById('sb-checkout-display').textContent = 'Check Out';
	    /* Mini header bar — set input values silently, show placeholder text */
	    document.getElementById('hmb-checkin').value  = toDateStr(ci);
	    document.getElementById('hmb-checkout').value = toDateStr(co);
	    document.getElementById('hmb-checkout').min   = toDateStr(co);
	    document.getElementById('hmb-checkin-display').textContent  = 'Check In';
	    document.getElementById('hmb-checkout-display').textContent = 'Check Out';
	    document.getElementById('hmb-checkin-display').classList.remove('has-value');
	    document.getElementById('hmb-checkout-display').classList.remove('has-value');
	  }
	  setDateDefaults();
	  function syncDates(which) {
	    var ciEl = document.getElementById('sb-checkin');
	    var coEl = document.getElementById('sb-checkout');
	    if (which === 'checkin' && ciEl.value) {
	      var minCo = new Date(ciEl.value + 'T00:00:00'); minCo.setDate(minCo.getDate() + 4);
	      var minCoStr = toDateStr(minCo);
	      coEl.min = minCoStr;
	      if (coEl.value && coEl.value < minCoStr) {
	        coEl.value = '';
	        document.getElementById('sb-checkout-display').textContent = 'Check Out';
	        document.getElementById('sb-checkout-display').classList.remove('has-value');
	      }
	      setDisplayDate('sb-checkin', 'sb-checkin-display', 'Check In');
	    }
	    if (which === 'checkout') setDisplayDate('sb-checkout', 'sb-checkout-display', 'Check Out');
	  }

	  /* ── Hero guests popover ── */
	  var g = { adults: 2, children: 0 };
	  function renderGuests() {
	    var el = document.getElementById('sb-guests-display');
	    var parts = [];
	    if (g.adults)   parts.push(g.adults + ' adult' + (g.adults > 1 ? 's' : ''));
	    if (g.children) parts.push(g.children + ' child' + (g.children > 1 ? 'ren' : ''));
	    el.textContent = parts.length ? parts.join(', ') : 'Guests';
	    el.classList.toggle('empty', !parts.length);
	    document.getElementById('v-adults').textContent   = g.adults;
	    document.getElementById('v-children').textContent = g.children;
	    document.getElementById('btn-adults-minus').disabled   = g.adults   <= 1;
	    document.getElementById('btn-children-minus').disabled = g.children <= 0;
	  }
	  function adj(type, delta) {
	    g[type] = Math.max(type === 'adults' ? 1 : 0, g[type] + delta);
	    renderGuests();
	  }
	  renderGuests();
	  var guestPopOpen = false;
	  function toggleGuests(e) {
	    e.stopPropagation();
	    guestPopOpen = !guestPopOpen;
	    document.getElementById('guests-popover').classList.toggle('open', guestPopOpen);
	  }
	  document.addEventListener('click', function(e) {
	    if (guestPopOpen && !document.getElementById('sb-guests-field').contains(e.target)) {
	      guestPopOpen = false; document.getElementById('guests-popover').classList.remove('open');
	    }
	    if (hmbPopOpen && !document.getElementById('hmb-guests-seg').contains(e.target)) {
	      hmbPopOpen = false; document.getElementById('hmb-guests-popover').classList.remove('open');
	    }
	  });
	  function onMobileGuestChange() {
	    g.adults   = Math.max(1, parseInt(document.getElementById('m-adults').value) || 1);
	    g.children = Math.max(0, parseInt(document.getElementById('m-children').value) || 0);
	  }
	  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeDrawer(); });

	  /* ── Browse ── */
	  function doSearch() {
	    var resort = document.getElementById('sb-resort').value;
	    if (!resort) { alert('Please select a resort.'); document.getElementById('sb-resort').focus(); return; }
	    var ci = document.getElementById('sb-checkin').value;
	    var co = document.getElementById('sb-checkout').value;
	    window.location.href = '/accommodation/?resort=' + encodeURIComponent(resort)
	      + (ci ? '&checkin=' + encodeURIComponent(ci) : '')
	      + (co ? '&checkout=' + encodeURIComponent(co) : '')
	      + '&adults=' + g.adults + '&children=' + g.children;
	  }

	  /* ── Mini header bar ── */
	  var hmbGuests = { adults: 2, children: 0 };
	  var hmbPopOpen = false;
	  function toggleHmbGuests(e) {
	    e.stopPropagation();
	    hmbPopOpen = !hmbPopOpen;
	    document.getElementById('hmb-guests-popover').classList.toggle('open', hmbPopOpen);
	  }
	  function adjHmb(type, delta) {
	    hmbGuests[type] = Math.max(type === 'adults' ? 1 : 0, hmbGuests[type] + delta);
	    document.getElementById('hmb-adults-val').textContent   = hmbGuests.adults;
	    document.getElementById('hmb-children-val').textContent = hmbGuests.children;
	    document.getElementById('hmb-adults-minus').disabled   = hmbGuests.adults   <= 1;
	    document.getElementById('hmb-children-minus').disabled = hmbGuests.children <= 0;
	    var parts = [];
	    if (hmbGuests.adults)   parts.push(hmbGuests.adults + ' adult' + (hmbGuests.adults > 1 ? 's' : ''));
	    if (hmbGuests.children) parts.push(hmbGuests.children + ' child' + (hmbGuests.children > 1 ? 'ren' : ''));
	    document.getElementById('hmb-guests-lbl').textContent = parts.length ? parts.join(', ') : 'Guests';
	  }
	  function hmbResortChange() { /* resort shown via select element natively */ }
	  function hmbDateChange(which) {
	    if (which === 'checkin') {
	      var ci = document.getElementById('hmb-checkin').value;
	      setDisplayDate('hmb-checkin', 'hmb-checkin-display', 'Check In');
	      if (ci) {
	        var mn = new Date(ci + 'T00:00:00'); mn.setDate(mn.getDate() + 4);
	        var ms = toDateStr(mn);
	        var coEl = document.getElementById('hmb-checkout');
	        coEl.min = ms;
	        if (coEl.value && coEl.value < ms) {
	          coEl.value = '';
	          document.getElementById('hmb-checkout-display').textContent = 'Check Out';
	          document.getElementById('hmb-checkout-display').classList.remove('has-value');
	        }
	      }
	    } else {
	      setDisplayDate('hmb-checkout', 'hmb-checkout-display', 'Check Out');
	    }
	  }
	  function hmbSearch() {
	    var resort = document.getElementById('hmb-resort').value;
	    if (!resort) { return; }
	    var ci = document.getElementById('hmb-checkin').value;
	    var co = document.getElementById('hmb-checkout').value;
	    window.location.href = '/accommodation/?resort=' + encodeURIComponent(resort)
	      + (ci ? '&checkin=' + encodeURIComponent(ci) : '')
	      + (co ? '&checkout=' + encodeURIComponent(co) : '')
	      + '&adults=' + hmbGuests.adults + '&children=' + hmbGuests.children;
	  }
	</script>

	<?php
}

?>
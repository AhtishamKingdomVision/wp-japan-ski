<?php
$acc_details = get_field('accomodation_details');
$acc_form = $acc_details['accommodation_form'] ?? false;
$address = $acc_details['address'] ?? '';
$acco_image_gallery = get_field('acco_image_gallery');
$bg_color   = $acc_details['bg_color'] ?? '#01111f';
$section_style = $bg_color ? 'style="background-color:' . esc_attr($bg_color) . ';"' : 'xyz';
$ff_image     = get_field('form_footer_image', 'option');
$ff_content   = get_field('form_footer_content', 'option');
echo '<section class="form_area acc-single-banner full-section" '. $section_style .' aria-labelledby="acc-title">';
	echo '<div class="container">';
		echo '<div class="left-side">';
			echo '<a class="btn desktop-none quote_toggle" href="javascript:void();">Get a Quote</a>';
			echo '<div class="title-wrapper">';
				echo '<h1>'. get_the_title() .'</h1>';
			echo '</div>'; #title-wrapper
			echo '<div class="single_review">';
				echo do_shortcode('[sku_reviews]');
			echo '</div>'; //single_review
			if($address){
				echo '<div class="acc-address">';
					echo '<p>'.$address.'</p>';
				echo '</div>'; #acc-address
			}
			if($acco_image_gallery){
				echo '<div class="acc-gallery">';
					$count = count($acco_image_gallery);
					foreach( $acco_image_gallery as $key => $image_id ){
						echo '<div class="galleryItem" data-fancybox="gallery" data-src="'.wp_get_attachment_image_url( $image_id, 'full').'">';
							if($key == 0){
								echo '<span>All Photos ('.$count.')</span>';
							}
							echo wp_get_attachment_image( $image_id, 'full' );
						echo '</div>'; #galleryItem
					}
				echo '</div>'; #acc-gallery
			}
		echo '</div>'; #left-side
		if($acc_form == false){
			echo '<div class="right-side">';
				echo '<a class="btn desktop-none quote_toggle" href="javascript:void();">Get a Quote</a>';
				echo '<div class="mob_quote_form">';
					echo '<div class="mob_quote_inner">';
						echo '<a class="btn desktop-none close_mob_quote_form" href="javascript:void();"><i class="fa-solid fa-x"></i></a>';
						echo do_shortcode('[gravityform id="1" title="true"]');
					echo '</div>'; //mob_quote_inner
				echo '</div>'; //mob_quote_form
                if ($ff_image && $ff_content) {
                    echo '<div class="ff_content_image">';
                        echo '<div class="ff_image">';
                            echo wp_get_attachment_image($ff_image, 'full');
                        echo '</div><!-- ff_image -->';

                        echo '<div class="ff_content">';
                            echo wp_kses_post($ff_content);
                        echo '</div><!-- ff_content -->';
                    echo '</div><!-- ff_content_image -->';
                }
			echo '</div>'; #right-side
		}
	echo '</div>'; #container
echo '</section>'; #acc-single-banner

?>
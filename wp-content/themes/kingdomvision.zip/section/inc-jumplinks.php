<?php
    $jumplink = $section["jumplink"] ?? [];
    echo '<section class="full-section jumplinks" id="jumplink-nav">';
        echo '<div class="container">';
            if (!empty($jumplink)) {
    			echo '<a class="mob_button" href="javascript:;">Jump to:</a>';
                echo '<div class="mobJumplinkWrapper">';
	                echo '<div class="jumplink-wrapper">';
	                foreach ($jumplink as $item) {
	                    $link = $item["link"] ?? "";
	                    if (!empty($link)) {
	                        $url = $link["url"] ?? "";
	                        $title = $link["title"] ?? "";
	                        $target = !empty($link["target"]) ? $link["target"] : "_self";
	                        echo '<a class="jumplink-item"href="' .
	                            esc_url($url) .
	                            '"target="' .
	                            esc_attr($target) .
	                            '">';
	                        echo esc_html($title);
	                        echo "</a>";
	                    }
	                }
	                echo "</div>";
                echo "</div>";
            }
        echo "</div>";
    echo "</section>";
?>


<script>
	jQuery(function($){
		// mob_button Click
		$(document).on('click' , 'a.mob_button', function(){
	        $(this).parents(".jumplinks").find(".mobJumplinkWrapper").slideToggle();
	        $(this).toggleClass('active');
	    });

		// jumplink-wrapper a Click
		$(document).on('click' , '.jumplinks .jumplink-wrapper a', function(e){
 			e.preventDefault();       

 			$('.jumplinks .jumplink-wrapper a').removeClass('active');
 			$(this).addClass('active');

 			$('.mobJumplinkWrapper').removeClass('active');

 			if ($(window).width() <= 767) {
	            $(this).parents('.jumplinks').find(".mobJumplinkWrapper").slideUp();
	        }

	        let selectedText = $(this).text();
// 	        console.log(selectedText);
	        $(this).parents('.jumplinks').find(".mob_button").text(selectedText);

			let currLink = $(this).attr('href');
			if ($(currLink).length) {
				let $target = currLink.replace(/#/g, '');
				let $section = $(`section[id="${$target}"]`).offset().top;

				if($section){
					let $minusTop = '';
						$minusTop = $('.jumplinks').innerHeight() + $('.main-header').innerHeight();
					$('html, body').stop().animate({
						scrollTop: $(`section[id="${$target}"]`).offset().top - $minusTop
					}, 400);
				}
			}

		});

		// scroll active
		$(window).on('scroll', function () {
	        let scrollPos = $(window).scrollTop();
	        let headerHeight = $('.jumplinks').innerHeight() + $('.main-header').innerHeight();

	        $('.jumplinks .jumplink-wrapper a').each(function () {
	            let currLink = $(this);
	            let ref = currLink.attr('href');

	            if ($(ref).length) {
	                let sectionTop = $(ref).offset().top - headerHeight ;
	                let sectionBottom = sectionTop + $(ref).innerHeight();

	                if (scrollPos >= sectionTop && scrollPos < sectionBottom) {
	                    $('.jumplinks .jumplink-wrapper a').removeClass('active');
	                    currLink.addClass('active');
	                }
	            }
	        });
	    });

	})
	


</script>
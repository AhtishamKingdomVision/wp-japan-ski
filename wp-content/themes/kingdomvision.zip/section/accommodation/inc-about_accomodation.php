<?php

$content = $section['content'] ?? '';
$ammenites_title = $section['ammenites_title'] ?? '';
$ammenites = $section['ammenites'] ?? [];

echo '<section class="full-section about-accomodation" ' . BackgroundFromSection($section) . '>';
    echo '<div class="container">';
        echo '<div class="flex-wrap">';
            echo '<div class="left-side">';
                echo TitleFromSection($section);
                echo WysiwygReadMoreLess($content);
            echo '</div>'; #left-side
            echo '<div class="right-side">';
                if($ammenites_title){
                    echo '<h3>'.$ammenites_title.'</h3>';
                }
                if($ammenites){
                    $count = count($ammenites);
                    echo '<ul class="ammenites" data-ammenites="'.$count.'">';
                        foreach ($ammenites as $key => $value) {
                            $icon = $value['icon'];
                            $label = $value['label'];
                            $icon_map = [
                                '4wd'            => get_template_directory_uri() . '/images/icons/4wd.svg',
                                'dishwasher'     => get_template_directory_uri() . '/images/icons/dishwasher.svg',
                                'fullkitchen'    => get_template_directory_uri() . '/images/icons/fullkitchen.svg',
                                'laundry'        => get_template_directory_uri() . '/images/icons/laundry.svg',
                                'microwave'      => get_template_directory_uri() . '/images/icons/microwave.svg',
                                'satellite'      => get_template_directory_uri() . '/images/icons/satellite.svg',
                                'air'            => get_template_directory_uri() . '/images/icons/air.svg',
                                'breakfast'      => get_template_directory_uri() . '/images/icons/breakfast.svg',
                                'parking'        => get_template_directory_uri() . '/images/icons/parking.svg',
                                'pet'            => get_template_directory_uri() . '/images/icons/pet.svg',
                                'restaurants'    => get_template_directory_uri() . '/images/icons/restaurants.svg',
                                'shuttleservice' => get_template_directory_uri() . '/images/icons/shuttleservice.svg',
                                'wifi'           => get_template_directory_uri() . '/images/icons/wifi.svg',
                                'apple'          => get_template_directory_uri() . '/images/icons/apple.svg',
                                'bath'           => get_template_directory_uri() . '/images/icons/bath.svg',
                                'concierge'      => get_template_directory_uri() . '/images/icons/concierge.svg',
                                'dryroom'        => get_template_directory_uri() . '/images/icons/dryroom.svg',
                                'fire'           => get_template_directory_uri() . '/images/icons/fire.svg',
                                'lifts'          => get_template_directory_uri() . '/images/icons/lifts.svg',
                                'phone'          => get_template_directory_uri() . '/images/icons/phone.svg',
                                'sound'          => get_template_directory_uri() . '/images/icons/sound.svg',
                                'hottube'          => get_template_directory_uri() . '/images/icons/hottube.svg',
                                'onsen'          => get_template_directory_uri() . '/images/icons/onsen.svg',
                                'onsite'          => get_template_directory_uri() . '/images/icons/onsite.svg',
                                'skiinskiout'          => get_template_directory_uri() . '/images/icons/skiinskiout.svg',
                            ];


                            if ($label && !empty($icon) && $icon !== 'none') {
                                $icon_url = isset($icon_map[$icon]) ? $icon_map[$icon] : '';
                                if ($icon_url) {
                                    echo '<li>';
                                        echo '<span class="icon">';
                                            echo '<img src="' . esc_url($icon_url) . '" alt="' . esc_attr($label) . '" />';
                                        echo '</span>';
                                        echo '<span class="text">' . esc_html($label) . '</span>';
                                    echo '</li>';
                                }
                            }

                        }
                    echo '</ul>';
                }
            echo '</div>'; #right-side
        echo '</div>'; #flex-wrap
    echo '</div>'; // container
echo '</section>'; #about-accomodation
?>


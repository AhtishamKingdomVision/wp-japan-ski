<?php 
$offers = $section['offers'] ?? [];

if (!empty($offers)) :
    echo '<section ' . SectionAttributes($section, 'full-section unbeatable_offers') . ' ' . BackgroundFromSection($section) . ' aria-labelledby="unbeatable-offers-title">';
        echo '<div class="container">';
            echo TitleFromSection($section);
		echo '</div>'; // container

	 		echo '<div class="offer_cover">';
				echo '<div class="offers" role="list">';

					foreach ($offers as $o) :

						$image   = $o['image']   ?? '';
						$content = $o['content'] ?? '';
						$button  = $o['button']  ?? null;

						echo '<div class="off_ers" role="listitem">';

							if ($image) {
								echo wp_get_attachment_image(
									$image,
									'full',
									false,
									[
										'class' => 'offer-image',
										'alt'   => esc_attr(get_post_meta($image, '_wp_attachment_image_alt', true))
									]
								);
							}

							if ($content) {
								echo '<div class="offer-content">';
								echo wp_kses_post($content);
								if (!empty($button)) :
									$link_url    = esc_url($button['url'] ?? '#');
									$link_title  = esc_html($button['title'] ?? 'Learn more');
									$link_target = esc_attr($button['target'] ?? '_self');

									echo '<a class="btn" href="'
										. $link_url
										. '" target="'
										. $link_target
										. '" aria-label="'
										. $link_title
										. '">'
										. $link_title
										. '</a>';
								endif;
								echo '</div>';
							}

						echo '</div>'; // off_ers

					endforeach;

				echo '</div>'; // offers
			echo '</div>';  //offer_cover
    echo '</section>';

endif;
?>
<?php

/**
 * Accommodation Card Template (ACF-based with RoomBoss fallback)
 * Displays a single accommodation listing with image, price, and booking options
 * 
 * Uses ACF fields for property data and RoomBoss API for live pricing
 * Requires: get_the_ID(), get_field(), get_the_terms(), get_hotel_rooms()
 */

try {
    // ✅ STEP 1: Validate post context
    $post_id = get_the_ID();
    if (empty($post_id)) {
        return;
    }

    // ✅ STEP 2: Retrieve and validate ACF fields
    $is_roomboss = (bool) get_field('is_roomboss', $post_id);
    $image = get_field('accommodation_list_image', $post_id);
    $short_desc = sanitize_text_field(get_field('bs_short_description', $post_id) ?? '');
    $db_price = (float) (get_field('min_room_price', $post_id) ?? 0);
    $overlay = (bool) get_field('overlay', $post_id);
    $hotel_tid = intval(get_field('acc_hotel_id', $post_id) ?? 0);

    // ✅ STEP 3: Process resort and area information
    $resort_name = '';
    $areas = '';
    $area_list = get_field('area', $post_id);
    
    if (!empty($area_list) && is_array($area_list)) {
        // Filter and sanitize area names
        $area_list = array_filter(array_map('sanitize_text_field', $area_list));
        $areas = implode(', ', $area_list);
    }

    // ✅ STEP 4: Get category/resort name
    $categories = get_the_terms($post_id, 'accommodation-cat');
    if (!empty($categories) && !is_wp_error($categories)) {
        $resort_name = str_replace(' Accommodation', '', sanitize_text_field($categories[0]->name ?? ''));
    }

    // ✅ STEP 5: Calculate pricing with fallback to RoomBoss
    $rb_price = 0;
    $rb = $GLOBALS['kv_roomboss_current'] ?? null;
    pre( var_dump( $rb ) );
    if (!empty($rb) && isset($rb['min_price'])) {
        $rb_price = (float) $rb['min_price'];
    }
    $price = ($db_price > 0) ? $db_price : $rb_price;

    // ✅ STEP 6: Process accommodation image
    $placeholder = get_stylesheet_directory_uri() . '/images/placeholder-listing.jpg';
    $image_url = $placeholder;

    if (!empty($image)) {
        if (is_numeric($image)) {
            // Image is attachment ID
            $img = wp_get_attachment_image_src((int) $image, 'large');
            if (!empty($img[0])) {
                $image_url = esc_url_raw($img[0]);
            }
        } elseif (is_array($image)) {
            // Image is array (ACF image field)
            if (!empty($image['sizes']['large'])) {
                $image_url = esc_url_raw($image['sizes']['large']);
            } elseif (!empty($image['url'])) {
                $image_url = esc_url_raw($image['url']);
            }
        } elseif (is_string($image)) {
            // Image is string URL
            $image_url = esc_url_raw($image);
        }
    }

    // ✅ STEP 7: Get room count safely
    $room_count = 0;
    if (!empty($hotel_tid)) {
        $hotel_data = get_hotel_rooms($hotel_tid);
        if (is_array($hotel_data) && isset($hotel_data['rooms'])) {
            $room_count = count($hotel_data['rooms']);
        }
    }

    // ✅ STEP 8: Prepare button state
    $post_title = get_the_title();
    $post_permalink = get_permalink();

} catch (Exception $e) {
    // ❌ Handle unexpected errors
    error_log('Error in accommodation-box template: ' . $e->getMessage());
    return;
}

?>

<div class="result-card accom-card <?php echo $overlay ? 'has-overlay' : ''; ?>" data-hotel-id="<?php echo esc_attr($hotel_tid); ?>">

    <a href="<?php echo esc_url($post_permalink); ?>">
        <div class="accom-image" style="background-image: url('<?php echo esc_url($image_url); ?>');"
            aria-label="<?php echo esc_attr($post_title); ?>"
            role="img">
            <?php if ($is_roomboss) : ?>
                <?php echo wp_get_attachment_image(30809, 'thumbnail', true, ['class' => 'is_roomboss-icon', 'alt' => 'Live availability']); ?>
            <?php endif; ?>
        </div>

        <div class="accom-content">
            <h3><?php echo esc_html($post_title); ?></h3>

            <!-- Price Display -->
            <?php if ($price > 0) : ?>
                <p class="price">
                    From JPY <?php echo number_format_i18n((int) $price); ?>
                    <span>/ night</span>
                </p>
            <?php endif; ?>

            <!-- Area and Resort Info -->
            <?php if (!empty($resort_name) || !empty($areas)) : ?>
                <p class="area_resort">
                    <?php if (!empty($resort_name)) : ?>
                        <?php echo esc_html($resort_name); ?>&nbsp;
                    <?php endif; ?>
                    <?php if (!empty($areas)) : ?>
                        <?php echo esc_html($areas); ?>
                    <?php endif; ?>
                </p>
            <?php endif; ?>

            <!-- Short Description -->
            <?php if (!empty($short_desc)) : ?>
                <p class="desc"><?php echo esc_html($short_desc); ?></p>
            <?php endif; ?>

            <!-- Action Button -->
            <?php if ($is_roomboss) : ?>
                <span class="book_btn btn" data-room_id="<?php echo esc_attr($post_id); ?>">
                    Book Now
                </span>
            <?php else : ?>
                <span class="enquire_btn btn" data-room_id="<?php echo esc_attr($post_id); ?>">
                    Enquire
                </span>
            <?php endif; ?>

            <!-- Details Link -->
            <span class="view_book btn">
                Details
            </span>
        </div>
    </a>

</div>
<?php
// ✅ STEP 1: Fetch fields once and cache results (avoid duplicate get_field calls)
$property_id = get_field('property_id');
$property_id = !empty($property_id) ? $property_id : false;

// ✅ STEP 2: Get room data via helper function
$data = get_hotel_rooms($property_id);

// ✅ STEP 3: Validate array structure before accessing keys
if (!is_array($data)) {
    $data = ['rooms' => [], 'bedroom_types' => []];
}

$rooms = get_field('unit_count') ?? $data['rooms']; // Rooms data
if(!is_array($rooms) ) {
    $rooms = [];
}
// pre('rooms: ' . $rooms);
$available_bedroom_types = is_array($data['bedroom_types']) ? $data['bedroom_types'] : []; // Available bedroom types

// ✅ STEP 4: Fetch and validate roomboss field once
$is_roomboss = !empty(get_field('is_roomboss')) ? true : false;
?>
<section class="room-listing">
    <div class="container">

        <div class="main-title">
            <h2>Rooms at <?php echo get_the_title(); ?></h2>
        </div>
        <!-- Search Filter Form -->
        <div class="room-search">
            <!-- ✅ STEP 5: Add proper escaping for form attributes -->
            <form id="room-filter-form" method="POST" property-id="<?php echo esc_attr($property_id); ?>" acc-id="<?php echo esc_attr(get_the_ID()); ?>" room-id="<?php echo esc_attr(get_the_ID()); ?>">
                <div class="search-fields">
                    <div class="field">
                        <label for="sc-check-in">Check In</label>
                        <input type="text" id="sc-check-in" class="sv-check-in" name="checkin" autocomplete="off" placeholder="Enter your check in dates" required>
                    </div>

                    <div class="field">
                        <label for="sc-check-out">Check Out</label>
                        <input type="text" id="sc-check-out" class="sv-check-out" name="checkout" autocomplete="off" placeholder="Enter your check out dates" required>
                    </div>
                </div>
                <button type="submit" class="rooms-sc-btn">Check Rates</button>
            </form>
        </div>

        <div class="rooms-wrap">
            <!-- Bedroom Tabs -->
            <div class="bedroom-tabs">
                <?php if ($is_roomboss): ?>
                    <div class="available_units">
                        <span class="units_avl">
                            <?php echo count( $rooms ) ?>    
                        </span>
                         unit type<?php echo count( $rooms ) > 1 ? 's' : ''; ?> available out of 
                        <span class="total_units">
                            <?php echo count( $rooms ) ?> 
                        </span>
                    </div>
                <?php
                else: ?>
                    <div class="available_units">
                        This property has <span class="total_units"><?php echo count( $rooms ) ?></span> unit type<?php echo count( $rooms ) > 1 ? 's' : ''; ?> - enquire for availability.
                    </div>
                <?php endif ?>
                <button type="button" class="bedroom-tab active" data-bedroom="all">All Bedrooms</button>
                <?php foreach ($available_bedroom_types as $bedroom_type) : ?>
                    <button type="button" class="btn bedroom-tab" data-bedroom="<?php echo $bedroom_type; ?>">
                        <?php echo $bedroom_type; ?> Bedroom<?php echo $bedroom_type > 1 ? 's' : ''; ?>
                    </button>
                <?php endforeach; ?>
            </div>


            <?php $abc = false; 
                //if ( $abc ): ?>
                
                <!-- Room Listings -->
                <div class="room-list">
                    <div class="row" id="room-results">
                        <?php
                        if (!empty($rooms)) :
                            foreach ($rooms as $room) :
                                get_template_part('partials/room-box', null, ['room' => $room, 'rb' => $is_roomboss, 'property_id' => $property_id]);
                            endforeach;
                        else :
                            echo '<p>No rooms available at the moment.</p>';
                        endif;
                        ?>
                    </div>
                </div>
            <?php //endif ?>
            <div class="booking-wrap" style="display:none; background-color: #00111e;">
                <!-- <button class="back-to-rooms btn-outline">← Back</button> -->
                <div class="booking-layout">

                    <!-- LEFT: Selected room + rate plans -->
                    <div class="booking-left">
                        <div class="booking-room-card">
                            <h3 class="booking-room-title">Deluxe Studio</h3>
                            <p class="booking-dates">Dec 13 – 20, 2025</p>

                            <div class="booking-meta">
                                <span>👤 2</span>
                                <span>🛏 1</span>
                                <span>🛁 1</span>
                            </div>
                        </div>

                        <!-- RATE PLANS -->
                        <div class="rate_plan_box selected">
                            <h4>Summer Stay</h4>
                            <p>Free cancellation up to 3 days before check-in</p>

                            <div class="price">
                                <span class="old">¥235,000</span>
                                <strong>¥211,500</strong>
                            </div>

                            <button class="btn select-rate">Selected</button>
                        </div>
                    </div>

                    <!-- RIGHT: BOOKING SUMMARY -->
                    <div class="booking-right">
                        <h3>Booking Summary</h3>

                        <div class="summary-item">
                            <span>Deluxe Studio</span>
                            <span>¥235,000</span>
                        </div>

                        <div class="summary-dates">
                            <div><b>Check in</b> 13/12/2025</div>
                            <div><b>Check out</b> 20/12/2025</div>
                        </div>

                        <div class="summary-total">
                            <strong>Total</strong>
                            <strong>¥235,000</strong>
                        </div>

                        <button class="btn proceed-btn">Proceed</button>
                    </div>

                </div>
            </div>
        </div>

        <div id="room-modal" class="room-modal" style="display: none;">
            <div class="room-modal-content">
                <button class="room-modal-close">&times;</button>
                <div id="room-modal-body"></div>
            </div>
        </div>

    </div>
</section>

<script>
    jQuery(function($) {

        // ✅ HELPER: Common AJAX error handler to reduce code duplication
        function handleAjaxError(xhr, exception, $target) {
            let msg = '';
            
            if (xhr.status === 0) {
                msg = 'Internet not connected. Verify Network.';
                alert(msg);
            } else if (exception === 'timeout') {
                msg = 'Request timed out. Please try again.';
                alert(msg);
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else if (xhr.status === 404) {
                msg = 'Requested page not found. [404]';
            } else if (xhr.status === 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === '') {
                msg = 'Requested JSON parse failed.';
            } else {
                msg = 'Error: ' + xhr.status + ' ' + xhr.responseText;
            }

            console.error('AJAX Error:', msg);
            return msg;
        }

        // ✅ HELPER: Validate form input existence and get value safely
        function getFieldValue(selector) {
            const $field = $(selector);
            if ($field.length === 0) {
                console.warn('Field not found:', selector);
                return '';
            }
            return $field.val() || '';
        }

        // ✅ HELPER: Validate and get numeric value from field
        function getNumericValue(value, defaultVal = 0) {
            const num = parseInt(value);
            return isNaN(num) ? defaultVal : num;
        }

        // ✅ HELPER: Consolidate localStorage operations
        const rb_storage = {
            get: function(key) {
                try {
                    return localStorage.getItem(key);
                } catch (e) {
                    console.error('localStorage read error:', e);
                    return null;
                }
            },
            set: function(key, value) {
                try {
                    localStorage.setItem(key, value);
                } catch (e) {
                    console.error('localStorage write error:', e);
                }
            },
            remove: function(key) {
                try {
                    localStorage.removeItem(key);
                } catch (e) {
                    console.error('localStorage remove error:', e);
                }
            },
            getJSON: function(key) {
                try {
                    const val = localStorage.getItem(key);
                    return val ? JSON.parse(val) : null;
                } catch (e) {
                    console.error('localStorage JSON parse error:', e);
                    return null;
                }
            },
            setJSON: function(key, obj) {
                try {
                    localStorage.setItem(key, JSON.stringify(obj));
                } catch (e) {
                    console.error('localStorage JSON write error:', e);
                }
            }
        };

        var acc_id = $( '#room-filter-form' ).attr( 'acc-id' );

        const uiState = rb_storage.get('rb_ui_state');
        const ratesChecked = rb_storage.get( acc_id+'_rates_checked') === 'true';

        var room_id = $( '#room-filter-form' ).attr( 'room-id' );
        var header_height = $( 'header' ).outerHeight();

        const to_form = rb_storage.get( 'go_to_form' );

        if( to_form == room_id ){
            $('html, body').animate({
                scrollTop: ( $('#room-filter-form').offset().top - header_height )
            }, 400);
            rb_storage.remove( 'go_to_form' );
        }

        var niseko_checkin = rb_storage.get('niseko_checkin');
        var niseko_checkout = rb_storage.get('niseko_checkout');

        show_booking_ui();

        function show_booking_ui(){

            let form = $('#room-filter-form'),
                property_id = form.attr('property-id'),
                checkin = form.find('#sc-check-in').val(),
                checkout = form.find('#sc-check-out').val();

            const payload = {
                action: 'load_roomboss_booking',
                property_id: property_id,
                start_date: checkin,
                end_date: checkout,
            };
            // Basic validation
            if (!payload.start_date || !payload.end_date) {
            $( '.room-list' ).show();
                // alert('Please select check-in and check-out dates');
                return;
            }

            $('.booking-wrap')
            .html('<div class="rb-loading">Loading booking…</div>')
            .show();

            $('.room-list').hide();

            $.ajax({
                url: kv_object.ajaxurl,
                type: 'POST',
                data: payload,
                dataType: 'json',
                success: function(resp) {
                    if (resp && resp.success) {
                        // ✅ SAVE UI STATE
                        localStorage.setItem('rb_ui_state', 'booking');
                        $('.booking-wrap').html(resp.data.html);

                        updateBedroomTabs(resp.data.available_bedroom_types);
                        $('.rooms-sc-btn')
                            .prop('disabled', false)
                            .removeClass('loading')
                            .text('Check Rates');
                        scrollToRoom($('.rooms-wrap'));
                        $('.room-list').fadeOut(200, function() {
                            $('#room-modal').fadeOut(200);
                            $('.booking-wrap')
                                .hide()
                                .html(resp.data.html)
                                .fadeIn(200);
                        });

                        // $('.booking-wrap').html(resp.data.html);
                        if (typeof kv_booking_init === 'function') {
                            kv_booking_init();
                            // console.log( 'booking init done' );
                        }

                        var rooms_count = $( '.rb-room-card' ).length;
                        $('.units_avl').text( rooms_count );

                        if ($('.room-list').is(':visible')) {
                            $('.room-list').hide();
                        }

                    }
                    else {
                        $('.booking-wrap').html(
                            '<p class="rb-error">' +
                            (resp?.data?.message || 'No data returned') +
                            '</p>'
                        );
                        $('.units_avl').text( 0 );
                    }
                },
                error: function (xhr, exception) {
                    $('.booking-wrap').html(
                        '<p class="rb-error">Unable to load booking data.</p>'
                    );

                    handleAjaxError(xhr, exception);

                    $('.rooms-sc-btn')
                    .prop('disabled', false)
                    .removeClass('loading')
                    .text('Check Rates');
                }
            });

        }

        $(document).on('click', '.roomboss_btn', function() {

            room_filter_submit_func();

        });

        $(document).on('click', '.book-btn', booking_form_func);

        function booking_form_func (e) {
            if (e && typeof e.preventDefault === 'function') {
                e.preventDefault();
            }

            // ✅ STEP 1: Validate rates checked status
            const ratesChecked = rb_storage.get( acc_id+'_rates_checked') === 'true';
            const niseko_checkin = rb_storage.get('niseko_checkin');
            const niseko_checkout = rb_storage.get('niseko_checkout');

            if (  !ratesChecked && ( !niseko_checkin || !niseko_checkout ) ) {
                alert('Please enter dates.');
                return;
            }

            // ✅ STEP 2: Setup button state
            const $btn = $(this);
            const originalText = $btn.text();

            // ✅ STEP 3: Get booking context (validate existence)
            const bookingContextStr = rb_storage.get('rb_booking_context');
            if (!bookingContextStr) {
                alert('Booking data missing. Please search again.');
                return;
            }

            let bookingContext;
            try {
                bookingContext = JSON.parse(bookingContextStr);
            } catch (e) {
                console.error('Failed to parse booking context:', e);
                alert('Booking data corrupted. Please search again.');
                return;
            }

            // ✅ STEP 4: Validate booking context required fields
            if (!bookingContext.checkin || !bookingContext.checkout || !bookingContext.property_id) {
                alert('Booking data missing. Please search again.');
                return;
            }

            // ✅ STEP 5: Build and validate payload
            const payload = {
                action: 'load_roomboss_booking',
                property_id: bookingContext.property_id,
                start_date: bookingContext.checkin,
                end_date: bookingContext.checkout,
                adults: getNumericValue($('#adults').val()),
                children: getNumericValue($('#children').val()),
                infants: getNumericValue($('#infants').val())
            };

            if (!payload.start_date || !payload.end_date) {
                alert('Please select check-in and check-out dates');
                return;
            }

            $btn
                .prop('disabled', true)
                .addClass('loading')
                .text('Loading…');

            // ✅ STEP 6: Send AJAX request
            $.ajax({
                url: kv_object.ajaxurl,
                type: 'POST',
                data: payload,
                dataType: 'json',
                beforeSend: function(jqXHR, settings) {
                  $('.booking-wrap').html( '<div class="rb-loading">Loading booking…</div>' );
                },
                success: function(resp) {
                    if (resp && resp.success) {
                        // ✅ SAVE UI STATE
                        rb_storage.set('rb_ui_state', 'booking');
                        $('.room-list').fadeOut(200, function() {
                            $('#room-modal').fadeOut(200);
                            $('.booking-wrap')
                                .hide()
                                .html(resp.data.html)
                                .fadeIn(200);
                        });
                        // $('.booking-wrap').html(resp.data.html);
                        if (typeof kv_booking_init === 'function') {
                            kv_booking_init();
                        }
                    } else {
                        $('.booking-wrap').html(
                            '<p class="rb-error">' +
                            (resp?.data?.message || 'No data returned') +
                            '</p>'
                        );
                    }
                },
                error: function ( xhr, exception ){
                    $('.booking-wrap').html(
                        '<p class="rb-error">Unable to load booking data.</p>'
                    );

                    handleAjaxError(xhr, exception);

                    $('.rooms-sc-btn')
                    .prop('disabled', false)
                    .removeClass('loading')
                    .text('Check Rates');
                },
                complete: function() {
                    $btn
                        .prop('disabled', false)
                        .removeClass('loading')
                        .text(originalText);
                }
            });
        }

        function handle_layout(){
            var rbcart = $('aside.rb-cart');
            var body = $('body');
            if(isMobile()){
                console.log( 'isMobile' );
                body.addClass('mobile');

                if( rbcart.length > 0 && body.hasClass( 'mobile' ) ){
                    console.log( 'Moving cart for mobile layout' );

                    // Move rbcart to be the first child of the body
                    rbcart.prependTo(body);
                }
            }
            else{
                var rbcart = $('aside.rb-cart');
                var parent = $('.rb-booking-layout');

                if( rbcart.length > 0 && body.hasClass( 'mobile' ) ){
                    console.log( 'Moving cart back for desktop layout' );

                    body.removeClass('mobile');
                    // Move rbcart to be the first child of the body
                    rbcart.appendTo(parent);
                }
            }
        }

        window.addEventListener("resize", function() {
          var rbcart = $('aside.rb-cart');
          if ( rbcart.length > 0 ) {
            console.log('Window resized, handling layout');
            handle_layout();
          }
        });

        $(document).on('change', '.rb-guest-input', function() {

            const $room = $(this).closest('.rb-room-card');
            const $form = $room.find('.rb-guests-form');
            const $btn = $room.find('.rb-select-btn');

            const adultsField = $form.find('.rb-adults');
            const childrenField = $form.find('.rb-children');
            const infantsField = $form.find('.rb-infants');

            const adults = getNumericValue(adultsField.val());
            const children = getNumericValue(childrenField.val());
            const infants = getNumericValue(infantsField.val());

            const maxGuests = getNumericValue($room.find('.rb-icon.guest').text());
            const maxInfants = getNumericValue($room.find('.rb-icon.infant').text());

            // ✅ Get or create error containers
            let $guestErr = $room.find('.rb-error-guests');
            let $infantErr = $room.find('.rb-error-infants');

            if (!$guestErr.length) {
                $guestErr = $('<div class="rb-error rb-error-guests"></div>').insertAfter($form);
            }
            if (!$infantErr.length) {
                $infantErr = $('<div class="rb-error rb-error-infants"></div>').insertAfter($form);
            }

            // ✅ Reset errors
            $guestErr.hide().text('');
            $infantErr.hide().text('');
            $form.find('.rb-guest-input').css('border', '');
            $btn.prop('disabled', false);

            let hasError = false;

            // ✅ STEP 1: Adults mandatory (hard return)
            if (!adults || adults < 1) {
                adultsField.css('border', '2px solid red');
                $guestErr.text('Please select number of adults staying in this room.').show();
                $btn.prop('disabled', true);
                return;
            }

            // ✅ STEP 2: Non-infant guest validation
            const guestTotal = adults + children;

            if (guestTotal > maxGuests) {
                adultsField.add(childrenField).css('border', '2px solid red');
                $guestErr
                    .text(`Total guests (${guestTotal}) cannot exceed ${maxGuests}.`)
                    .show();
                hasError = true;
            }

            // ✅ STEP 3: Infant validation (independent)
            if (infantsField.length && infants > 0) {
                if ((guestTotal + infants) > (maxGuests + maxInfants)) {
                    infantsField.css('border', '2px solid red');
                    $infantErr
                        .text(
                            `Total guests + infants cannot exceed ${maxGuests + maxInfants}.`
                        )
                        .show();
                    hasError = true;
                }
            }

            // ✅ STEP 4: Final state
            if (hasError) {
                scrollToRoom($room);
                $btn.prop('disabled', true);
            } else {
                $guestErr.hide();
                $infantErr.hide();
                $form.find('.rb-guest-input').css('border', '');
                $btn.prop('disabled', false);
            }
        });

        // ✅ Mark rates as unchecked when form changes
        $(document).on('change', '#room-filter-form input, #room-filter-form select', function() {
            rb_storage.set( acc_id+'_rates_checked', 'false');
            rb_storage.set('rb_ui_state', 'list');
        });

        // Open modal
        $(document).on('click', '.details-btn', function(e) {
            e.preventDefault();

            const $btn = $(this);
            const originalText = $btn.text();

            const roomId = $(this).attr('room-id');
            const propertyId = $(this).attr('property-id');

            // 🔄 Button loading state
            $btn
                .prop('disabled', true)
                .addClass('loading')
                .text('Loading…');

            // $('#room-modal').fadeIn(200);
            // $('body').css('overflow', 'hidden');
            // $('#room-modal-body').html('<p>Loading...</p>');
            $.ajax({
                url: kv_object.ajaxurl, // WordPress AJAX URL
                method: 'POST',
                data: {
                    action: 'niseko_load_room_details', // The action to handle the request
                    room_id: roomId,
                    property_id: propertyId
                },
                success: function(res) {
                    if (res.success) {
                        $('#room-modal-body').html(res.data.html);


                        // setTimeout(() => {
                        //     initRoomGallery()
                        // }, 200);
                        // initRoomGallery();
                        $('#room-modal').fadeIn(200, function() {
                            const $gallery = $('.js-room-gallery');
                            const $images = $gallery.find('img');

                            let imagesLoaded = 0;
                            $images.each(function() {
                                if (this.complete) {
                                    imagesLoaded++;
                                } else {
                                    $(this).on('load', () => {
                                        imagesLoaded++;
                                        if (imagesLoaded === $images.length) initRoomGallery();
                                    });
                                }
                            });

                            // If all images are already loaded
                            if (imagesLoaded === $images.length) {
                                initRoomGallery();
                            }
                        });


                        $('.book-btn').prop('disabled', false).removeClass('disabled');

                    } else {
                        $('#room-modal-body').html('<p>Error loading room details.</p>'); // Error message

                        $('.book-btn').prop('disabled', false).removeClass('disabled');
                    }
                },
                error: function (xhr, exception) {
                    // ✅ Use consolidated error handler
                    handleAjaxError(xhr, exception);
                    $('#room-modal-body').html('<p class="rb-error">Error loading room details.</p>'); // Error message
                },
                complete: function() {
                    // 🔁 Restore button
                    $btn
                        .prop('disabled', false)
                        .removeClass('loading')
                        .text(originalText);
                }
            });
        });

        // Close modal when clicking outside modal content
        $(document).on('click', '#room-modal', function(e) {
            // Check if the clicked target is the modal itself (not the content)
            if ($(e.target).is('#room-modal')) {
                $(this).fadeOut(200);
            }
        });
        // Close modal (X button or backdrop)
        $(document).on('click', '.room-modal-close, .room-modal-backdrop', function() {
            $('#room-modal').fadeOut(200);
            // $('body').css('overflow', '');
        });


        $('#room-filter-form').on('submit', room_filter_submit_func);

        function room_filter_submit_func(e) {
            
            if (e && typeof e.preventDefault === 'function') {
                e.preventDefault();
            }

            // ✅ STEP 1: Get UI state and form reference
            const uiState = rb_storage.get('rb_ui_state') || 'list';
            const form = $( '#room-filter-form' );

            const $btn = form.find( '.rooms-sc-btn' );
            const originalText = $btn.text();

            // ✅ STEP 2: Get property ID and check if rates were already loaded
            const property_id = form.attr( 'property-id' );
            const rate_checked = rb_storage.get( property_id + '_rates_checked' );

            // ✅ STEP 3: Validate and get dates
            var checkin = getFieldValue('#sc-check-in');
            var checkout = getFieldValue('#sc-check-out');

            // ✅ STEP 4: If rates were checked before, ensure dates are still selected
            if( rate_checked === 'true' ){
                if ( !checkin || !checkout ) {
                    alert('Please select check-in and check-out dates');
                    return;
                }
            }

            // ✅ STEP 5: Save dates to localStorage for reference
            if (checkin && checkout ) {
                rb_storage.set('niseko_checkin', checkin);
                rb_storage.set('niseko_checkout', checkout);
            }

            // ✅ STEP 6: Save booking context (single source of truth)
            rb_storage.setJSON('rb_booking_context', {
                checkin,
                checkout,
                property_id,
            });

            $btn
            .prop('disabled', true)
            .addClass('loading')
            .text('Loading…');

            if (uiState === 'list') {
                $.ajax({
                    url: kv_object.ajaxurl, // WordPress AJAX URL
                    method: 'POST',
                    data: {
                        action: 'niseko_search_roomboss_single', // The action to handle the request
                        checkin: checkin,
                        checkout: checkout,
                        property_id: property_id, // Send the hotel ID for which to get rooms
                    },
                    success: function(res) {
                        if (res.success) {

                            // ✅ MARK RATES AS CHECKED
                            rb_storage.set( acc_id+'_rates_checked', 'true');

                            $('#room-results').html(res.data.html); // Update the room results
                            updateBedroomTabs(res.data.available_bedroom_types); // Update bedroom tabs based on API response
                            $('.book-btn').prop('disabled', false).removeClass('disabled');
                            var count = res.data.count;
                            $('.units_avl').text( count );
                        } else {
                            $('.book-btn').prop('disabled', false).removeClass('disabled');
                            $('#room-results').html('<p>No rooms available for selected dates.</p>'); // No rooms found
                        }

                    },
                    error: function (xhr, exception) {
                        // ✅ Use consolidated error handler
                        handleAjaxError(xhr, exception);
                        $('#room-results').html('<p class="rb-error">Error fetching room availability.</p>');
                    },
                    complete: function() {
                        $btn
                            .prop('disabled', false)
                            .removeClass('loading')
                            .text(originalText);
                    }
                });
                return;
            }
            else{

                rb_render_booking_from_storage();
            }
        }

        // Handle Bedroom Tab Switching
        $(document).on('click', '.bedroom-tab', function() {
            // Remove active class from all tabs and add to clicked tab
            $('.bedroom-tab').removeClass('active');
            $(this).addClass('active');

            // Get the bedroom filter value (all, 1, 2, 3)
            var bedroomFilter = $(this).data('bedroom');

            // Show/hide room cards based on selected bedroom filter
            if (bedroomFilter === 'all') {
                $('.room-card').show(); // Show all rooms
            } else {
                $('.room-card').each(function() {
                    // Hide rooms that do not match the selected bedroom filter
                    var roomBedroomCount = $(this).data('bedroom');
                    if (roomBedroomCount === parseInt(bedroomFilter)) {
                        $(this).show(); // Show matching room
                    } else {
                        $(this).hide(); // Hide non-matching room
                    }
                });
            }
        });

        // Trigger a click on the "All Bedrooms" tab by default
        $('.bedroom-tab[data-bedroom="all"]').click();

        $(document).on('click', '.close_cart', function (e) {
            let parent = $(this).parents('aside.rb-cart'),
                body   = $( 'body' );

            parent.removeClass('active');
            body.removeClass('cart-active');
        });

        // Update bedroom tabs dynamically based on available bedroom types
        function updateBedroomTabs(availableBedroomTypes) {
            var avl_units = $( '.available_units' )[0].outerHTML;
            $('.bedroom-tabs').empty();
            $('.bedroom-tabs').append('<button type="button" class="bedroom-tab active" data-bedroom="all">All Bedrooms</button>');
            $.each(availableBedroomTypes, function(index, type) {
                $('.bedroom-tabs').append('<button type="button" class="bedroom-tab" data-bedroom="' + type + '">' + type + ' Bedroom' + (type > 1 ? 's' : '') + '</button>');
            });
            $('.bedroom-tabs').prepend( avl_units );
            var room_count = $( '#room-results .room-card' ).length;
            $( '.units_avl' ).text( room_count );
        }

        // ✅ CART MANAGEMENT HELPERS - Use centralized rb_storage
        function kv_booking_cart_get() {
            return rb_storage.getJSON('rb_cart') || {items: []};
        }

        function kv_booking_cart_set(cart) {
            rb_storage.setJSON('rb_cart', cart);
        }

        function kv_booking_cart_render() {

            const cart = kv_booking_cart_get();
            const $body = $('#rbCartBody');
            const wp_body = $('body');
            
            const hz_cart = $( 'aside.rb-cart' );
            const close_cart = $( '.close_cart' );

            const $footer = $('#rbCartFooter');
            const $total = $('#rbCartTotal');

            // console.log('Rendering cart with items:', cart.items);

            if (!cart.items || !cart.items.length) {
                $body.html('<p class="rb-cart-empty">No rooms selected yet.</p>');
                $footer.hide();
                wp_body.removeClass('cart-active');
                hz_cart.removeClass('active');
                return;
            }

            // console.log('Cart has items, rendering summary.');

            let html = '';
            let sum = 0;

            cart.items.forEach((it, idx) => {

                sum += Number(it.price || 0);

                // ✅ SAFE FALLBACKS (CRITICAL)
                const guestsLabel =
                    it.guests?.label ||
                    `${it.guests?.adults || 0} adults`;

                const checkIn = it.dates?.check_in || '';
                const checkOut = it.dates?.check_out || '';

                const formattedPrice = it.price ?
                    '¥' + Number(it.price).toLocaleString('ja-JP') :
                    '';

                // console.log( 'in rendering loop' );

                html += `<div class="rb-summary-card" data-idx="${idx}">

                    <!-- HEADER -->
                    <div class="rb-summary-head">
                        <div class="rb-summary-room">
                            ${it.room_name || ''}
                        </div>

                        <div class="rb-summary-price-wrap">
                            <div class="rb-summary-price">${formattedPrice}</div>
                            <button type="button" class="rb-remove" title="Remove"></button>
                        </div>
                    </div>

                    <!-- RATE PLAN -->
                    <div class="rb-summary-rate">
                        ${it.rateplan_name || ''}
                    </div>

                    <!-- GUEST SUMMARY -->
                    <div class="rb-summary-guests">
                        ${guestsLabel || ''}
                    </div>

                    <!-- DATES -->
                    <div class="rb-summary-dates">
                        <div class="rb-date">
                            <span>Check in</span>
                            ${checkIn || ''}
                        </div>

                        <div class="rb-date-separator"></div>

                        <div class="rb-date">
                            <span>Check out</span>
                            ${checkOut || ''}
                        </div>
                    </div>

                </div>`;
                // console.log( 'end of loop' );
            });
            // console.log('after loop');
            $body.html(html);
            // console.log( 'body' );
            // console.log( $body );
            // console.log( $body.html() );
            $total.text('¥' + sum.toLocaleString('ja-JP'));
            $footer.show();

            /* ------------------------------------
               SYNC BUTTON STATES
            ------------------------------------ */
            $('.rb-select-btn')
                .removeClass('is-selected')
                .text('Select');

            cart.items.forEach(it => {
                $(
                    `.rb-rateplan-box[data-room-type-id="${it.room_type_id}"][data-rateplan-id="${it.rateplan_id}"]`
                )
                .find('.rb-select-btn')
                .addClass('is-selected')
                .text('Selected');
            });
        }

        function get_room_type_from_cart() {
            const cart = kv_booking_cart_get();
            if( empty( cart ) ) return;
            return cart.items.find(it => it.room_type);
        }

        function scrollToRoom($room) {
            $('html, body').animate({
                scrollTop: $room.offset().top - 140
            }, 600);
        }

        function kv_booking_init() {
            // render cart when booking html loads
            kv_booking_cart_render();

            console.log( 'booking init called' );

            handle_layout();
            console.log( 'layout handled' );
            // add to cart
            $(document)
                .off('click.rbSelect')
                .on('click.rbSelect', '.rb-select-btn', function() {

                    const wp_body = $('body');

                    const hz_cart = $( 'aside.rb-cart' );
                    const close_cart = $( '.close_cart' );

                    const $btn = $(this);
                    const $box = $btn.closest('.rb-rateplan-box');
                    const $room = $btn.closest('.rb-room-card');
                    const $wrap = $('.rb-booking-layout');
                    const form = $('#room-filter-form');
                    const hotel_name = $( '.title-wrapper h1' ).text();
                    const hotel_tid = form.attr('property-id');

                    /* --------------------------------------------------
                       1️⃣ READ ROOM LIMITS & GUESTS
                    -------------------------------------------------- */

                    const maxGuests = Number($room.find('.rb-icon.guest').text() || 0);

                    const $guestForm = $room.find('.rb-guests-form');

                    const adults = Number($guestForm.find('.rb-adults').val() || 0);
                    const children = Number($guestForm.find('.rb-children').val() || 0);
                    const infants = Number($guestForm.find('.rb-infants').val() || 0);

                    console.log('👥 guests values:', {
                        adults,
                        children,
                        infants
                    });

                    // reset UI
                    $room.find('.rb-guest-input').css('border', '');

                    /* --------------------------------------------------
                       2️⃣ VALIDATION (EXACT OLD BEHAVIOUR)
                    -------------------------------------------------- */

                    if (!adults || adults < 1) {
                        $room.find('.rb-adults').css('border', '2px solid red');
                        alert('Please select number of adults staying in this room.');
                        return;
                    }

                    if ((adults + children) > maxGuests) {
                        $room.find('.rb-adults, .rb-children').css('border', '2px solid red');
                        alert(`Total guests cannot exceed ${maxGuests}.`);
                        return;
                    }

                    /* --------------------------------------------------
                       3️⃣ READ DATES & NIGHTS (SINGLE SOURCE)
                    -------------------------------------------------- */

                    const check_in = $wrap.data('start-date');
                    const check_out = $wrap.data('end-date');
                    const nights = Number($wrap.data('nights') || 0);
                    
                    let checkin_date = new Date( check_in ),
                        checkout_date = new Date( check_out ),
                        duration = checkout_date - checkin_date;

                    /* --------------------------------------------------
                       4️⃣ BUILD GUESTS STRING (OLD STYLE)
                    -------------------------------------------------- */
                    let parts = [];

                    if (adults > 0) {
                        parts.push(`${adults} Adult${adults > 1 ? 's' : ''}`);
                    }

                    if (children > 0) {
                        parts.push(`${children} Child${children > 1 ? 'ren' : ''}`);
                    }

                    if (infants > 0) {
                        parts.push(`${infants} Infant${infants > 1 ? 's' : ''}`);
                    }

                    let guests_staying = parts.join(', ');

                    /* --------------------------------------------------
                       5️⃣ OPTIONAL DISCOUNT SUPPORT
                    -------------------------------------------------- */

                    const discountPrice = Number($box.data('discount-price') || 0);

                    /* --------------------------------------------------
                       6️⃣ BUILD CART ITEM
                    -------------------------------------------------- */

                    const item = {
                        hotel_type_id: hotel_tid,
                        room_type: $box.data('room-type'),
                        room_type_id: $box.data('room-type-id'),
                        property_name: hotel_name,
                        room_name: $box.data('room-name'),
                        rateplan_id: $box.data('rateplan-id'),
                        rateplan_name: $box.data('rateplan-name'),
                        price: Number($box.data('price') || 0),
                        price_label: $box.find('.rb-rateplan-price').text().trim(),
                        discount_price: discountPrice,
                        duration: duration,
                        guests: {
                            adults,
                            children,
                            infants,
                            label: guests_staying
                        },
                        dates: {
                            check_in,
                            check_out,
                            nights
                        }
                    };

                    /* --------------------------------------------------
                       7️⃣ UPDATE CART
                    -------------------------------------------------- */

                    let cart = kv_booking_cart_get();

                    cart.items = cart.items.filter(
                        x => x.room_type_id !== item.room_type_id
                    );

                    cart.items.push(item);

                    kv_booking_cart_set(cart);
                    kv_booking_cart_render();

                    /* --------------------------------------------------
                       8️⃣ UPDATE BUTTON STATES
                    -------------------------------------------------- */

                    $room.find('.rb-select-btn')
                        .removeClass('is-selected')
                        .text('Select');

                    $btn.addClass('is-selected').text('Selected');

                    if( isMobile() ){

                        wp_body.addClass('cart-active');
                        hz_cart.addClass('active');
                    }
                });

            // remove
            $(document)
                .off('click.rbRemove')
                .on('click.rbRemove', '.rb-remove', function() {

                    const $item = $(this).closest('.rb-summary-card');
                    const idx = Number($item.data('idx'));

                    console.log('🗑 Removing cart item at index:', idx);

                    let cart = kv_booking_cart_get();

                    if (!cart.items || typeof cart.items[idx] === 'undefined') {
                        console.warn('❌ Cart item not found');
                        return;
                    }

                    // capture removed item BEFORE deletion
                    const removedItem = cart.items[idx];

                    // remove item
                    cart.items.splice(idx, 1);

                    kv_booking_cart_set(cart);
                    kv_booking_cart_render();

                    $(`.rb-rateplan-box[data-room-type-id="${removedItem.room_type_id}"][data-rateplan-id="${removedItem.rateplan_id}"]`)
                        .find('.rb-select-btn')
                        .removeClass('is-selected')
                        .text('Select');
                });

            // proceed
            // $(document).off('click.rbProceed').on('click.rbProceed', '.rb-proceed-btn', function() {
            //     // redirect or open next step
            //     window.location.href = '/confirm-booking/';
            // });
        }

        function rb_render_booking_from_storage() {

            // ✅ STEP 1: Get and validate booking context from storage
            const bookingContextStr = rb_storage.get('rb_booking_context');
            
            if (!bookingContextStr) {
                alert('Booking data missing. Please search again.');
                return;
            }

            let bookingContext;
            try {
                bookingContext = JSON.parse(bookingContextStr);
            } catch (e) {
                console.error('Failed to parse booking context:', e);
                alert('Booking data corrupted. Please search again.');
                return;
            }

            // ✅ STEP 2: Validate required fields exist
            if (!bookingContext.checkin || !bookingContext.checkout || !bookingContext.property_id) {
                alert('Booking data missing. Please search again.');
                return;
            }

            // ✅ STEP 3: Build payload for booking API
            const payload = {
                action: 'load_roomboss_booking',
                property_id: bookingContext.property_id,
                start_date: bookingContext.checkin,
                end_date: bookingContext.checkout,
                adults: getNumericValue(bookingContext.adults),
                children: getNumericValue(bookingContext.children),
                infants: getNumericValue(bookingContext.infants)
            };

            // ✅ STEP 4: Hide room list and show loading state
            $('.room-list').hide();
            $('#room-modal').hide();

            $('.booking-wrap')
                .html('<div class="rb-loading">Loading booking…</div>')
                .show();

            // ✅ STEP 5: Fetch booking data from API
            $.ajax({
                url: kv_object.ajaxurl,
                type: 'POST',
                data: payload,
                dataType: 'json',
                success: function(resp) {          
                    // ✅ STEP 6: Handle success response
                    $('.book-btn').prop('disabled', false).removeClass('disabled');
                    
                    if (resp && resp.success) {
                        // ✅ STEP 7: Render booking layout
                        $('.booking-wrap').html(resp.data.html);
                        updateBedroomTabs(resp.data.available_bedroom_types);
                        $('.rooms-sc-btn')
                            .prop('disabled', false)
                            .removeClass('loading')
                            .text('Check Rates');
                        scrollToRoom($('.rooms-wrap'));

                        // ✅ STEP 8: Initialize booking UI handlers
                        if (typeof kv_booking_init === 'function') {
                            kv_booking_init();
                        }
                    } else {
                        // ❌ API returned error
                        const errorMsg = resp?.data?.message || 'Unable to restore booking.';
                        $('.booking-wrap').html(
                            '<p class="rb-error">' + esc_html(errorMsg) + '</p>'
                        );
                    }
                },
                error: function (xhr, exception) {
                    // ❌ STEP 9: Handle AJAX errors
                    $('.booking-wrap').html(
                        '<p class="rb-error">Booking reload failed.</p>'
                    );

                    handleAjaxError(xhr, exception);

                    $('.rooms-sc-btn')
                        .prop('disabled', false)
                        .removeClass('loading')
                        .text('Check Rates');
                }
            });
        }

        function initRoomGallery() {
            const $gallery = $('.js-room-gallery');
            const $slides = $gallery.find('.room-slide');

            // Destroy slick if already initialized
            if ($gallery.hasClass('slick-initialized')) {
                $gallery.slick('unslick');
            }

            // Only initialize slick if there are 3 or more slides
            if ($slides.length >= 3) {

                $gallery.on('init', function() {
                    setTimeout(function() {
                        $gallery.slick('setPosition');
                    }, 0);
                });
                $gallery.slick({
                    infinite: true, // loop
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: true,
                    dots: false,
                    adaptiveHeight: true,
                    prevArrow: '<button type="button" class="slick-prev"><img src="' + kingdomVision.themeUrl + '/images/left_arrow.svg" alt="Previous"></button>',
                    nextArrow: '<button type="button" class="slick-next"><img src="' + kingdomVision.themeUrl + '/images/right_arrow.svg" alt="Next"></button>',
                    responsive: [{
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            }
        }

    });
</script>
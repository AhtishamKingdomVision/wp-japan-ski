<?php
/**
 * Room Booking Data Template
 * Displays available rooms with rate plans for booking system
 * 
 * Required $args keys:
 *   - grouped_rooms: Array of room data from API
 *   - rate_plans: Array of rate plan data (optional)
 *   - room_descriptions: Array of room descriptions keyed by room ID
 *   - dates: Array with 'check_in' and 'check_out' date strings
 *   - property_id: Numeric property/hotel ID
 */

// ✅ STEP 1: Parse and validate arguments with defaults
$args = wp_parse_args($args ?? [], [
    'grouped_rooms'      => [],
    'rate_plans'         => [],
    'room_descriptions'  => [],
    'dates'              => ['check_in' => '', 'check_out' => ''],
    'property_id'        => 0,
]);

// ✅ STEP 2: Extract and validate room data
$rooms = is_array($args['grouped_rooms']) ? $args['grouped_rooms'] : [];
$ratePlans = is_array($args['rate_plans']) ? $args['rate_plans'] : [];
$desc = is_array($args['room_descriptions']) ? $args['room_descriptions'] : [];
$propertyId = intval($args['property_id']);

// ✅ STEP 3: Extract and validate date information
$dates = is_array($args['dates']) ? $args['dates'] : [];
$startDisplay = sanitize_text_field($dates['check_in'] ?? '');
$endDisplay = sanitize_text_field($dates['check_out'] ?? '');
$nights = isset($dates['nights']) ? intval($dates['nights']) : 0;

// ✅ STEP 4: Check if property uses roomboss or bedbank
$is_roomboss = !empty($propertyId) ? get_resort_id_by_property_id($propertyId) : false;
?>

<a href="javascript:;" class="btn back-to-rooms btn-outline">← Back</a>
<div class="rb-booking-layout" data-hotel-id="<?php echo esc_attr($propertyId); ?>"
    data-start-date="<?php echo esc_attr($startDisplay); ?>"
    data-end-date="<?php echo esc_attr($endDisplay); ?>"
    data-nights="<?php echo esc_attr($nights); ?>">
    <div class="rb-left">

        <?php if (empty($rooms)) : ?>
            <p class="rb-empty">No rooms available for selected dates.</p>
        <?php else :
            foreach ($rooms as $roomName => $room) :
                // ✅ Extract room identifiers with defaults
                $RoomId = intval($room['RoomId'] ?? 0);
                $roomTypeId = intval($room['ActualRoomId'] ?? 0);
                
                // Skip rooms without ID
                if (empty($RoomId)) {
                    continue;
                }

                // ✅ Process and validate room image URL
                $img = '';
                if (!empty($room['RoomImages']) && is_array($room['RoomImages']) && !empty($room['RoomImages'][0])) {
                    $imageData = $room['RoomImages'][0];
                    
                    // Check if path is already a complete URL
                    if (!empty($imageData['path']) && filter_var($imageData['path'], FILTER_VALIDATE_URL)) {
                        $img = esc_url_raw($imageData['path']);
                    } elseif (!empty($imageData['path']) && !empty($imageData['file_name'])) {
                        // Construct full URL from components
                        $img = esc_url_raw(KV_BOOKING_SYSTEM_BASE . '/storage' . $imageData['path'] . $imageData['file_name']);
                    }
                }

                // ✅ Extract room details with validation and defaults
                $maxGuests = intval($room['MaximumAdults'] ?? 0);
                $bedrooms = intval($room['numberBedrooms'] ?? 0);
                $baths = intval($room['numberBathrooms'] ?? 0);
                $maxInfants = intval($room['maxNumberInfants'] ?? 0);
                ?>
                <div class="rb-room-card room-card"
                    data-bedroom="<?php echo esc_attr($bedrooms); ?>"
                    data-room-id="<?php echo esc_attr($RoomId); ?>"
                    >
                    <div class="rb-room-top">
                        <div class="rb-room-img">
                            <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($room['RoomName'] ?? 'Room'); ?>">
                        </div>

                        <div class="rb-room-meta">
                            <div class="tit_date">
                                <h3 class="rb-room-title"><?php echo esc_html($room['RoomName'] ?? ''); ?></h3>


                                <div class="rb-room-dates"></div>
                            </div>

                            <div class="rb-icons">
                                <span class="rb-icon guest"><?php echo esc_html($maxGuests); ?></span>
                                <span class="rb-icon bad"><?php echo esc_html($bedrooms); ?></span>
                                <span class="rb-icon bath"><?php echo esc_html($baths); ?></span>
                                <?php if (!empty($maxInfants) && $maxInfants > 0) : ?>
                                    <span class="rb-icon infant">
                                        <?php echo esc_html($maxInfants); ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="rb-room-desc">
                                <!-- Std Guests: 2, Max Guests: 2; 1 Bedroom (King or Twin), 1 Bathroom; Size: 33-39 m²; Levels 2-5 -->
                                <?php echo esc_html($desc[$RoomId] ?? ''); ?>
                            </div>

                        </div>
                        <div class="rb-guests-filter">
                            <form class="rb-guests-form">

                                <!-- Adults -->
                                <div class="rb-guest-field">
                                    <label>Adults</label>
                                    <select class="rb-guest-input rb-adults" name="adults">
                                        <option value="">Adults</option>
                                        <?php for ($i = 1; $i <= $maxGuests; $i++): ?>
                                            <option value="<?php echo esc_attr($i); ?>"><?php echo esc_html($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <!-- Children -->
                                <div class="rb-guest-field">
                                    <label>Children</label>
                                    <select class="rb-guest-input rb-children" name="children">
                                        <option value="">Children</option>
                                        <?php for ($i = 0; $i <= $maxGuests; $i++): ?>
                                            <option value="<?php echo esc_attr($i); ?>"><?php echo esc_html($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <!-- Infants -->
                                <div class="rb-guest-field">
                                    <label>Infants</label>
                                    <select class="rb-guest-input rb-infants" name="infants">
                                        <option value="">Infants</option>
                                        <?php for ($i = 0; $i <= $maxGuests; $i++): ?>
                                            <option value="<?php echo esc_attr($i); ?>"><?php echo esc_html($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                            </form>
                        </div>
                    </div>

                    <div class="rb-rateplans">
                        <?php
                            $allRooms = [$room];
                            foreach($room['children'] ?? [] as $childRoom) {
                                $allRooms[] = $childRoom;
                            }

                            foreach ($allRooms as $room) : 
                                // ✅ Calculate prices with safe division
                                $priceRetail = (float) ($room['ActualPrice'] ?? 0);
                                $perStay = ($maxGuests > 0) ? ceil($priceRetail / $maxGuests) : $priceRetail;
                        ?>

                        <?php 
                            // $RoomId = intval($room['RoomId'] ?? 0);
                            // if (empty($RoomId)) {
                            //     continue;
                            // }
                        ?>
                            <div class="rb-rateplan-box"
                                data-room-type="<?php echo esc_attr(!empty($room['ratePlanId']) ? 'roomboss' : 'bedbank'); ?>"
                                data-room-type-id="<?php echo esc_attr($roomTypeId); ?>"
                                data-room-name="<?php echo esc_attr($room['RoomName'] ?? ''); ?>"
                                data-rateplan-id="<?php echo esc_attr($room['ratePlanId'] ?? ''); ?>"
                                data-rateplan-name="<?php echo esc_attr($room['ratePlanName'] ?? ''); ?>"
                                data-price="<?php echo esc_attr($priceRetail); ?>">

                                <div class="rb-rateplan-left">

                                    <!-- TITLE + INFO ICON -->
                                    <div class="rb-rateplan-title-wrap">
                                        <div class="rb-rateplan-title">
                                            <?php echo esc_html($room['ratePlanName'] ?? ''); ?>
                                        </div>

                                        <?php if (!empty($room['ratePlanLongDescription'])) : ?>
                                            <i class="rb-toggle-long-desc fa-solid fa-circle-info"
                                                title="More information"></i>
                                        <?php endif; ?>
                                    </div>

                                    <!-- SHORT DESCRIPTION -->
                                    <?php if (!empty($room['description'])) :?>
                                        <div class="rb-rateplan-desc">
                                            <?php echo esc_html($room['description']); ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- LONG DESCRIPTION (HIDDEN) -->
                                    <?php if (!empty($room['ratePlanLongDescription'])) : ?>
                                        <div class="rb-long-desc" style="display:none;">
                                            <?php
                                                // ✅ Security: Sanitize HTML content to allow safe formatting
                                                $long_desc = $room['ratePlanLongDescription'];
                                                echo wp_kses_post($long_desc);
                                            ?>
                                        </div>
                                    <?php endif; ?>

                                </div>


                                <div class="rb-rateplan-right">

                                    <div class="rb-price-container">

                                        <!-- per stay -->
                                        <div class="rb-per-stay">
                                            <?php echo wp_kses_post(_currency_format_new($perStay, true)); ?>
                                            <span class="label">per stay</span>
                                        </div>

                                        <!-- prices -->
                                        <div class="rb-room-price">
                                            <div class="rb-final-price"
                                                data-price="<?php echo esc_attr($priceRetail); ?>">
                                                <?php echo wp_kses_post(_currency_format_new($priceRetail, true)); ?>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                                <button type="button" class="rb-select-btn">Select</button>
                            </div>
                        <?php endforeach; ?>
                    </div>


                </div>
            <?php endforeach; ?>

        <?php endif; ?>
    </div>

    <!-- CART -->
    <aside class="rb-cart">
            <div class="rb-cart-wrap">
                <div class="rb-cart-head">
                    <h3>Booking Summary</h3>

                    <div class="close_cart is_mobile"><a class="close"><i class="fa-solid fa-xmark"></i></a></div>
                </div>

                <div class="rb-cart-body" id="rbCartBody">
                    <p class="rb-cart-empty">No rooms selected yet.</p>
                </div>

                <div class="rb-cart-footer" id="rbCartFooter" style="display:none;">
                    <div class="rb-total-row">
                        <strong>Total</strong>
                        <span id="rbCartTotal">0</span>
                    </div>
                    <button type="button" class="rb-proceed-btn">Proceed</button>
                </div>
            </div>
        </aside>
</div>
<?php

if(get_template_part('header-new')){
    get_header('new');
}
// else{
//     get_header();
// }

$header_option = get_field('header_option');

$bg_image = get_the_post_thumbnail_url();
$placeholder = get_template_directory_uri() . '/images/placeholder-single.jpg';
$bg_image = !empty($bg_image) ? $bg_image : $placeholder;

$tag_line = get_field('tag_line');
$title = get_the_title();
$teamMembersOption = get_field('team_members' , 'option') ?? [];
$select_auhtor = get_field('select_member');
$date = get_field('date');
$post_id    = get_the_ID();
$post_url   = urlencode(get_permalink($post_id));
$post_title = urlencode(get_the_title($post_id));
$post_image = has_post_thumbnail($post_id)
    ? urlencode(get_the_post_thumbnail_url($post_id, 'full'))
    : '';
$overlay      = get_field('overlay');
$blog_builder = get_field('post_builder');
$ff_image     = get_field('form_footer_image', 'option');
$ff_content   = get_field('form_footer_content', 'option');

echo '<div class="content-wrapper full-section accommodation '.esc_attr($header_option).'">';
    echo '<section class="full-section topsinglebanner" style="background: url('.$bg_image.') no-repeat center/cover;">';

        echo '<div class="container">';
            if($tag_line){ printf('<span class="tagline">%s</span>', $tag_line); }
            if($title){ printf('<h1>%s</h1>', $title); }
            if($select_auhtor || $date){
                echo '<div class="postAuthorDate">';
                    echo getMemberFromSpecialists($select_auhtor , $teamMembersOption, $date);
                echo '</div>';
            }
            echo '<div class="kv-social-share">';

            /* COPY LINK */
            echo '<a href="javascript:;" class="kv-share-btn kv-copy-link"
                    data-link="' . esc_url(get_permalink($post_id)) . '"
                    aria-label="Copy link">
                    <i class="fa-solid fa-link"></i>
                  </a>';

            /* X (Twitter) */
            echo '<a class="kv-share-btn"
                    href="https://twitter.com/intent/tweet?url=' . $post_url . '&text=' . $post_title . '"
                    target="_blank" rel="noopener noreferrer"
                    aria-label="Share on X">
                    <i class="fa-brands fa-x-twitter"></i>
                  </a>';

            /* Facebook */
            echo '<a class="kv-share-btn"
                    href="https://www.facebook.com/sharer/sharer.php?u=' . $post_url . '"
                    target="_blank" rel="noopener noreferrer"
                    aria-label="Share on Facebook">
                    <i class="fa-brands fa-facebook-f"></i>
                  </a>';

            /* LinkedIn */
            echo '<a class="kv-share-btn"
                    href="https://www.linkedin.com/sharing/share-offsite/?url=' . $post_url . '"
                    target="_blank" rel="noopener noreferrer"
                    aria-label="Share on LinkedIn">
                    <i class="fa-brands fa-linkedin-in"></i>
                  </a>';

            /* Pinterest (only if image exists) */
            if ($post_image) {
                echo '<a class="kv-share-btn"
                        href="https://pinterest.com/pin/create/button/?url=' . $post_url . '&media=' . $post_image . '&description=' . $post_title . '"
                        target="_blank" rel="noopener noreferrer"
                        aria-label="Share on Pinterest">
                        <i class="fa-brands fa-pinterest-p"></i>
                      </a>';
            }

            echo '</div>';
        echo '</div>';
    echo '</section>';

    echo '<section class="full-section single_main">';
        echo '<div class="container">';
            echo '<div class="sm_inner">';
                echo '<div class="sm_left">';
                    the_content();

                     if($blog_builder){
                       if (!empty($blog_builder) && is_array($blog_builder)) {
                          $sectionIndex = 0;
                          foreach ($blog_builder as $section){
                             $sectionIndex++;
                             $layout = $section['acf_fc_layout'];
                             $template = locate_template("section/blogs/{$layout}.php");

                             if ($template) {
                                   $currenSectionIndex = $sectionIndex;
                                   include $template;
                             }

                          }

                       } else {

                       }
                     }

                        echo '<div class="more_posts full-section">';
                         $prev_post = get_previous_post();
                         $next_post = get_next_post();
                            if($prev_post) {
                              echo '<div class="prev_posts">';
                                 $prev_title = strip_tags(str_replace('"', '', $prev_post->post_title));
                                 echo "\t" . '<a class="btn" rel="prev" href="' . get_permalink($prev_post->ID) . '" title="' . $prev_title. '" class=" "><img src="'.home_url().'/wp-content/themes/kingdomvision/images/left_arrow.svg"></i>&nbsp;&nbsp;Previous Post</a>' . "\n";
                              echo '</div>';
                            }

                            if($next_post) {
                              echo '<div class="next_posts">';
                                 $next_title = strip_tags(str_replace('"', '', $next_post->post_title));
                                 echo "\t" . '<a class="btn" rel="next" href="' . get_permalink($next_post->ID) . '" title="' . $next_title. '" class=" ">Next Post&nbsp;&nbsp;<img src="'.home_url().'/wp-content/themes/kingdomvision/images/right_arrow.svg"></a>' . "\n";
                              echo '</div>';
                            }
                            echo '</div>';


                echo '</div>'; //sm_left
                echo '<div class="sm_right">';
                    echo '<div class="sm_sticky">';
                        $jumplinks = get_field('jumplinks');
                        if (!empty($jumplinks) && is_array($jumplinks)) {
                            echo '<ul>';
                            foreach ($jumplinks as $value) {
                                // Skip empty rows
                                if (empty($value['link']) || empty($value['link']['url'])) {
                                    continue;
                                }
                                $link        = $value['link'];
                                $link_url    = $link['url'];
                                $link_title  = !empty($link['title']) ? $link['title'] : '';
                                $link_target = !empty($link['target']) ? $link['target'] : '_self';
                                // Extra safety
                                if (empty($link_url)) {
                                    continue;
                                }
                                echo '<li>';
                                    echo '<a href="' . esc_url($link_url) . '" target="' . esc_attr($link_target) . '">';
                                        echo esc_html($link_title);
                                    echo '</a>';
                                echo '</li>';
                            }
                            echo '</ul>';
                        }
                        echo do_shortcode('[gravityform id="1" title="true"]');
                        if ($ff_image && $ff_content) {
                            echo '<div class="ff_content_image">';
                                echo '<div class="ff_image">';
                                    echo wp_get_attachment_image($ff_image, 'full');
                                echo '</div><!-- ff_image -->';

                                echo '<div class="ff_content">';
                                    echo wp_kses_post($ff_content);
                                echo '</div><!-- ff_content -->';
                            echo '</div><!-- ff_content_image -->';
                        }
                    echo '</div>'; //sm_sticky
                echo '</div>'; //sm_right
            echo '</div>'; //sm_inner
        echo '</div>';
    echo '</section>';

    $title_n = get_field('title_n');
    $related_posts = get_field('post', get_the_ID());
    $teamMembersOption  = get_field('team_members', 'option') ?? [];
    if ($related_posts) {

        echo '<section class="full-section kv-related-posts">';
            echo '<div class="container">';
                echo '<h2>' . ($title_n == '0' || empty($title_n) ? 'Related Posts' : esc_html($title_n)) . '</h2>';
                echo '<div class="kv-post-grid">';

                foreach ($related_posts as $post) {

                    setup_postdata($post);

                    // Pass option data to template part
                    set_query_var('teamMembersOption', $teamMembersOption);

                    // Capture post-card output
                    ob_start();
                    get_template_part('post-card');
                    echo ob_get_clean();
                }

                echo '</div>';
            echo '</div>';
        echo '</section>';

        wp_reset_postdata();
    }

    echo '</div>'; #content-wrapper

?>
<?php if($overlay == true): ?>
    <style type="text/css">
    section.topsinglebanner:after { content: ""; position: absolute; width: 100%; height: 100%; top: 0; background: rgba(0, 17, 31, 0.80); z-index: -1; }
</style>
<?php endif; ?>
<?php get_footer(); ?>

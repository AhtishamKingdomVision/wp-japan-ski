<script>
    jQuery(document).ready(function($) {

        var acc_id = $( '#room-filter-form' ).attr( 'acc-id' );

        const uiState = localStorage.getItem('rb_ui_state');
        const ratesChecked = localStorage.getItem( acc_id+'_rates_checked') === 'true';

        var room_id = $( '#room-filter-form' ).attr( 'room-id' );
        var header_height = $( 'header' ).outerHeight();

        const to_form = localStorage.getItem( 'go_to_form' );

        if( to_form == room_id ){

            $('html, body').animate({
                // Subtract 148 from the target offset top value
                scrollTop: ( $('#room-filter-form').offset().top - header_height )
            }, 400);
            localStorage.removeItem( 'go_to_form' );
        }

        // if ( uiState && uiState === 'booking' && ratesChecked ) {
        //     rb_render_booking_from_storage();
        // }

        var checkin = $('#sc-check-in').length > 0 ? $('#sc-check-in').val() : '';
        var checkout = $('#sc-check-out').length > 0 ? $('#sc-check-out').val() : '';

        if ( !checkin.length > 0 || !checkout.length > 0 ) {
            show_booking_ui();
        }


        $(document).on('click', '.book-btn', booking_form_func);

        function show_booking_ui(){

            let form = $('#room-filter-form'),
                hotel_id = form.attr('hotel-id'),
                checkin = form.find('#sc-check-in').val(),
                checkout = form.find('#sc-check-out').val();

            $( '.room-list' ).hide();

            const payload = {
                action: 'load_roomboss_booking',
                hotel_id: hotel_id,
                start_date: checkin,
                end_date: checkout,
            };

            // Basic validation
            if (!payload.start_date || !payload.end_date) {
            $( '.room-list' ).show();
                // alert('Please select check-in and check-out dates');
                return;
            }

            $.ajax({
                url: kv_object.ajaxurl,
                type: 'POST',
                data: payload,
                dataType: 'json',
                success: function(resp) {
                    if (resp && resp.success) {

                        // ✅ SAVE UI STATE
                        localStorage.setItem('rb_ui_state', 'booking');

                        $('.room-list').fadeOut(200, function() {
                            $('#room-modal').fadeOut(200);
                            $('.booking-wrap')
                                .hide()
                                .html(resp.data.html)
                                .fadeIn(200);
                        });
                        // $('.booking-wrap').html(resp.data.html);
                        if (typeof kv_booking_init === 'function') {
                            kv_booking_init();
                        }
                        var rooms_count = $( '.rb-room-card' ).length;
                        $('.units_avl').text( rooms_count );
                    } else {
                        $('.booking-wrap').html(
                            '<p class="rb-error">' +
                            (resp?.data?.message || 'No data returned') +
                            '</p>'
                        );
                    }
                },
                error: function() {
                    $('.booking-wrap').html(
                        '<p class="rb-error">Unable to load booking data.</p>'
                    );
                    console.error('Booking AJAX error:', xhr.responseText);
                },
                complete: function() {
                }
            });

        }

        function booking_form_func (e) {
            if (e && typeof e.preventDefault === 'function') {
                e.preventDefault();
            }

            // 🔒 HARD BLOCK: must check rates first
            const ratesChecked = localStorage.getItem( acc_id+'_rates_checked') === 'true';

            if (!ratesChecked && localStorage.getItem('rb_booking_context') === null) {
                alert('Please enter dates.');
                return;
            }

            const $btn = $(this);
            const originalText = $btn.text();

            // 🔒 Get booking context from localStorage
            const bookingContext = JSON.parse(
                localStorage.getItem('rb_booking_context')
            );

            // ❌ Defensive check (should never happen, but safe)
            if (!bookingContext.checkin || !bookingContext.checkout || !bookingContext.hotel_id) {
                alert('Booking data missing. Please search again.');
                return;
            }

            const payload = {
                action: 'load_roomboss_booking',
                hotel_id: bookingContext.hotel_id,
                start_date: bookingContext.checkin,
                end_date: bookingContext.checkout,
                adults: $('#adults').val() || 0,
                children: $('#children').val() || 0,
                infants: $('#infants').val() || 0
            };

            // Basic validation
            if (!payload.start_date || !payload.end_date) {
                alert('Please select check-in and check-out dates');
                return;
            }

            $btn
                .prop('disabled', true)
                .addClass('loading')
                .text('Loading…');

            // UI switch
            // $('.room-list').fadeOut(200, function() {
            //     $('.booking-wrap')
            //         .fadeIn(200)
            //         .html('<div class="rb-loading">Loading availability…</div>');
            // });


            $.ajax({
                url: kv_object.ajaxurl,
                type: 'POST',
                data: payload,
                dataType: 'json',
                success: function(resp) {
                    if (resp && resp.success) {

                        // ✅ SAVE UI STATE
                        localStorage.setItem('rb_ui_state', 'booking');

                        $('.room-list').fadeOut(200, function() {
                            $('#room-modal').fadeOut(200);
                            $('.booking-wrap')
                                .hide()
                                .html(resp.data.html)
                                .fadeIn(200);
                        });
                        // $('.booking-wrap').html(resp.data.html);
                        if (typeof kv_booking_init === 'function') {
                            kv_booking_init();
                        }
                    } else {
                        $('.booking-wrap').html(
                            '<p class="rb-error">' +
                            (resp?.data?.message || 'No data returned') +
                            '</p>'
                        );
                    }

                },
                error: function() {
                    $('.booking-wrap').html(
                        '<p class="rb-error">Unable to load booking data.</p>'
                    );
                    console.error('Booking AJAX error:', xhr.responseText);
                },
                complete: function() {
                    // 🔁 Restore button state
                    $btn
                        .prop('disabled', false)
                        .removeClass('loading')
                        .text(originalText);
                }
            });

        }

        $(document).on('change', '#room-filter-form input, #room-filter-form select', function() {
            localStorage.setItem( acc_id+'_rates_checked', 'false');
            // localStorage.setItem('rb_ui_state', 'list');
        });

        // OPTIONAL: Back to rooms
        $(document).on('click', '.back-to-rooms', function() {


            // 🔁 Reset persisted UI state
            localStorage.removeItem('rb_ui_state');

            $('.booking-wrap').fadeOut(200, function() {
                jQuery(this).empty();

                $('.room-list').fadeIn(200);
            });
        });

        // Open modal
        $(document).on('click', '.details-btn', function(e) {
            e.preventDefault();

            const $btn = $(this);
            const originalText = $btn.text();

            const roomId = $(this).attr('room-id');
            const hotelId = $(this).attr('hotel-id');

            console.log( 'hotelId' );
            console.log( hotelId );

            // 🔄 Button loading state
            $btn
                .prop('disabled', true)
                .addClass('loading')
                .text('Loading…');

            // $('#room-modal').fadeIn(200);
            // $('body').css('overflow', 'hidden');
            // $('#room-modal-body').html('<p>Loading...</p>');
            $.ajax({
                url: kv_object.ajaxurl, // WordPress AJAX URL
                method: 'POST',
                data: {
                    action: 'niseko_load_room_details', // The action to handle the request
                    room_id: roomId,
                    hotel_id: hotelId
                },
                success: function(res) {
                    if (res.success) {
                        $('#room-modal-body').html(res.data.html);


                        // setTimeout(() => {
                        //     initRoomGallery()
                        // }, 200);
                        // initRoomGallery();
                        $('#room-modal').fadeIn(200, function() {
                            const $gallery = $('.js-room-gallery');
                            const $images = $gallery.find('img');

                            let imagesLoaded = 0;
                            $images.each(function() {
                                if (this.complete) {
                                    imagesLoaded++;
                                } else {
                                    $(this).on('load', () => {
                                        imagesLoaded++;
                                        if (imagesLoaded === $images.length) initRoomGallery();
                                    });
                                }
                            });

                            // If all images are already loaded
                            if (imagesLoaded === $images.length) {
                                initRoomGallery();
                            }
                        });


                        $('.book-btn').prop('disabled', false).removeClass('disabled');

                    } else {
                        $('#room-modal-body').html('<p>Error loading room details.</p>'); // Error message

                        $('.book-btn').prop('disabled', false).removeClass('disabled');
                    }
                },
                error: function() {
                    $('#room-modal-body').html('<p>Error loading room details.</p>'); // Error message
                },
                complete: function() {
                    // 🔁 Restore button
                    $btn
                        .prop('disabled', false)
                        .removeClass('loading')
                        .text(originalText);
                }
            });
        });

        // Close modal when clicking outside modal content
        $(document).on('click', '#room-modal', function(e) {
            // Check if the clicked target is the modal itself (not the content)
            if ($(e.target).is('#room-modal')) {
                $(this).fadeOut(200);
            }
        });
        // Close modal (X button or backdrop)
        $(document).on('click', '.room-modal-close, .room-modal-backdrop', function() {
            $('#room-modal').fadeOut(200);
            // $('body').css('overflow', '');
        });


        $('#room-filter-form').on('submit', room_filter_submit_func);

        function room_filter_submit_func(e) {
            
            console.log( e );
            if (e && typeof e.preventDefault === 'function') {
                e.preventDefault();
            }

            const uiState = localStorage.getItem('rb_ui_state') || 'list';
            const form = $( '#room-filter-form' )

            const $btn = form.find( '.rooms-sc-btn' );
            const originalText = $btn.text();

            const hotel_id = form.attr( 'hotel-id' );
            const rate_checked = localStorage.getItem( hotel_id + '_rates_checked' );

            var checkin = $('#sc-check-in').val();
            var checkout = $('#sc-check-out').val();

            if( rate_checked === 'true' ){

                if ( !checkin.length > 0 || !checkout.length > 0 ) {
                    alert('Please select check-in and check-out dates');
                    return;
                }
            }

            if (checkin && checkout ) {
                localStorage.setItem('niseko_checkin', checkin);
                localStorage.setItem('niseko_checkout', checkout);
            }

            // ✅ Save booking context (single source of truth)
            localStorage.setItem('rb_booking_context', JSON.stringify({
                checkin,
                checkout,
                hotel_id,
            }));

            $btn
            .prop('disabled', true)
            .addClass('loading')
            .text('Loading…');

            if (uiState === 'list') {
                $.ajax({
                    url: kv_object.ajaxurl, // WordPress AJAX URL
                    method: 'POST',
                    data: {
                        action: 'niseko_search_roomboss_single', // The action to handle the request
                        checkin: checkin,
                        checkout: checkout,
                        hotel_id: hotel_id, // Send the hotel ID for which to get rooms
                    },
                    success: function(res) {
                        if (res.success) {

                            // ✅ MARK RATES AS CHECKED
                            localStorage.setItem( acc_id+'_rates_checked', 'true');

                            $('#room-results').html(res.data.html); // Update the room results
                            updateBedroomTabs(res.data.available_bedroom_types); // Update bedroom tabs based on API response
                            $('.book-btn').prop('disabled', false).removeClass('disabled');
                            var count = res.data.count;
                            $('.units_avl').text( count );
                        } else {
                            $('.book-btn').prop('disabled', false).removeClass('disabled');
                            $('#room-results').html('<p>No rooms available for selected dates.</p>'); // No rooms found
                        }

                    },
                    error: function() {
                        alert('Error fetching room availability.');
                    },
                    complete: function() {
                        $btn
                            .prop('disabled', false)
                            .removeClass('loading')
                            .text(originalText);
                    }
                });
                return;
            }

            rb_render_booking_from_storage();
        }

        // Handle Bedroom Tab Switching
        $(document).on('click', '.bedroom-tab', function() {
            // Remove active class from all tabs and add to clicked tab
            $('.bedroom-tab').removeClass('active');
            $(this).addClass('active');

            // Get the bedroom filter value (all, 1, 2, 3)
            var bedroomFilter = $(this).data('bedroom');

            // Show/hide room cards based on selected bedroom filter
            if (bedroomFilter === 'all') {
                $('.room-card').show(); // Show all rooms
            } else {
                $('.room-card').each(function() {
                    // Hide rooms that do not match the selected bedroom filter
                    var roomBedroomCount = $(this).data('bedroom');
                    if (roomBedroomCount === parseInt(bedroomFilter)) {
                        $(this).show(); // Show matching room
                    } else {
                        $(this).hide(); // Hide non-matching room
                    }
                });
            }
        });

        // Trigger a click on the "All Bedrooms" tab by default
        $('.bedroom-tab[data-bedroom="all"]').click();

        // Update bedroom tabs dynamically based on available bedroom types
        function updateBedroomTabs(availableBedroomTypes) {
            var avl_units = $( '.available_units' )[0].outerHTML;
            $('.bedroom-tabs').empty();
            $('.bedroom-tabs').append('<button type="button" class="bedroom-tab active" data-bedroom="all">All Bedrooms</button>');
            $.each(availableBedroomTypes, function(index, type) {
                $('.bedroom-tabs').append('<button type="button" class="bedroom-tab" data-bedroom="' + type + '">' + type + ' Bedroom' + (type > 1 ? 's' : '') + '</button>');
            });
            $('.bedroom-tabs').prepend( avl_units );
            var room_count = $( '#room-results .room-card' ).length;
            $( '.units_avl' ).text( room_count );
        }


        function kv_booking_cart_get() {
            return JSON.parse(localStorage.getItem('rb_cart') || '{"items":[]}');
        }

        function kv_booking_cart_set(cart) {
            localStorage.setItem('rb_cart', JSON.stringify(cart));
        }

        function kv_booking_cart_render() {

            const cart = kv_booking_cart_get();
            const $body = jQuery('#rbCartBody');
            const $footer = jQuery('#rbCartFooter');
            const $total = jQuery('#rbCartTotal');

            if (!cart.items || !cart.items.length) {
                $body.html('<p class="rb-cart-empty">No rooms selected yet.</p>');
                $footer.hide();
                return;
            }

            let html = '';
            let sum = 0;

            cart.items.forEach((it, idx) => {

                sum += Number(it.price || 0);

                // ✅ SAFE FALLBACKS (CRITICAL)
                const guestsLabel =
                    it.guests?.label ||
                    `${it.guests?.adults || 0} adults`;

                const checkIn = it.dates?.check_in || '';
                const checkOut = it.dates?.check_out || '';

                const formattedPrice = it.price ?
                    '¥' + Number(it.price).toLocaleString('ja-JP') :
                    '';

                html += `<div class="rb-summary-card" data-idx="${idx}">

                    <!-- HEADER -->
                    <div class="rb-summary-head">
                        <div class="rb-summary-room">
                            ${it.room_name || ''}
                        </div>

                        <div class="rb-summary-price-wrap">
                            <div class="rb-summary-price">${formattedPrice}</div>
                            <button type="button" class="rb-remove" title="Remove">🗑</button>
                        </div>
                    </div>

                    <!-- RATE PLAN -->
                    <div class="rb-summary-rate">
                        ${it.rateplan_name || ''}
                    </div>

                    <!-- GUEST SUMMARY -->
                    <div class="rb-summary-guests">
                        ${guestsLabel || ''}
                    </div>

                    <!-- DATES -->
                    <div class="rb-summary-dates">
                        <div class="rb-date">
                            <span>Check in</span>
                            ${checkIn || ''}
                        </div>

                        <div class="rb-date-separator"></div>

                        <div class="rb-date">
                            <span>Check out</span>
                            ${checkOut || ''}
                        </div>
                    </div>

                </div>`;
            });

            $body.html(html);
            $total.text('¥' + sum.toLocaleString('ja-JP'));
            $footer.show();

            /* ------------------------------------
               SYNC BUTTON STATES
            ------------------------------------ */
            jQuery('.rb-select-btn')
                .removeClass('is-selected')
                .text('Select');

            cart.items.forEach(it => {
                jQuery(
                        `.rb-rateplan-box[data-room-type-id="${it.room_type_id}"]
             [data-rateplan-id="${it.rateplan_id}"]`
                    )
                    .find('.rb-select-btn')
                    .addClass('is-selected')
                    .text('Selected');
            });
        }

        function scrollToRoom($room) {
            jQuery('html, body').animate({
                scrollTop: $room.offset().top - 140
            }, 600);
        }

        function kv_booking_init() {
            // render cart when booking html loads
            kv_booking_cart_render();

            // add to cart
            jQuery(document)
                .off('click.rbSelect')
                .on('click.rbSelect', '.rb-select-btn', function() {

                    console.log('🟢 rb-select-btn clicked');

                    const $btn = jQuery(this);
                    const $box = $btn.closest('.rb-rateplan-box');
                    const $room = $btn.closest('.rb-room-card');
                    const $wrap = jQuery('.rb-booking-layout');
                    const form = jQuery('#room-filter-form');
                    const hotel_name = jQuery( '.title-wrapper h1' ).text();
                    const hotel_tid = form.attr('hotel-id');

                    console.log('📦 rateplan box found:', $box.length);
                    console.log('🏨 room card found:', $room.length);

                    /* --------------------------------------------------
                       1️⃣ READ ROOM LIMITS & GUESTS
                    -------------------------------------------------- */

                    const maxGuests = Number($room.find('.rb-icon.guest').text() || 0);

                    const $guestForm = $room.find('.rb-guests-form');

                    const adults = Number($guestForm.find('.rb-adults').val() || 0);
                    const children = Number($guestForm.find('.rb-children').val() || 0);
                    const infants = Number($guestForm.find('.rb-infants').val() || 0);

                    console.log('👥 guests values:', {
                        adults,
                        children,
                        infants
                    });
                    console.log('👥 maxGuests:', maxGuests);

                    // reset UI
                    $room.find('.rb-guest-input').css('border', '');

                    /* --------------------------------------------------
                       2️⃣ VALIDATION (EXACT OLD BEHAVIOUR)
                    -------------------------------------------------- */

                    if (!adults || adults < 1) {
                        console.warn('❌ validation failed: adults');
                        $room.find('.rb-adults').css('border', '2px solid red');
                        alert('Please select number of adults staying in this room.');
                        return;
                    }

                    if ((adults + children) > maxGuests) {
                        console.warn('❌ validation failed: guests exceed max');
                        $room.find('.rb-adults, .rb-children').css('border', '2px solid red');
                        alert(`Total guests cannot exceed ${maxGuests}.`);
                        return;
                    }

                    console.log('✅ guest validation passed');

                    /* --------------------------------------------------
                       3️⃣ READ DATES & NIGHTS (SINGLE SOURCE)
                    -------------------------------------------------- */

                    const check_in = $wrap.data('start-date');
                    const check_out = $wrap.data('end-date');
                    const nights = Number($wrap.data('nights') || 0);
                    const duration = nights;

                    console.log('📅 dates:', {
                        check_in,
                        check_out,
                        nights
                    });

                    /* --------------------------------------------------
                       4️⃣ BUILD GUESTS STRING (OLD STYLE)
                    -------------------------------------------------- */
                    let parts = [];

                    if (adults > 0) {
                        parts.push(`${adults} Adult${adults > 1 ? 's' : ''}`);
                    }

                    if (children > 0) {
                        parts.push(`${children} Child${children > 1 ? 'ren' : ''}`);
                    }

                    if (infants > 0) {
                        parts.push(`${infants} Infant${infants > 1 ? 's' : ''}`);
                    }

                    let guests_staying = parts.join(', ');

                    console.log('🧾 guests_staying label:', guests_staying);

                    /* --------------------------------------------------
                       5️⃣ OPTIONAL DISCOUNT SUPPORT
                    -------------------------------------------------- */

                    const discountPrice = Number($box.data('discount-price') || 0);
                    console.log('💸 discountPrice:', discountPrice);

                    /* --------------------------------------------------
                       6️⃣ BUILD CART ITEM
                    -------------------------------------------------- */

                    const item = {
                        hotel_type_id: hotel_tid,
                        room_type_id: $box.data('room-type-id'),
                        property_name: hotel_name,
                        room_name: $box.data('room-name'),
                        rateplan_id: $box.data('rateplan-id'),
                        rateplan_name: $box.data('rateplan-name'),
                        price: Number($box.data('price') || 0),
                        price_label: $box.find('.rb-rateplan-price').text().trim(),
                        discount_price: discountPrice,
                        duration: duration,
                        guests: {
                            adults,
                            children,
                            infants,
                            label: guests_staying
                        },
                        dates: {
                            check_in,
                            check_out,
                            nights
                        }
                    };

                    console.log('🧾 cart item built:', item);

                    /* --------------------------------------------------
                       7️⃣ UPDATE CART
                    -------------------------------------------------- */

                    let cart = kv_booking_cart_get();
                    console.log('🛒 cart before:', cart);

                    cart.items = cart.items.filter(
                        x => x.room_type_id !== item.room_type_id
                    );

                    cart.items.push(item);

                    console.log('🛒 cart after:', cart);

                    kv_booking_cart_set(cart);
                    kv_booking_cart_render();

                    console.log('✅ cart rendered');

                    /* --------------------------------------------------
                       8️⃣ UPDATE BUTTON STATES
                    -------------------------------------------------- */

                    $room.find('.rb-select-btn')
                        .removeClass('is-selected')
                        .text('Select');

                    $btn.addClass('is-selected').text('Selected');

                    console.log('🎉 select completed');
                });

            jQuery(document).on('change', '.rb-guest-input', function() {

                const $room = jQuery(this).closest('.rb-room-card');
                const $form = $room.find('.rb-guests-form');
                const $btn = $room.find('.rb-select-btn');

                const adultsField = $form.find('.rb-adults');
                const childrenField = $form.find('.rb-children');
                const infantsField = $form.find('.rb-infants');

                const adults = parseInt(adultsField.val()) || 0;
                const children = parseInt(childrenField.val()) || 0;
                const infants = parseInt(infantsField.val()) || 0;

                const maxGuests = parseInt($room.find('.rb-icon.guest').text()) || 0;
                const maxInfants = parseInt($room.find('.rb-icon.infant').text()) || 0;

                /* ---------------------------
                   ERROR CONTAINERS
                --------------------------- */
                let $guestErr = $room.find('.rb-error-guests');
                let $infantErr = $room.find('.rb-error-infants');

                if (!$guestErr.length) {
                    $guestErr = jQuery('<div class="rb-error rb-error-guests"></div>').insertAfter($form);
                }
                if (!$infantErr.length) {
                    $infantErr = jQuery('<div class="rb-error rb-error-infants"></div>').insertAfter($form);
                }

                /* ---------------------------
                   RESET
                --------------------------- */
                $guestErr.hide().text('');
                $infantErr.hide().text('');
                $form.find('.rb-guest-input').css('border', '');
                $btn.prop('disabled', false);

                let hasError = false;

                /* ---------------------------
                   1️⃣ ADULTS REQUIRED (ONLY HARD RETURN)
                --------------------------- */
                if (!adults || adults < 1) {
                    adultsField.css('border', '2px solid red');
                    $guestErr.text('Please select number of adults staying in this room.').show();
                    // scrollToRoom($room);
                    $btn.prop('disabled', true);
                    return; // ✅ staging also returns here
                }

                /* ---------------------------
                   2️⃣ NON-INFANT GUEST VALIDATION
                --------------------------- */
                const guestTotal = adults + children;

                if (guestTotal > maxGuests) {
                    adultsField.add(childrenField).css('border', '2px solid red');
                    $guestErr
                        .text(`Total guests (${guestTotal}) cannot exceed ${maxGuests}.`)
                        .show();
                    hasError = true;
                }

                /* ---------------------------
                   3️⃣ INFANT VALIDATION (RUNS REGARDLESS)
                --------------------------- */
                if (infantsField.length && infants > 0) {
                    if ((guestTotal + infants) > (maxGuests + maxInfants)) {
                        infantsField.css('border', '2px solid red');
                        $infantErr
                            .text(
                                `Total guests + infants cannot exceed ${maxGuests + maxInfants}.`
                            )
                            .show();
                        hasError = true;
                    }
                }

                /* ---------------------------
                   4️⃣ FINAL STATE
                --------------------------- */
                if (hasError) {
                    scrollToRoom($room);
                    $btn.prop('disabled', true);
                } else {
                    $guestErr.hide();
                    $infantErr.hide();
                    $form.find('.rb-guest-input').css('border', '');
                    $btn.prop('disabled', false);
                }
            });

            // remove
            jQuery(document)
                .off('click.rbRemove')
                .on('click.rbRemove', '.rb-remove', function() {

                    const $item = jQuery(this).closest('.rb-summary-card');
                    const idx = Number($item.data('idx'));

                    console.log('🗑 Removing cart item at index:', idx);

                    let cart = kv_booking_cart_get();

                    if (!cart.items || typeof cart.items[idx] === 'undefined') {
                        console.warn('❌ Cart item not found');
                        return;
                    }

                    // capture removed item BEFORE deletion
                    const removedItem = cart.items[idx];
                    console.log(removedItem);

                    // remove item
                    cart.items.splice(idx, 1);

                    kv_booking_cart_set(cart);
                    kv_booking_cart_render();

                    jQuery(`.rb-rateplan-box[data-room-type-id="${removedItem.room_type_id}"][data-rateplan-id="${removedItem.rateplan_id}"]`)
                        .find('.rb-select-btn')
                        .removeClass('is-selected')
                        .text('Select');
                });

            // proceed
            // jQuery(document).off('click.rbProceed').on('click.rbProceed', '.rb-proceed-btn', function() {
            //     // redirect or open next step
            //     window.location.href = '/confirm-booking/';
            // });
        }

        function initRoomGallery() {
            const $gallery = $('.js-room-gallery');
            const $slides = $gallery.find('.room-slide');

            // Destroy slick if already initialized
            if ($gallery.hasClass('slick-initialized')) {
                $gallery.slick('unslick');
            }

            // Only initialize slick if there are 3 or more slides
            if ($slides.length >= 3) {

                $gallery.on('init', function() {
                    setTimeout(function() {
                        $gallery.slick('setPosition');
                    }, 0);
                });
                $gallery.slick({
                    infinite: true, // loop
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: true,
                    dots: false,
                    adaptiveHeight: true,
                    prevArrow: '<button type="button" class="slick-prev"><img src="' + themeUrl + '/images/left_arrow.svg" alt="Previous"></button>',
                    nextArrow: '<button type="button" class="slick-next"><img src="' + themeUrl + '/images/right_arrow.svg" alt="Next"></button>',
                    responsive: [{
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            }
        }


        $(document).on('change', '.rb-guest-input', function() {

            const room = $(this).closest('.rb-room-card');

            const limitsBox = room.find('.rb-room-limits');

            const maxGuests = parseInt(limitsBox.data('max-guests')) || 0;
            const maxInfants = parseInt(limitsBox.data('max-infants')) || 0;

            const adultsField = room.find('.rb-adults');
            const childrenField = room.find('.rb-children');
            const infantsField = room.find('.rb-infants');

            const errorGuests = room.find('.rb-error-guests');
            const errorInfants = room.find('.rb-error-infants');

            const selectBtn = room.find('.rb-select-btn');

            // Reset
            errorGuests.hide().text('');
            errorInfants.hide().text('');
            room.find('.rb-guest-input').css('border', '');
            selectBtn.prop('disabled', false);

            const adults = parseInt(adultsField.val()) || 0;
            const children = parseInt(childrenField.val()) || 0;
            const infants = parseInt(infantsField.val()) || 0;

            // 1️⃣ Adults mandatory
            if (!adults || adults < 1) {
                adultsField.css('border', '2px solid red');
                errorGuests.text('Please select number of adults.').show();
                selectBtn.prop('disabled', true);
                scrollToRoom(room);
                return;
            }

            // 2️⃣ Adults + children limit
            const nonInfantGuests = adults + children;

            if (nonInfantGuests > maxGuests) {
                room.find('.rb-adults, .rb-children').css('border', '2px solid red');
                errorGuests
                    .text(`Total guests (${nonInfantGuests}) cannot exceed ${maxGuests}.`)
                    .show();
                selectBtn.prop('disabled', true);
                // scrollToRoom(room); // limitsBox ka element nhi tha is liye comment kia ha agr baad mein add hota ha to uncomment hoga
                return;
            }

            // 3️⃣ Infants limit
            if (infants > 0 && (nonInfantGuests + infants) > (maxGuests + maxInfants)) {
                infantsField.css('border', '2px solid red');
                errorInfants
                    .text(`Guests + infants cannot exceed ${maxGuests + maxInfants}.`)
                    .show();
                selectBtn.prop('disabled', true);
                scrollToRoom(room);
                return;
            }

        });

        function rb_render_booking_from_storage() {

            const bookingContext = JSON.parse(
                localStorage.getItem('rb_booking_context')
            );

            // ❌ Defensive check (should never happen, but safe)
            if (!bookingContext.checkin || !bookingContext.checkout || !bookingContext.hotel_id) {
                alert('Booking data missing. Please search again.');
                return;
            }

            // if (!bookingContext || bookingContext.submitted !== true) {
            //     return;
            // }

            const payload = {
                action: 'load_roomboss_booking',
                hotel_id: bookingContext.hotel_id,
                start_date: bookingContext.checkin,
                end_date: bookingContext.checkout,
                adults: bookingContext.adults || 0,
                children: bookingContext.children || 0,
                infants: bookingContext.infants || 0
            };

            jQuery('.room-list').hide();
            jQuery('#room-modal').hide();

            jQuery('.booking-wrap')
                .html('<div class="rb-loading">Loading booking…</div>')
                .show();

            jQuery.ajax({
                url: kv_object.ajaxurl,
                type: 'POST',
                data: payload,
                dataType: 'json',
                success: function(resp) {                
                    $('.book-btn').prop('disabled', false).removeClass('disabled');
                    if (resp && resp.success) {
                        jQuery('.booking-wrap').html(resp.data.html);
                        updateBedroomTabs(resp.data.available_bedroom_types);
                        $('.rooms-sc-btn')
                            .prop('disabled', false)
                            .removeClass('loading')
                            .text('Check Rates');
                        scrollToRoom($('.rooms-wrap'));

                        if (typeof kv_booking_init === 'function') {
                            kv_booking_init();
                        }
                        var checkin = $('#sc-check-in').val();
                        var checkout = $('#sc-check-out').val();

                        if ( checkin.length > 0 || checkout.length > 0 ) {
                            jQuery('.book-btn').click();
                        }
                    } else {
                        jQuery('.booking-wrap').html(
                            '<p class="rb-error">Unable to restore booking.</p>'
                        );
                    }
                },
                error: function() {
                    jQuery('.booking-wrap').html(
                        '<p class="rb-error">Booking reload failed.</p>'
                    );
                }
            });

        }

    });
</script>